(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0z17s2p._.js","static/chunks/node_modules_next_0mkd4tu._.js","static/chunks/node_modules_motion-dom_dist_es_0n_wqqr._.js","static/chunks/node_modules_framer-motion_dist_es_129u8xh._.js","static/chunks/node_modules_recharts_es6_util_0h4dqy4._.js","static/chunks/node_modules_recharts_es6_component_0d9cnvp._.js","static/chunks/node_modules_recharts_es6_state_0d7bkjz._.js","static/chunks/node_modules_recharts_es6_cartesian_0n-dh4p._.js","static/chunks/node_modules_recharts_es6_0z9hv.k._.js","static/chunks/node_modules_@base-ui_react_esm_04q7krr._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_09x2h8n._.js"],
    source: "dynamic"
});
