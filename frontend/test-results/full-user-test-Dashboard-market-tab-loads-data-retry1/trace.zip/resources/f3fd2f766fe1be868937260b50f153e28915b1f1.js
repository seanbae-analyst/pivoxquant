(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ApiError",
    ()=>ApiError,
    "apiFetch",
    ()=>apiFetch
]);
async function apiFetch(path, init) {
    const res = await fetch(path, {
        credentials: "include",
        headers: {
            "Content-Type": "application/json",
            ...init?.headers
        },
        ...init
    });
    if (!res.ok) {
        const body = await res.json().catch(()=>({}));
        throw new ApiError(res.status, body.error ?? res.statusText);
    }
    return res.json();
}
class ApiError extends Error {
    status;
    constructor(status, message){
        super(message), this.status = status;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/endpoints.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API endpoint constants — single source of truth for all backend URLs.
 * Replaces magic strings throughout the frontend.
 */ __turbopack_context__.s([
    "API",
    ()=>API
]);
const API = {
    auth: {
        register: "/api/auth/register",
        login: "/api/auth/login",
        logout: "/api/auth/logout",
        me: "/api/auth/me"
    },
    portfolio: {
        list: "/api/portfolio",
        analytics: "/api/portfolio/analytics",
        history: (period)=>`/api/portfolio/history?period=${period}`,
        addPosition: "/api/portfolio/position",
        editPosition: (id)=>`/api/portfolio/position/${id}`,
        deletePosition: (id)=>`/api/portfolio/position/${id}`,
        buyMore: (id)=>`/api/portfolio/position/${id}/buy`,
        sellShares: (id)=>`/api/portfolio/position/${id}/sell`,
        buyNew: "/api/portfolio/position/buy-new",
        capital: "/api/portfolio/capital"
    },
    signals: {
        all: "/api/signals",
        one: (ticker)=>`/api/signals/${ticker}`,
        refresh: "/api/signals/refresh",
        scan: "/api/scan"
    },
    discover: "/api/discover",
    market: {
        overview: "/api/market/overview",
        status: "/api/market/status",
        macro: "/api/macro",
        sectors: "/api/sectors",
        morningBrief: "/api/morning-brief",
        lookup: (ticker)=>`/api/lookup/${ticker}`,
        prices: "/api/prices",
        chart: (ticker)=>`/api/chart/${ticker}`,
        earnings: "/api/earnings",
        peers: (ticker)=>`/api/peers/${ticker}`,
        profile: (ticker)=>`/api/profile/${ticker}`,
        dividend: (ticker)=>`/api/dividend/${ticker}`,
        news: (ticker)=>`/api/news/${ticker}`
    },
    daytrade: {
        status: "/api/daytrade/status",
        scan: "/api/daytrade/scan",
        analyze: (ticker)=>`/api/daytrade/analyze/${ticker}`,
        chart: (ticker)=>`/api/daytrade/chart/${ticker}`,
        prices: "/api/daytrade/prices",
        stream: "/api/daytrade/stream"
    },
    alerts: {
        list: "/api/alerts",
        read: "/api/alerts/read",
        clear: "/api/alerts/clear",
        priceCheck: "/api/alerts/price-check"
    },
    trades: "/api/trades",
    autotrade: {
        status: "/api/autotrade/status",
        start: "/api/autotrade/start",
        stop: "/api/autotrade/stop",
        sellAll: "/api/autotrade/sell-all"
    },
    ai: {
        status: "/api/ai/status",
        chat: "/api/ai/chat",
        swot: "/api/ai/swot",
        competitor: "/api/ai/competitor",
        sectorTrend: "/api/ai/sector-trend",
        commentary: "/api/ai/commentary",
        morningSummary: "/api/ai/morning-summary",
        coaching: "/api/ai/coaching"
    },
    watchlist: {
        list: "/api/watchlist",
        add: "/api/watchlist",
        remove: (id)=>`/api/watchlist/${id}`
    },
    realtime: {
        stream: "/api/realtime/stream",
        price: (ticker)=>`/api/realtime/price/${ticker}`,
        status: "/api/realtime/status"
    },
    backtest: (ticker)=>`/api/backtest/${ticker}`,
    quant: {
        vixStrategy: "/api/vix-strategy",
        crossAsset: "/api/cross-asset"
    },
    profile: {
        get: "/api/profile",
        onboarding: "/api/profile/onboarding",
        update: "/api/profile",
        questionnaire: "/api/profile/questionnaire"
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/auth.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$endpoints$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/endpoints.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function AuthProvider({ children }) {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const refresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[refresh]": async ()=>{
            try {
                const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$endpoints$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API"].auth.me);
                setUser(data.authenticated ? data.user ?? null : null);
            } catch  {
                setUser(null);
            } finally{
                setLoading(false);
            }
        }
    }["AuthProvider.useCallback[refresh]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            refresh();
        }
    }["AuthProvider.useEffect"], [
        refresh
    ]);
    const login = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[login]": async (email, password)=>{
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$endpoints$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API"].auth.login, {
                method: "POST",
                body: JSON.stringify({
                    email,
                    password
                })
            });
            await refresh();
        }
    }["AuthProvider.useCallback[login]"], [
        refresh
    ]);
    const signup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[signup]": async (email, password, name)=>{
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$endpoints$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API"].auth.register, {
                method: "POST",
                body: JSON.stringify({
                    email,
                    password,
                    name
                })
            });
            await refresh();
        }
    }["AuthProvider.useCallback[signup]"], [
        refresh
    ]);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthProvider.useCallback[logout]": async ()=>{
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$endpoints$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API"].auth.logout, {
                method: "POST"
            });
            setUser(null);
        }
    }["AuthProvider.useCallback[logout]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            loading,
            login,
            signup,
            logout,
            refresh
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/auth.tsx",
        lineNumber: 81,
        columnNumber: 5
    }, this);
}
_s(AuthProvider, "hZOWtFA12264g3w4DiQZ/KJLgdQ=");
_c = AuthProvider;
function useAuth() {
    _s1();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (!ctx) throw new Error("useAuth must be used within AuthProvider");
    return ctx;
}
_s1(useAuth, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/pwa/sw-init.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SwInit",
    ()=>SwInit
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
function SwInit() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SwInit.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            if (!("serviceWorker" in navigator)) return;
            navigator.serviceWorker.register("/sw.js", {
                scope: "/",
                updateViaCache: "none"
            }).then({
                "SwInit.useEffect": (reg)=>{
                    // Check for updates every 60 minutes
                    setInterval({
                        "SwInit.useEffect": ()=>reg.update()
                    }["SwInit.useEffect"], 60 * 60 * 1000);
                }
            }["SwInit.useEffect"]).catch({
                "SwInit.useEffect": ()=>{
                // SW registration failed — likely not HTTPS in dev
                }
            }["SwInit.useEffect"]);
        }
    }["SwInit.useEffect"], []);
    return null;
}
_s(SwInit, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = SwInit;
var _c;
__turbopack_context__.k.register(_c, "SwInit");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/pwa/in-app-browser-guard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InAppBrowserGuard",
    ()=>InAppBrowserGuard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function detectInAppBrowser(ua) {
    if (/KAKAOTALK/i.test(ua)) return "kakaotalk";
    if (/NAVER\(inapp/i.test(ua)) return "naver";
    if (/Line\//i.test(ua)) return "line";
    if (/Instagram/i.test(ua)) return "instagram";
    if (/FBAN|FBAV/i.test(ua)) return "facebook";
    return null;
}
function isAndroid() {
    return /Android/i.test(navigator.userAgent);
}
function isIOS() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent);
}
function openExternalBrowser(url, browser) {
    // KakaoTalk
    if (browser === "kakaotalk") {
        if (isIOS()) {
            window.location.href = `kakaotalk://web/openExternal?url=${encodeURIComponent(url)}`;
            return;
        }
        if (isAndroid()) {
            window.location.href = `intent://${url.replace(/^https?:\/\//, "")}#Intent;scheme=https;package=com.android.chrome;end`;
            return;
        }
    }
    // Naver
    if (browser === "naver") {
        if (isAndroid()) {
            window.location.href = `intent://${url.replace(/^https?:\/\//, "")}#Intent;scheme=https;package=com.android.chrome;end`;
            return;
        }
        // iOS Naver: open in Safari
        window.open(url, "_blank");
        return;
    }
    // Generic fallback: try window.open
    window.open(url, "_blank");
}
function InAppBrowserGuard() {
    _s();
    const [browser, setBrowser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [copied, setCopied] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InAppBrowserGuard.useEffect": ()=>{
            const detected = detectInAppBrowser(navigator.userAgent);
            setBrowser(detected);
            // Auto-redirect attempt
            if (detected) {
                const timer = setTimeout({
                    "InAppBrowserGuard.useEffect.timer": ()=>{
                        openExternalBrowser(window.location.href, detected);
                    }
                }["InAppBrowserGuard.useEffect.timer"], 500);
                return ({
                    "InAppBrowserGuard.useEffect": ()=>clearTimeout(timer)
                })["InAppBrowserGuard.useEffect"];
            }
        }
    }["InAppBrowserGuard.useEffect"], []);
    if (!browser) return null;
    const handleCopyUrl = async ()=>{
        try {
            await navigator.clipboard.writeText(window.location.href);
            setCopied(true);
            setTimeout(()=>setCopied(false), 2000);
        } catch  {
            // Fallback for older browsers
            const input = document.createElement("input");
            input.value = window.location.href;
            document.body.appendChild(input);
            input.select();
            document.execCommand("copy");
            document.body.removeChild(input);
            setCopied(true);
            setTimeout(()=>setCopied(false), 2000);
        }
    };
    const browserNames = {
        kakaotalk: "카카오톡",
        naver: "네이버",
        line: "라인",
        instagram: "인스타그램",
        facebook: "페이스북"
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[9999] flex items-center justify-center bg-[#050508] p-6",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-sm text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: "/icons/icon-192x192.png",
                    alt: "StockPilot",
                    className: "mx-auto mb-6 h-20 w-20 rounded-2xl"
                }, void 0, false, {
                    fileName: "[project]/src/components/pwa/in-app-browser-guard.tsx",
                    lineNumber: 100,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "mb-3 text-xl font-semibold text-zinc-100",
                    children: "외부 브라우저에서 열어주세요"
                }, void 0, false, {
                    fileName: "[project]/src/components/pwa/in-app-browser-guard.tsx",
                    lineNumber: 105,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mb-6 text-sm leading-relaxed text-zinc-400",
                    children: [
                        browserNames[browser] || "인앱",
                        " 브라우저에서는 StockPilot의 모든 기능을 사용할 수 없습니다.",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                            fileName: "[project]/src/components/pwa/in-app-browser-guard.tsx",
                            lineNumber: 111,
                            columnNumber: 11
                        }, this),
                        "Chrome 또는 Safari에서 열어주세요."
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/pwa/in-app-browser-guard.tsx",
                    lineNumber: 108,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: ()=>openExternalBrowser(window.location.href, browser),
                    className: "mb-3 w-full rounded-xl bg-emerald-500 px-6 py-3 text-sm font-semibold text-zinc-900 transition-opacity hover:opacity-85",
                    children: "외부 브라우저로 열기"
                }, void 0, false, {
                    fileName: "[project]/src/components/pwa/in-app-browser-guard.tsx",
                    lineNumber: 115,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: handleCopyUrl,
                    className: "w-full rounded-xl border border-zinc-700 px-6 py-3 text-sm text-zinc-300 transition-colors hover:border-zinc-500",
                    children: copied ? "복사됨!" : "URL 복사하기"
                }, void 0, false, {
                    fileName: "[project]/src/components/pwa/in-app-browser-guard.tsx",
                    lineNumber: 124,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-4 text-xs text-zinc-600",
                    children: "복사한 URL을 Chrome 또는 Safari에 붙여넣기 하세요"
                }, void 0, false, {
                    fileName: "[project]/src/components/pwa/in-app-browser-guard.tsx",
                    lineNumber: 131,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/pwa/in-app-browser-guard.tsx",
            lineNumber: 99,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/pwa/in-app-browser-guard.tsx",
        lineNumber: 98,
        columnNumber: 5
    }, this);
}
_s(InAppBrowserGuard, "zKFbpvYiKIyXdmD+C4TUCRSTecU=");
_c = InAppBrowserGuard;
var _c;
__turbopack_context__.k.register(_c, "InAppBrowserGuard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0ec.r3q._.js.map