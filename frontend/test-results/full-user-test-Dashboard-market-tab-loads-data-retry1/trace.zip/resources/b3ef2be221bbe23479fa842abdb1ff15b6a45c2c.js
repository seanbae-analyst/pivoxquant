(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0v_.5-z._.css","static/chunks/node_modules_next_dist_0z8ikg~._.js","static/chunks/src_0ec.r3q._.js"],
    source: "dynamic"
});
