(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/recharts/es6/state/optionsSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "arrayTooltipSearcher",
    ()=>arrayTooltipSearcher,
    "createEventEmitter",
    ()=>createEventEmitter,
    "optionsReducer",
    ()=>optionsReducer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/DataUtils.js [app-client] (ecmascript)");
;
;
var arrayTooltipSearcher = (data, strIndex)=>{
    if (!strIndex) return undefined;
    if (!Array.isArray(data)) return undefined;
    var numIndex = Number.parseInt(strIndex, 10);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNan"])(numIndex)) {
        return undefined;
    }
    return data[numIndex];
};
var initialState = {
    chartName: '',
    tooltipPayloadSearcher: ()=>undefined,
    eventEmitter: undefined,
    defaultTooltipEventType: 'axis'
};
var optionsSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'options',
    initialState,
    reducers: {
        createEventEmitter: (state)=>{
            if (state.eventEmitter == null) {
                state.eventEmitter = Symbol('rechartsEventEmitter');
            }
        }
    }
});
var optionsReducer = optionsSlice.reducer;
var { createEventEmitter } = optionsSlice.actions;
}),
"[project]/node_modules/recharts/es6/state/tooltipSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addTooltipEntrySettings",
    ()=>addTooltipEntrySettings,
    "initialState",
    ()=>initialState,
    "mouseLeaveChart",
    ()=>mouseLeaveChart,
    "mouseLeaveItem",
    ()=>mouseLeaveItem,
    "noInteraction",
    ()=>noInteraction,
    "removeTooltipEntrySettings",
    ()=>removeTooltipEntrySettings,
    "replaceTooltipEntrySettings",
    ()=>replaceTooltipEntrySettings,
    "setActiveClickItemIndex",
    ()=>setActiveClickItemIndex,
    "setActiveMouseOverItemIndex",
    ()=>setActiveMouseOverItemIndex,
    "setKeyboardInteraction",
    ()=>setKeyboardInteraction,
    "setMouseClickAxisIndex",
    ()=>setMouseClickAxisIndex,
    "setMouseOverAxisIndex",
    ()=>setMouseOverAxisIndex,
    "setSyncInteraction",
    ()=>setSyncInteraction,
    "setTooltipSettingsState",
    ()=>setTooltipSettingsState,
    "tooltipReducer",
    ()=>tooltipReducer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
;
;
var noInteraction = {
    active: false,
    index: null,
    dataKey: undefined,
    graphicalItemId: undefined,
    coordinate: undefined
};
var initialState = {
    itemInteraction: {
        click: noInteraction,
        hover: noInteraction
    },
    axisInteraction: {
        click: noInteraction,
        hover: noInteraction
    },
    keyboardInteraction: noInteraction,
    syncInteraction: {
        active: false,
        index: null,
        dataKey: undefined,
        label: undefined,
        coordinate: undefined,
        sourceViewBox: undefined,
        graphicalItemId: undefined
    },
    tooltipItemPayloads: [],
    settings: {
        shared: undefined,
        trigger: 'hover',
        axisId: 0,
        active: false,
        defaultIndex: undefined
    }
};
/**
 * This is the event we get when user is interacting with a specific graphical item.
 */ /**
 * Keyboard interaction payload has no graphical item ID,
 * and no dataKey, because keyboard interaction is always
 * with the whole chart, not with a specific graphical item.
 */ var tooltipSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'tooltip',
    initialState,
    reducers: {
        addTooltipEntrySettings: {
            reducer (state, action) {
                state.tooltipItemPayloads.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload));
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        replaceTooltipEntrySettings: {
            reducer (state, action) {
                var { prev, next } = action.payload;
                var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).tooltipItemPayloads.indexOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(prev));
                if (index > -1) {
                    state.tooltipItemPayloads[index] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(next);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        removeTooltipEntrySettings: {
            reducer (state, action) {
                var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).tooltipItemPayloads.indexOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload));
                if (index > -1) {
                    state.tooltipItemPayloads.splice(index, 1);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        setTooltipSettingsState (state, action) {
            state.settings = action.payload;
        },
        setActiveMouseOverItemIndex (state, action) {
            state.syncInteraction.active = false;
            state.syncInteraction.sourceViewBox = undefined;
            state.keyboardInteraction.active = false;
            state.itemInteraction.hover.active = true;
            state.itemInteraction.hover.index = action.payload.activeIndex;
            state.itemInteraction.hover.dataKey = action.payload.activeDataKey;
            state.itemInteraction.hover.graphicalItemId = action.payload.activeGraphicalItemId;
            state.itemInteraction.hover.coordinate = action.payload.activeCoordinate;
        },
        mouseLeaveChart (state) {
            /*
       * Clear only the active flags. Why?
       * 1. Keep Coordinate to preserve animation - next time the Tooltip appears, we want to render it from
       * the last place where it was when it disappeared.
       * 2. We want to keep all the properties anyway just in case the tooltip has `active=true` prop
       * and continues being visible even after the mouse has left the chart.
       */ state.itemInteraction.hover.active = false;
            state.axisInteraction.hover.active = false;
        },
        mouseLeaveItem (state) {
            state.itemInteraction.hover.active = false;
        },
        setActiveClickItemIndex (state, action) {
            state.syncInteraction.active = false;
            state.syncInteraction.sourceViewBox = undefined;
            state.itemInteraction.click.active = true;
            state.keyboardInteraction.active = false;
            state.itemInteraction.click.index = action.payload.activeIndex;
            state.itemInteraction.click.dataKey = action.payload.activeDataKey;
            state.itemInteraction.click.graphicalItemId = action.payload.activeGraphicalItemId;
            state.itemInteraction.click.coordinate = action.payload.activeCoordinate;
        },
        setMouseOverAxisIndex (state, action) {
            state.syncInteraction.active = false;
            state.syncInteraction.sourceViewBox = undefined;
            state.axisInteraction.hover.active = true;
            state.keyboardInteraction.active = false;
            state.axisInteraction.hover.index = action.payload.activeIndex;
            state.axisInteraction.hover.dataKey = action.payload.activeDataKey;
            state.axisInteraction.hover.coordinate = action.payload.activeCoordinate;
        },
        setMouseClickAxisIndex (state, action) {
            state.syncInteraction.active = false;
            state.syncInteraction.sourceViewBox = undefined;
            state.keyboardInteraction.active = false;
            state.axisInteraction.click.active = true;
            state.axisInteraction.click.index = action.payload.activeIndex;
            state.axisInteraction.click.dataKey = action.payload.activeDataKey;
            state.axisInteraction.click.coordinate = action.payload.activeCoordinate;
        },
        setSyncInteraction (state, action) {
            state.syncInteraction = action.payload;
        },
        setKeyboardInteraction (state, action) {
            state.keyboardInteraction.active = action.payload.active;
            state.keyboardInteraction.index = action.payload.activeIndex;
            state.keyboardInteraction.coordinate = action.payload.activeCoordinate;
        }
    }
});
var { addTooltipEntrySettings, replaceTooltipEntrySettings, removeTooltipEntrySettings, setTooltipSettingsState, setActiveMouseOverItemIndex, mouseLeaveItem, mouseLeaveChart, setActiveClickItemIndex, setMouseOverAxisIndex, setMouseClickAxisIndex, setSyncInteraction, setKeyboardInteraction } = tooltipSlice.actions;
var tooltipReducer = tooltipSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/chartDataSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "chartDataReducer",
    ()=>chartDataReducer,
    "initialChartDataState",
    ()=>initialChartDataState,
    "setChartData",
    ()=>setChartData,
    "setComputedData",
    ()=>setComputedData,
    "setDataStartEndIndexes",
    ()=>setDataStartEndIndexes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
;
;
var initialChartDataState = {
    chartData: undefined,
    computedData: undefined,
    dataStartIndex: 0,
    dataEndIndex: 0
};
var chartDataSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'chartData',
    initialState: initialChartDataState,
    reducers: {
        setChartData (state, action) {
            state.chartData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload);
            if (action.payload == null) {
                state.dataStartIndex = 0;
                state.dataEndIndex = 0;
                return;
            }
            if (action.payload.length > 0 && state.dataEndIndex !== action.payload.length - 1) {
                state.dataEndIndex = action.payload.length - 1;
            }
        },
        setComputedData (state, action) {
            state.computedData = action.payload;
        },
        setDataStartEndIndexes (state, action) {
            var { startIndex, endIndex } = action.payload;
            if (startIndex != null) {
                state.dataStartIndex = startIndex;
            }
            if (endIndex != null) {
                state.dataEndIndex = endIndex;
            }
        }
    }
});
var { setChartData, setDataStartEndIndexes, setComputedData } = chartDataSlice.actions;
var chartDataReducer = chartDataSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/layoutSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "chartLayoutReducer",
    ()=>chartLayoutReducer,
    "setChartSize",
    ()=>setChartSize,
    "setLayout",
    ()=>setLayout,
    "setMargin",
    ()=>setMargin,
    "setScale",
    ()=>setScale
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
;
var initialState = {
    layoutType: 'horizontal',
    width: 0,
    height: 0,
    margin: {
        top: 5,
        right: 5,
        bottom: 5,
        left: 5
    },
    scale: 1
};
var chartLayoutSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'chartLayout',
    initialState,
    reducers: {
        setLayout (state, action) {
            state.layoutType = action.payload;
        },
        setChartSize (state, action) {
            state.width = action.payload.width;
            state.height = action.payload.height;
        },
        setMargin (state, action) {
            var _action$payload$top, _action$payload$right, _action$payload$botto, _action$payload$left;
            state.margin.top = (_action$payload$top = action.payload.top) !== null && _action$payload$top !== void 0 ? _action$payload$top : 0;
            state.margin.right = (_action$payload$right = action.payload.right) !== null && _action$payload$right !== void 0 ? _action$payload$right : 0;
            state.margin.bottom = (_action$payload$botto = action.payload.bottom) !== null && _action$payload$botto !== void 0 ? _action$payload$botto : 0;
            state.margin.left = (_action$payload$left = action.payload.left) !== null && _action$payload$left !== void 0 ? _action$payload$left : 0;
        },
        setScale (state, action) {
            state.scale = action.payload;
        }
    }
});
var { setMargin, setLayout, setChartSize, setScale } = chartLayoutSlice.actions;
var chartLayoutReducer = chartLayoutSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/RechartsReduxContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RechartsReduxContext",
    ()=>RechartsReduxContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var RechartsReduxContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
}),
"[project]/node_modules/recharts/es6/state/hooks.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAppDispatch",
    ()=>useAppDispatch,
    "useAppSelector",
    ()=>useAppSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$shim$2f$with$2d$selector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/use-sync-external-store/shim/with-selector.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$RechartsReduxContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/RechartsReduxContext.js [app-client] (ecmascript)");
;
;
;
var noopDispatch = (a)=>a;
var useAppDispatch = ()=>{
    var context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$RechartsReduxContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RechartsReduxContext"]);
    if (context) {
        return context.store.dispatch;
    }
    return noopDispatch;
};
var noop = ()=>{};
var addNestedSubNoop = ()=>noop;
var refEquality = (a, b)=>a === b;
function useAppSelector(selector) {
    var context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$RechartsReduxContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RechartsReduxContext"]);
    var outOfContextSelector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useAppSelector.useMemo[outOfContextSelector]": ()=>{
            if (!context) {
                return noop;
            }
            return ({
                "useAppSelector.useMemo[outOfContextSelector]": (state)=>{
                    if (state == null) {
                        return undefined;
                    }
                    return selector(state);
                }
            })["useAppSelector.useMemo[outOfContextSelector]"];
        }
    }["useAppSelector.useMemo[outOfContextSelector]"], [
        context,
        selector
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$shim$2f$with$2d$selector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStoreWithSelector"])(context ? context.subscription.addNestedSub : addNestedSubNoop, context ? context.store.getState : noop, context ? context.store.getState : noop, outOfContextSelector, refEquality);
}
}),
"[project]/node_modules/recharts/es6/state/selectors/legendSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectLegendPayload",
    ()=>selectLegendPayload,
    "selectLegendSettings",
    ()=>selectLegendSettings,
    "selectLegendSize",
    ()=>selectLegendSize
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$es$2d$toolkit$2f$compat$2f$sortBy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/es-toolkit/compat/sortBy.js [app-client] (ecmascript)");
;
;
var selectLegendSettings = (state)=>state.legend.settings;
var selectLegendSize = (state)=>state.legend.size;
var selectAllLegendPayload2DArray = (state)=>state.legend.payload;
var selectLegendPayload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllLegendPayload2DArray,
    selectLegendSettings
], (payloads, _ref)=>{
    var { itemSorter } = _ref;
    var flat = payloads.flat(1);
    return itemSorter ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$es$2d$toolkit$2f$compat$2f$sortBy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(flat, itemSorter) : flat;
});
}),
"[project]/node_modules/recharts/es6/state/selectors/containerSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectChartHeight",
    ()=>selectChartHeight,
    "selectChartWidth",
    ()=>selectChartWidth,
    "selectContainerScale",
    ()=>selectContainerScale,
    "selectMargin",
    ()=>selectMargin
]);
var selectChartWidth = (state)=>state.layout.width;
var selectChartHeight = (state)=>state.layout.height;
var selectContainerScale = (state)=>state.layout.scale;
var selectMargin = (state)=>state.layout.margin;
}),
"[project]/node_modules/recharts/es6/state/selectors/selectAllAxes.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectAllXAxes",
    ()=>selectAllXAxes,
    "selectAllYAxes",
    ()=>selectAllYAxes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
;
var selectAllXAxes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])((state)=>state.cartesianAxis.xAxis, (xAxisMap)=>{
    return Object.values(xAxisMap);
});
var selectAllYAxes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])((state)=>state.cartesianAxis.yAxis, (yAxisMap)=>{
    return Object.values(yAxisMap);
});
}),
"[project]/node_modules/recharts/es6/state/selectors/selectChartOffsetInternal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectAxisViewBox",
    ()=>selectAxisViewBox,
    "selectBrushHeight",
    ()=>selectBrushHeight,
    "selectChartOffsetInternal",
    ()=>selectChartOffsetInternal,
    "selectChartViewBox",
    ()=>selectChartViewBox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$legendSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/legendSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/ChartUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/containerSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectAllAxes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/Constants.js [app-client] (ecmascript)");
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
;
;
;
;
;
var selectBrushHeight = (state)=>state.brush.height;
function selectLeftAxesOffset(state) {
    var yAxes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllYAxes"])(state);
    return yAxes.reduce((result, entry)=>{
        if (entry.orientation === 'left' && !entry.mirror && !entry.hide) {
            var width = typeof entry.width === 'number' ? entry.width : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_Y_AXIS_WIDTH"];
            return result + width;
        }
        return result;
    }, 0);
}
function selectRightAxesOffset(state) {
    var yAxes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllYAxes"])(state);
    return yAxes.reduce((result, entry)=>{
        if (entry.orientation === 'right' && !entry.mirror && !entry.hide) {
            var width = typeof entry.width === 'number' ? entry.width : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_Y_AXIS_WIDTH"];
            return result + width;
        }
        return result;
    }, 0);
}
function selectTopAxesOffset(state) {
    var xAxes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllXAxes"])(state);
    return xAxes.reduce((result, entry)=>{
        if (entry.orientation === 'top' && !entry.mirror && !entry.hide) {
            return result + entry.height;
        }
        return result;
    }, 0);
}
function selectBottomAxesOffset(state) {
    var xAxes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllXAxes"])(state);
    return xAxes.reduce((result, entry)=>{
        if (entry.orientation === 'bottom' && !entry.mirror && !entry.hide) {
            return result + entry.height;
        }
        return result;
    }, 0);
}
var selectChartOffsetInternal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartWidth"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartHeight"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectMargin"],
    selectBrushHeight,
    selectLeftAxesOffset,
    selectRightAxesOffset,
    selectTopAxesOffset,
    selectBottomAxesOffset,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$legendSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectLegendSettings"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$legendSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectLegendSize"]
], (chartWidth, chartHeight, margin, brushHeight, leftAxesOffset, rightAxesOffset, topAxesOffset, bottomAxesOffset, legendSettings, legendSize)=>{
    var offsetH = {
        left: (margin.left || 0) + leftAxesOffset,
        right: (margin.right || 0) + rightAxesOffset
    };
    var offsetV = {
        top: (margin.top || 0) + topAxesOffset,
        bottom: (margin.bottom || 0) + bottomAxesOffset
    };
    var offset = _objectSpread(_objectSpread({}, offsetV), offsetH);
    var brushBottom = offset.bottom;
    offset.bottom += brushHeight;
    offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendOffsetOfLegend"])(offset, legendSettings, legendSize);
    var offsetWidth = chartWidth - offset.left - offset.right;
    var offsetHeight = chartHeight - offset.top - offset.bottom;
    return _objectSpread(_objectSpread({
        brushBottom
    }, offset), {}, {
        // never return negative values for height and width
        width: Math.max(offsetWidth, 0),
        height: Math.max(offsetHeight, 0)
    });
});
var selectChartViewBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(selectChartOffsetInternal, (offset)=>({
        x: offset.left,
        y: offset.top,
        width: offset.width,
        height: offset.height
    }));
var selectAxisViewBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartWidth"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartHeight"], (width, height)=>({
        x: 0,
        y: 0,
        width,
        height
    }));
}),
"[project]/node_modules/recharts/es6/state/selectors/brushSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectBrushDimensions",
    ()=>selectBrushDimensions,
    "selectBrushSettings",
    ()=>selectBrushSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectChartOffsetInternal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/containerSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/DataUtils.js [app-client] (ecmascript)");
;
;
;
;
var selectBrushSettings = (state)=>state.brush;
var selectBrushDimensions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBrushSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectMargin"]
], (brushSettings, offset, margin)=>({
        height: brushSettings.height,
        x: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumber"])(brushSettings.x) ? brushSettings.x : offset.left,
        y: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumber"])(brushSettings.y) ? brushSettings.y : offset.top + offset.height + offset.brushBottom - ((margin === null || margin === void 0 ? void 0 : margin.bottom) || 0),
        width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumber"])(brushSettings.width) ? brushSettings.width : offset.width
    }));
}),
"[project]/node_modules/recharts/es6/state/selectors/dataSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectChartDataAndAlwaysIgnoreIndexes",
    ()=>selectChartDataAndAlwaysIgnoreIndexes,
    "selectChartDataSliceIfNotInPanorama",
    ()=>selectChartDataSliceIfNotInPanorama,
    "selectChartDataSliceIgnoringIndexes",
    ()=>selectChartDataSliceIgnoringIndexes,
    "selectChartDataSliceWithIndexes",
    ()=>selectChartDataSliceWithIndexes,
    "selectChartDataWithIndexes",
    ()=>selectChartDataWithIndexes,
    "selectChartDataWithIndexesIfNotInPanoramaPosition3",
    ()=>selectChartDataWithIndexesIfNotInPanoramaPosition3,
    "selectChartDataWithIndexesIfNotInPanoramaPosition4",
    ()=>selectChartDataWithIndexesIfNotInPanoramaPosition4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
;
var selectChartDataWithIndexes = (state)=>state.chartData;
var selectChartDataAndAlwaysIgnoreIndexes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectChartDataWithIndexes
], (dataState)=>{
    var dataEndIndex = dataState.chartData != null ? dataState.chartData.length - 1 : 0;
    return {
        chartData: dataState.chartData,
        computedData: dataState.computedData,
        dataEndIndex,
        dataStartIndex: 0
    };
});
var selectChartDataWithIndexesIfNotInPanoramaPosition4 = (state, _unused1, _unused2, isPanorama)=>{
    if (isPanorama) {
        return selectChartDataAndAlwaysIgnoreIndexes(state);
    }
    return selectChartDataWithIndexes(state);
};
var selectChartDataWithIndexesIfNotInPanoramaPosition3 = (state, _unused1, isPanorama)=>{
    if (isPanorama) {
        return selectChartDataAndAlwaysIgnoreIndexes(state);
    }
    return selectChartDataWithIndexes(state);
};
var selectChartDataSliceIfNotInPanorama = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectChartDataWithIndexesIfNotInPanoramaPosition4
], (_ref)=>{
    var { chartData, dataStartIndex, dataEndIndex } = _ref;
    return chartData != null ? chartData.slice(dataStartIndex, dataEndIndex + 1) : [];
});
var selectChartDataSliceIgnoringIndexes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectChartDataAndAlwaysIgnoreIndexes
], (_ref2)=>{
    var { chartData, dataStartIndex, dataEndIndex } = _ref2;
    return chartData != null ? chartData.slice(dataStartIndex, dataEndIndex + 1) : [];
});
var selectChartDataSliceWithIndexes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectChartDataWithIndexes
], (_ref3)=>{
    var { chartData, dataStartIndex, dataEndIndex } = _ref3;
    return chartData != null ? chartData.slice(dataStartIndex, dataEndIndex + 1) : [];
});
}),
"[project]/node_modules/recharts/es6/state/selectors/rootPropsSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectBarCategoryGap",
    ()=>selectBarCategoryGap,
    "selectBarGap",
    ()=>selectBarGap,
    "selectChartBaseValue",
    ()=>selectChartBaseValue,
    "selectChartName",
    ()=>selectChartName,
    "selectEventEmitter",
    ()=>selectEventEmitter,
    "selectReverseStackOrder",
    ()=>selectReverseStackOrder,
    "selectRootBarSize",
    ()=>selectRootBarSize,
    "selectRootMaxBarSize",
    ()=>selectRootMaxBarSize,
    "selectStackOffsetType",
    ()=>selectStackOffsetType,
    "selectSyncId",
    ()=>selectSyncId,
    "selectSyncMethod",
    ()=>selectSyncMethod
]);
var selectRootMaxBarSize = (state)=>state.rootProps.maxBarSize;
var selectBarGap = (state)=>state.rootProps.barGap;
var selectBarCategoryGap = (state)=>state.rootProps.barCategoryGap;
var selectRootBarSize = (state)=>state.rootProps.barSize;
var selectStackOffsetType = (state)=>state.rootProps.stackOffset;
var selectReverseStackOrder = (state)=>state.rootProps.reverseStackOrder;
var selectChartName = (state)=>state.options.chartName;
var selectSyncId = (state)=>state.rootProps.syncId;
var selectSyncMethod = (state)=>state.rootProps.syncMethod;
var selectEventEmitter = (state)=>state.options.eventEmitter;
var selectChartBaseValue = (state)=>state.rootProps.baseValue;
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineAxisRangeWithReverse.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineAxisRangeWithReverse",
    ()=>combineAxisRangeWithReverse
]);
var combineAxisRangeWithReverse = (axisSettings, axisRange)=>{
    if (!axisSettings || !axisRange) {
        return undefined;
    }
    if (axisSettings !== null && axisSettings !== void 0 && axisSettings.reversed) {
        return [
            axisRange[1],
            axisRange[0]
        ];
    }
    return axisRange;
};
}),
"[project]/node_modules/recharts/es6/state/selectors/polarAxisSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "implicitAngleAxis",
    ()=>implicitAngleAxis,
    "implicitRadiusAxis",
    ()=>implicitRadiusAxis,
    "selectAngleAxis",
    ()=>selectAngleAxis,
    "selectAngleAxisRange",
    ()=>selectAngleAxisRange,
    "selectAngleAxisRangeWithReversed",
    ()=>selectAngleAxisRangeWithReversed,
    "selectMaxRadius",
    ()=>selectMaxRadius,
    "selectOuterRadius",
    ()=>selectOuterRadius,
    "selectPolarOptions",
    ()=>selectPolarOptions,
    "selectPolarViewBox",
    ()=>selectPolarViewBox,
    "selectRadiusAxis",
    ()=>selectRadiusAxis,
    "selectRadiusAxisRange",
    ()=>selectRadiusAxisRange,
    "selectRadiusAxisRangeWithReversed",
    ()=>selectRadiusAxisRangeWithReversed
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/containerSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectChartOffsetInternal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$PolarUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/PolarUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/DataUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarAngleAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/polar/defaultPolarAngleAxisProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/polar/defaultPolarRadiusAxisProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineAxisRangeWithReverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineAxisRangeWithReverse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/chartLayoutContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getAxisTypeBasedOnLayout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/getAxisTypeBasedOnLayout.js [app-client] (ecmascript)");
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
;
;
;
;
;
;
;
;
;
var implicitAngleAxis = {
    allowDataOverflow: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarAngleAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarAngleAxisProps"].allowDataOverflow,
    allowDecimals: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarAngleAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarAngleAxisProps"].allowDecimals,
    allowDuplicatedCategory: false,
    // defaultPolarAngleAxisProps.allowDuplicatedCategory has it set to true but the actual axis rendering ignores the prop because reasons,
    dataKey: undefined,
    domain: undefined,
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarAngleAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarAngleAxisProps"].angleAxisId,
    includeHidden: false,
    name: undefined,
    reversed: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarAngleAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarAngleAxisProps"].reversed,
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarAngleAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarAngleAxisProps"].scale,
    tick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarAngleAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarAngleAxisProps"].tick,
    tickCount: undefined,
    ticks: undefined,
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarAngleAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarAngleAxisProps"].type,
    unit: undefined,
    niceTicks: 'auto'
};
var implicitRadiusAxis = {
    allowDataOverflow: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].allowDataOverflow,
    allowDecimals: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].allowDecimals,
    allowDuplicatedCategory: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].allowDuplicatedCategory,
    dataKey: undefined,
    domain: undefined,
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].radiusAxisId,
    includeHidden: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].includeHidden,
    name: undefined,
    reversed: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].reversed,
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].scale,
    tick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].tick,
    tickCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].tickCount,
    ticks: undefined,
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$polar$2f$defaultPolarRadiusAxisProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultPolarRadiusAxisProps"].type,
    unit: undefined,
    niceTicks: 'auto'
};
var selectAngleAxisNoDefaults = (state, angleAxisId)=>{
    if (angleAxisId == null) {
        return undefined;
    }
    return state.polarAxis.angleAxis[angleAxisId];
};
var selectAngleAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAngleAxisNoDefaults,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectPolarChartLayout"]
], (angleAxisSettings, layout)=>{
    var _getAxisTypeBasedOnLa;
    if (angleAxisSettings != null) {
        return angleAxisSettings;
    }
    var evaluatedType = (_getAxisTypeBasedOnLa = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getAxisTypeBasedOnLayout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAxisTypeBasedOnLayout"])(layout, 'angleAxis', implicitAngleAxis.type)) !== null && _getAxisTypeBasedOnLa !== void 0 ? _getAxisTypeBasedOnLa : 'category';
    return _objectSpread(_objectSpread({}, implicitAngleAxis), {}, {
        type: evaluatedType
    });
});
var selectRadiusAxisNoDefaults = (state, radiusAxisId)=>{
    return state.polarAxis.radiusAxis[radiusAxisId];
};
var selectRadiusAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectRadiusAxisNoDefaults,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectPolarChartLayout"]
], (radiusAxisSettings, layout)=>{
    var _getAxisTypeBasedOnLa2;
    if (radiusAxisSettings != null) {
        return radiusAxisSettings;
    }
    var evaluatedType = (_getAxisTypeBasedOnLa2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getAxisTypeBasedOnLayout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAxisTypeBasedOnLayout"])(layout, 'radiusAxis', implicitRadiusAxis.type)) !== null && _getAxisTypeBasedOnLa2 !== void 0 ? _getAxisTypeBasedOnLa2 : 'category';
    return _objectSpread(_objectSpread({}, implicitRadiusAxis), {}, {
        type: evaluatedType
    });
});
var selectPolarOptions = (state)=>state.polarOptions;
var selectMaxRadius = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartWidth"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartHeight"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$PolarUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMaxRadius"]);
var selectInnerRadius = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectPolarOptions,
    selectMaxRadius
], (polarChartOptions, maxRadius)=>{
    if (polarChartOptions == null) {
        return undefined;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPercentValue"])(polarChartOptions.innerRadius, maxRadius, 0);
});
var selectOuterRadius = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectPolarOptions,
    selectMaxRadius
], (polarChartOptions, maxRadius)=>{
    if (polarChartOptions == null) {
        return undefined;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPercentValue"])(polarChartOptions.outerRadius, maxRadius, maxRadius * 0.8);
});
var combineAngleAxisRange = (polarOptions)=>{
    if (polarOptions == null) {
        return [
            0,
            0
        ];
    }
    var { startAngle, endAngle } = polarOptions;
    return [
        startAngle,
        endAngle
    ];
};
var selectAngleAxisRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectPolarOptions
], combineAngleAxisRange);
var selectAngleAxisRangeWithReversed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAngleAxis,
    selectAngleAxisRange
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineAxisRangeWithReverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineAxisRangeWithReverse"]);
var selectRadiusAxisRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectMaxRadius,
    selectInnerRadius,
    selectOuterRadius
], (maxRadius, innerRadius, outerRadius)=>{
    if (maxRadius == null || innerRadius == null || outerRadius == null) {
        return undefined;
    }
    return [
        innerRadius,
        outerRadius
    ];
});
var selectRadiusAxisRangeWithReversed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectRadiusAxis,
    selectRadiusAxisRange
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineAxisRangeWithReverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineAxisRangeWithReverse"]);
var selectPolarViewBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectPolarOptions,
    selectInnerRadius,
    selectOuterRadius,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartWidth"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartHeight"]
], (layout, polarOptions, innerRadius, outerRadius, width, height)=>{
    if (layout !== 'centric' && layout !== 'radial' || polarOptions == null || innerRadius == null || outerRadius == null) {
        return undefined;
    }
    var { cx, cy, startAngle, endAngle } = polarOptions;
    return {
        cx: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPercentValue"])(cx, width, width / 2),
        cy: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPercentValue"])(cy, height, height / 2),
        innerRadius,
        outerRadius,
        startAngle,
        endAngle,
        clockWise: false // this property look useful, why not use it?
    };
});
}),
"[project]/node_modules/recharts/es6/state/selectors/pickAxisType.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "pickAxisType",
    ()=>pickAxisType
]);
var pickAxisType = (_state, axisType)=>axisType;
}),
"[project]/node_modules/recharts/es6/state/selectors/pickAxisId.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "pickAxisId",
    ()=>pickAxisId
]);
var pickAxisId = (_state, _axisType, axisId)=>axisId;
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineDisplayedStackedData.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineDisplayedStackedData",
    ()=>combineDisplayedStackedData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$stacks$2f$getStackSeriesIdentifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/stacks/getStackSeriesIdentifier.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/ChartUtils.js [app-client] (ecmascript)");
;
;
function combineDisplayedStackedData(stackedGraphicalItems, _ref, tooltipAxisSettings) {
    var { chartData = [] } = _ref;
    var { allowDuplicatedCategory, dataKey: tooltipDataKey } = tooltipAxisSettings;
    // A map of tooltip data keys to the stacked data points
    var knownItemsByDataKey = new Map();
    stackedGraphicalItems.forEach((item)=>{
        var _item$data;
        // If there is no data on the individual item then we use the root chart data
        var resolvedData = (_item$data = item.data) !== null && _item$data !== void 0 ? _item$data : chartData;
        if (resolvedData == null || resolvedData.length === 0) {
            // if that doesn't work then we skip this item
            return;
        }
        var stackIdentifier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$stacks$2f$getStackSeriesIdentifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStackSeriesIdentifier"])(item);
        resolvedData.forEach((entry, index)=>{
            var tooltipValue = tooltipDataKey == null || allowDuplicatedCategory ? index : String((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(entry, tooltipDataKey, null));
            var numericValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(entry, item.dataKey, 0);
            var curr;
            if (knownItemsByDataKey.has(tooltipValue)) {
                curr = knownItemsByDataKey.get(tooltipValue);
            } else {
                curr = {};
            }
            Object.assign(curr, {
                [stackIdentifier]: numericValue
            });
            knownItemsByDataKey.set(tooltipValue, curr);
        });
    });
    return Array.from(knownItemsByDataKey.values());
}
}),
"[project]/node_modules/recharts/es6/state/types/StackedGraphicalItem.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Some graphical items allow data stacking. The stacks are optional,
 * so all props here are optional too.
 */ /**
 * Some graphical items allow data stacking.
 * This interface is used to represent the items that are stacked
 * because the user has provided the stackId and dataKey properties.
 */ __turbopack_context__.s([
    "isStacked",
    ()=>isStacked
]);
function isStacked(graphicalItem) {
    return 'stackId' in graphicalItem && graphicalItem.stackId != null && graphicalItem.dataKey != null;
}
}),
"[project]/node_modules/recharts/es6/state/selectors/numberDomainEqualityCheck.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "numberDomainEqualityCheck",
    ()=>numberDomainEqualityCheck
]);
var numberDomainEqualityCheck = (a, b)=>{
    if (a === b) {
        return true;
    }
    if (a == null || b == null) {
        return false;
    }
    return a[0] === b[0] && a[1] === b[1];
};
}),
"[project]/node_modules/recharts/es6/state/selectors/arrayEqualityCheck.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Checks if two arrays are equal, treating empty arrays as equal regardless of reference.
 * If both arrays are non-empty, it checks for reference equality.
 * @param a
 * @param b
 */ __turbopack_context__.s([
    "arrayContentsAreEqualCheck",
    ()=>arrayContentsAreEqualCheck,
    "emptyArraysAreEqualCheck",
    ()=>emptyArraysAreEqualCheck
]);
function emptyArraysAreEqualCheck(a, b) {
    if (Array.isArray(a) && Array.isArray(b) && a.length === 0 && b.length === 0) {
        // empty arrays are always equal, regardless of reference
        return true;
    }
    return a === b;
}
function arrayContentsAreEqualCheck(a, b) {
    if (a.length === b.length) {
        for(var i = 0; i < a.length; i++){
            if (a[i] !== b[i]) {
                return false;
            }
        }
        return true;
    }
    return false;
}
}),
"[project]/node_modules/recharts/es6/state/selectors/selectTooltipAxisType.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectTooltipAxisType",
    ()=>selectTooltipAxisType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/chartLayoutContext.js [app-client] (ecmascript)");
;
var selectTooltipAxisType = (state)=>{
    var layout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"])(state);
    if (layout === 'horizontal') {
        return 'xAxis';
    }
    if (layout === 'vertical') {
        return 'yAxis';
    }
    if (layout === 'centric') {
        return 'angleAxis';
    }
    return 'radiusAxis';
};
}),
"[project]/node_modules/recharts/es6/state/selectors/selectTooltipAxisId.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectTooltipAxisId",
    ()=>selectTooltipAxisId
]);
var selectTooltipAxisId = (state)=>state.tooltip.settings.axisId;
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineCheckedDomain.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineCheckedDomain",
    ()=>combineCheckedDomain
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/isDomainSpecifiedByUser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/isWellBehavedNumber.js [app-client] (ecmascript)");
;
;
var combineCheckedDomain = (realScaleType, axisDomain)=>{
    if (axisDomain == null) {
        return undefined;
    }
    switch(realScaleType){
        case 'linear':
            {
                /*
         * linear scale only reads the first two numbers in the domain, and ignores everything else.
         * So if it happens that someone somehow gave us a bigger domain,
         * let's pick the min and max from it.
         */ if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellFormedNumberDomain"])(axisDomain)) {
                    var min, max;
                    for(var i = 0; i < axisDomain.length; i++){
                        var value = axisDomain[i];
                        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(value)) {
                            continue;
                        }
                        if (min === undefined || value < min) {
                            min = value;
                        }
                        if (max === undefined || value > max) {
                            max = value;
                        }
                    }
                    if (min !== undefined && max !== undefined) {
                        return [
                            min,
                            max
                        ];
                    }
                    return undefined;
                }
                return axisDomain;
            }
        default:
            return axisDomain;
    }
};
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineConfiguredScale.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineConfiguredScale",
    ()=>combineConfiguredScale,
    "combineConfiguredScaleInternal",
    ()=>combineConfiguredScaleInternal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$victory$2d$vendor$2f$es$2f$d3$2d$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/victory-vendor/es/d3-scale.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$victory$2d$vendor$2f$es$2f$d3$2d$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/victory-vendor/es/d3-scale.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/DataUtils.js [app-client] (ecmascript)");
;
;
function getD3ScaleFromType(realScaleType) {
    var scales = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$victory$2d$vendor$2f$es$2f$d3$2d$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__;
    if (realScaleType in scales && typeof scales[realScaleType] === 'function') {
        return scales[realScaleType]();
    }
    var name = "scale".concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["upperFirst"])(realScaleType));
    if (name in scales && typeof scales[name] === 'function') {
        return scales[name]();
    }
    return undefined;
}
function combineConfiguredScaleInternal(scale, axisDomain, axisRange) {
    if (typeof scale === 'function') {
        return scale.copy().domain(axisDomain).range(axisRange);
    }
    if (scale == null) {
        return undefined;
    }
    var d3ScaleFunction = getD3ScaleFromType(scale);
    if (d3ScaleFunction == null) {
        return undefined;
    }
    d3ScaleFunction.domain(axisDomain).range(axisRange);
    return d3ScaleFunction;
}
function combineConfiguredScale(axis, realScaleType, axisDomain, axisRange) {
    if (axisDomain == null || axisRange == null) {
        return undefined;
    }
    if (typeof axis.scale === 'function') {
        return combineConfiguredScaleInternal(axis.scale, axisDomain, axisRange);
    }
    return combineConfiguredScaleInternal(realScaleType, axisDomain, axisRange);
}
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineRealScaleType.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineRealScaleType",
    ()=>combineRealScaleType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$victory$2d$vendor$2f$es$2f$d3$2d$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/victory-vendor/es/d3-scale.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$victory$2d$vendor$2f$es$2f$d3$2d$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/victory-vendor/es/d3-scale.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/DataUtils.js [app-client] (ecmascript)");
;
;
function getD3ScaleName(name) {
    return "scale".concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["upperFirst"])(name));
}
function isSupportedScaleName(name) {
    return getD3ScaleName(name) in __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$victory$2d$vendor$2f$es$2f$d3$2d$scale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__;
}
var combineRealScaleType = (axisConfig, hasBar, chartType)=>{
    if (axisConfig == null) {
        return undefined;
    }
    var { scale, type } = axisConfig;
    if (scale === 'auto') {
        if (type === 'category' && chartType && (chartType.indexOf('LineChart') >= 0 || chartType.indexOf('AreaChart') >= 0 || chartType.indexOf('ComposedChart') >= 0 && !hasBar)) {
            return 'point';
        }
        if (type === 'category') {
            return 'band';
        }
        return 'linear';
    }
    if (typeof scale === 'string') {
        return isSupportedScaleName(scale) ? scale : 'point';
    }
    return undefined;
};
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineInverseScaleFunction.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineInverseScaleFunction",
    ()=>combineInverseScaleFunction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$createCategoricalInverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/scale/createCategoricalInverse.js [app-client] (ecmascript)");
;
function combineInverseScaleFunction(configuredScale) {
    if (configuredScale == null) {
        return undefined;
    }
    if ('invert' in configuredScale && typeof configuredScale.invert === 'function') {
        return configuredScale.invert.bind(configuredScale);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$createCategoricalInverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCategoricalInverse"])(configuredScale, undefined);
}
}),
"[project]/node_modules/recharts/es6/state/selectors/axisSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineAllAppliedValues",
    ()=>combineAllAppliedValues,
    "combineAppliedValues",
    ()=>combineAppliedValues,
    "combineAreasDomain",
    ()=>combineAreasDomain,
    "combineAxisDomain",
    ()=>combineAxisDomain,
    "combineAxisDomainWithNiceTicks",
    ()=>combineAxisDomainWithNiceTicks,
    "combineAxisTicks",
    ()=>combineAxisTicks,
    "combineCategoricalDomain",
    ()=>combineCategoricalDomain,
    "combineDisplayedData",
    ()=>combineDisplayedData,
    "combineDomainOfAllAppliedNumericalValuesIncludingErrorValues",
    ()=>combineDomainOfAllAppliedNumericalValuesIncludingErrorValues,
    "combineDomainOfStackGroups",
    ()=>combineDomainOfStackGroups,
    "combineDotsDomain",
    ()=>combineDotsDomain,
    "combineDuplicateDomain",
    ()=>combineDuplicateDomain,
    "combineGraphicalItemTicks",
    ()=>combineGraphicalItemTicks,
    "combineGraphicalItemsData",
    ()=>combineGraphicalItemsData,
    "combineGraphicalItemsSettings",
    ()=>combineGraphicalItemsSettings,
    "combineLinesDomain",
    ()=>combineLinesDomain,
    "combineNiceTicks",
    ()=>combineNiceTicks,
    "combineNumericalDomain",
    ()=>combineNumericalDomain,
    "combineStackGroups",
    ()=>combineStackGroups,
    "defaultNumericDomain",
    ()=>defaultNumericDomain,
    "filterGraphicalNotStackedItems",
    ()=>filterGraphicalNotStackedItems,
    "filterReferenceElements",
    ()=>filterReferenceElements,
    "getDomainDefinition",
    ()=>getDomainDefinition,
    "getErrorDomainByDataKey",
    ()=>getErrorDomainByDataKey,
    "implicitXAxis",
    ()=>implicitXAxis,
    "implicitYAxis",
    ()=>implicitYAxis,
    "implicitZAxis",
    ()=>implicitZAxis,
    "isErrorBarRelevantForAxisType",
    ()=>isErrorBarRelevantForAxisType,
    "itemAxisPredicate",
    ()=>itemAxisPredicate,
    "mergeDomains",
    ()=>mergeDomains,
    "selectAllAppliedValues",
    ()=>selectAllAppliedValues,
    "selectAllErrorBarSettings",
    ()=>selectAllErrorBarSettings,
    "selectAllXAxesOffsetSteps",
    ()=>selectAllXAxesOffsetSteps,
    "selectAllYAxesOffsetSteps",
    ()=>selectAllYAxesOffsetSteps,
    "selectAnyCartesianItemsUsesChartData",
    ()=>selectAnyCartesianItemsUsesChartData,
    "selectAxisDomain",
    ()=>selectAxisDomain,
    "selectAxisDomainIncludingNiceTicks",
    ()=>selectAxisDomainIncludingNiceTicks,
    "selectAxisInverseDataSnapScale",
    ()=>selectAxisInverseDataSnapScale,
    "selectAxisInverseScale",
    ()=>selectAxisInverseScale,
    "selectAxisInverseTickSnapScale",
    ()=>selectAxisInverseTickSnapScale,
    "selectAxisPropsNeededForCartesianGridTicksGenerator",
    ()=>selectAxisPropsNeededForCartesianGridTicksGenerator,
    "selectAxisRange",
    ()=>selectAxisRange,
    "selectAxisRangeWithReverse",
    ()=>selectAxisRangeWithReverse,
    "selectAxisScale",
    ()=>selectAxisScale,
    "selectAxisWithScale",
    ()=>selectAxisWithScale,
    "selectBaseAxis",
    ()=>selectBaseAxis,
    "selectCalculatedXAxisPadding",
    ()=>selectCalculatedXAxisPadding,
    "selectCalculatedYAxisPadding",
    ()=>selectCalculatedYAxisPadding,
    "selectCartesianAxisSize",
    ()=>selectCartesianAxisSize,
    "selectCartesianGraphicalItemsData",
    ()=>selectCartesianGraphicalItemsData,
    "selectCartesianItemsSettings",
    ()=>selectCartesianItemsSettings,
    "selectCategoricalDomain",
    ()=>selectCategoricalDomain,
    "selectChartDirection",
    ()=>selectChartDirection,
    "selectCheckedAxisDomain",
    ()=>selectCheckedAxisDomain,
    "selectDisplayedData",
    ()=>selectDisplayedData,
    "selectDisplayedStackedData",
    ()=>selectDisplayedStackedData,
    "selectDomainDefinition",
    ()=>selectDomainDefinition,
    "selectDomainFromUserPreference",
    ()=>selectDomainFromUserPreference,
    "selectDomainOfStackGroups",
    ()=>selectDomainOfStackGroups,
    "selectDuplicateDomain",
    ()=>selectDuplicateDomain,
    "selectErrorBarsSettings",
    ()=>selectErrorBarsSettings,
    "selectHasBar",
    ()=>selectHasBar,
    "selectNiceTicks",
    ()=>selectNiceTicks,
    "selectNumericalDomain",
    ()=>selectNumericalDomain,
    "selectRealScaleType",
    ()=>selectRealScaleType,
    "selectReferenceAreas",
    ()=>selectReferenceAreas,
    "selectReferenceAreasByAxis",
    ()=>selectReferenceAreasByAxis,
    "selectReferenceDots",
    ()=>selectReferenceDots,
    "selectReferenceDotsByAxis",
    ()=>selectReferenceDotsByAxis,
    "selectReferenceLines",
    ()=>selectReferenceLines,
    "selectReferenceLinesByAxis",
    ()=>selectReferenceLinesByAxis,
    "selectRenderableAxisSettings",
    ()=>selectRenderableAxisSettings,
    "selectRenderedTicksOfAxis",
    ()=>selectRenderedTicksOfAxis,
    "selectSmallestDistanceBetweenValues",
    ()=>selectSmallestDistanceBetweenValues,
    "selectSortedDataPoints",
    ()=>selectSortedDataPoints,
    "selectStackGroups",
    ()=>selectStackGroups,
    "selectStackedCartesianItemsSettings",
    ()=>selectStackedCartesianItemsSettings,
    "selectTicksOfAxis",
    ()=>selectTicksOfAxis,
    "selectTicksOfGraphicalItem",
    ()=>selectTicksOfGraphicalItem,
    "selectTooltipAxis",
    ()=>selectTooltipAxis,
    "selectTooltipAxisDataKey",
    ()=>selectTooltipAxisDataKey,
    "selectUnfilteredCartesianItems",
    ()=>selectUnfilteredCartesianItems,
    "selectXAxisPosition",
    ()=>selectXAxisPosition,
    "selectXAxisRange",
    ()=>selectXAxisRange,
    "selectXAxisSettings",
    ()=>selectXAxisSettings,
    "selectXAxisSettingsNoDefaults",
    ()=>selectXAxisSettingsNoDefaults,
    "selectXAxisSize",
    ()=>selectXAxisSize,
    "selectYAxisPosition",
    ()=>selectYAxisPosition,
    "selectYAxisRange",
    ()=>selectYAxisRange,
    "selectYAxisSettings",
    ()=>selectYAxisSettings,
    "selectYAxisSettingsNoDefaults",
    ()=>selectYAxisSettingsNoDefaults,
    "selectYAxisSize",
    ()=>selectYAxisSize,
    "selectZAxisSettings",
    ()=>selectZAxisSettings,
    "selectZAxisWithScale",
    ()=>selectZAxisWithScale
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$es$2d$toolkit$2f$compat$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/es-toolkit/compat/range.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/chartLayoutContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/ChartUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/dataSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/isDomainSpecifiedByUser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/DataUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/isWellBehavedNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$getNiceTickValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/scale/getNiceTickValues.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/containerSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectAllAxes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectChartOffsetInternal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$brushSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/brushSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/rootPropsSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$polarAxisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/polarAxisSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/pickAxisType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/pickAxisId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineAxisRangeWithReverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineAxisRangeWithReverse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$stacks$2f$getStackSeriesIdentifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/stacks/getStackSeriesIdentifier.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineDisplayedStackedData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineDisplayedStackedData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$types$2f$StackedGraphicalItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/types/StackedGraphicalItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$numberDomainEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/numberDomainEqualityCheck.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$arrayEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/arrayEqualityCheck.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipAxisType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipAxisId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$RechartsScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/scale/RechartsScale.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineCheckedDomain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineCheckedDomain.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineConfiguredScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineConfiguredScale.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineRealScaleType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineRealScaleType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$createCategoricalInverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/scale/createCategoricalInverse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineInverseScaleFunction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineInverseScaleFunction.js [app-client] (ecmascript)");
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var defaultNumericDomain = [
    0,
    'auto'
];
var implicitXAxis = {
    allowDataOverflow: false,
    allowDecimals: true,
    allowDuplicatedCategory: true,
    angle: 0,
    dataKey: undefined,
    domain: undefined,
    height: 30,
    hide: true,
    id: 0,
    includeHidden: false,
    interval: 'preserveEnd',
    minTickGap: 5,
    mirror: false,
    name: undefined,
    orientation: 'bottom',
    padding: {
        left: 0,
        right: 0
    },
    reversed: false,
    scale: 'auto',
    tick: true,
    tickCount: 5,
    tickFormatter: undefined,
    ticks: undefined,
    type: 'category',
    unit: undefined,
    niceTicks: 'auto'
};
var selectXAxisSettingsNoDefaults = (state, axisId)=>{
    return state.cartesianAxis.xAxis[axisId];
};
var selectXAxisSettings = (state, axisId)=>{
    var axis = selectXAxisSettingsNoDefaults(state, axisId);
    if (axis == null) {
        return implicitXAxis;
    }
    return axis;
};
var implicitYAxis = {
    allowDataOverflow: false,
    allowDecimals: true,
    allowDuplicatedCategory: true,
    angle: 0,
    dataKey: undefined,
    domain: defaultNumericDomain,
    hide: true,
    id: 0,
    includeHidden: false,
    interval: 'preserveEnd',
    minTickGap: 5,
    mirror: false,
    name: undefined,
    orientation: 'left',
    padding: {
        top: 0,
        bottom: 0
    },
    reversed: false,
    scale: 'auto',
    tick: true,
    tickCount: 5,
    tickFormatter: undefined,
    ticks: undefined,
    type: 'number',
    unit: undefined,
    niceTicks: 'auto',
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_Y_AXIS_WIDTH"]
};
var selectYAxisSettingsNoDefaults = (state, axisId)=>{
    return state.cartesianAxis.yAxis[axisId];
};
var selectYAxisSettings = (state, axisId)=>{
    var axis = selectYAxisSettingsNoDefaults(state, axisId);
    if (axis == null) {
        return implicitYAxis;
    }
    return axis;
};
var implicitZAxis = {
    domain: [
        0,
        'auto'
    ],
    includeHidden: false,
    reversed: false,
    allowDataOverflow: false,
    allowDuplicatedCategory: false,
    dataKey: undefined,
    id: 0,
    name: '',
    range: [
        64,
        64
    ],
    scale: 'auto',
    type: 'number',
    unit: ''
};
var selectZAxisSettings = (state, axisId)=>{
    var axis = state.cartesianAxis.zAxis[axisId];
    if (axis == null) {
        return implicitZAxis;
    }
    return axis;
};
var selectBaseAxis = (state, axisType, axisId)=>{
    switch(axisType){
        case 'xAxis':
            {
                return selectXAxisSettings(state, axisId);
            }
        case 'yAxis':
            {
                return selectYAxisSettings(state, axisId);
            }
        case 'zAxis':
            {
                return selectZAxisSettings(state, axisId);
            }
        case 'angleAxis':
            {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$polarAxisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAngleAxis"])(state, axisId);
            }
        case 'radiusAxis':
            {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$polarAxisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectRadiusAxis"])(state, axisId);
            }
        default:
            throw new Error("Unexpected axis type: ".concat(axisType));
    }
};
var selectCartesianAxisSettings = (state, axisType, axisId)=>{
    switch(axisType){
        case 'xAxis':
            {
                return selectXAxisSettings(state, axisId);
            }
        case 'yAxis':
            {
                return selectYAxisSettings(state, axisId);
            }
        default:
            throw new Error("Unexpected axis type: ".concat(axisType));
    }
};
var selectRenderableAxisSettings = (state, axisType, axisId)=>{
    switch(axisType){
        case 'xAxis':
            {
                return selectXAxisSettings(state, axisId);
            }
        case 'yAxis':
            {
                return selectYAxisSettings(state, axisId);
            }
        case 'angleAxis':
            {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$polarAxisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAngleAxis"])(state, axisId);
            }
        case 'radiusAxis':
            {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$polarAxisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectRadiusAxis"])(state, axisId);
            }
        default:
            throw new Error("Unexpected axis type: ".concat(axisType));
    }
};
var selectHasBar = (state)=>state.graphicalItems.cartesianItems.some((item)=>item.type === 'bar') || state.graphicalItems.polarItems.some((item)=>item.type === 'radialBar');
function itemAxisPredicate(axisType, axisId) {
    return (item)=>{
        switch(axisType){
            case 'xAxis':
                // This is sensitive to the data type, as 0 !== '0'. I wonder if we should be more flexible. How does 2.x branch behave? TODO write test for that
                return 'xAxisId' in item && item.xAxisId === axisId;
            case 'yAxis':
                return 'yAxisId' in item && item.yAxisId === axisId;
            case 'zAxis':
                return 'zAxisId' in item && item.zAxisId === axisId;
            case 'angleAxis':
                return 'angleAxisId' in item && item.angleAxisId === axisId;
            case 'radiusAxis':
                return 'radiusAxisId' in item && item.radiusAxisId === axisId;
            default:
                return false;
        }
    };
}
var selectUnfilteredCartesianItems = (state)=>state.graphicalItems.cartesianItems;
var selectAxisPredicate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisId"]
], itemAxisPredicate);
var combineGraphicalItemsSettings = (graphicalItems, axisSettings, axisPredicate)=>graphicalItems.filter(axisPredicate).filter((item)=>{
        if ((axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.includeHidden) === true) {
            return true;
        }
        return !item.hide;
    });
var selectCartesianItemsSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectUnfilteredCartesianItems,
    selectBaseAxis,
    selectAxisPredicate
], combineGraphicalItemsSettings, {
    memoizeOptions: {
        resultEqualityCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$arrayEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyArraysAreEqualCheck"]
    }
});
var selectStackedCartesianItemsSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectCartesianItemsSettings
], (cartesianItems)=>{
    return cartesianItems.filter((item)=>item.type === 'area' || item.type === 'bar').filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$types$2f$StackedGraphicalItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isStacked"]);
});
var filterGraphicalNotStackedItems = (cartesianItems)=>cartesianItems.filter((item)=>!('stackId' in item) || item.stackId === undefined);
var selectCartesianItemsSettingsExceptStacked = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectCartesianItemsSettings
], filterGraphicalNotStackedItems);
var combineGraphicalItemsData = (cartesianItems)=>cartesianItems.map((item)=>item.data).filter(Boolean).flat(1);
var selectAnyCartesianItemsUsesChartData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectCartesianItemsSettings
], (items)=>items.some((item)=>!item.data));
var selectCartesianGraphicalItemsData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectCartesianItemsSettings
], combineGraphicalItemsData, {
    memoizeOptions: {
        resultEqualityCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$arrayEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyArraysAreEqualCheck"]
    }
});
var combineDisplayedData = (graphicalItemsData, _ref)=>{
    var { chartData = [], dataStartIndex, dataEndIndex } = _ref;
    if (graphicalItemsData.length > 0) {
        /*
     * There is no slicing when data is defined on graphical items. Why?
     * Because Brush ignores data defined on graphical items,
     * and does not render.
     * So Brush will never show up in a Scatter chart for example.
     * This is something we will need to fix.
     *
     * Now, when the root chart data is not defined, the dataEndIndex is 0,
     * which means the itemsData will be sliced to an empty array anyway.
     * But that's an implementation detail, and we can fix that too.
     *
     * Also, in absence of Axis dataKey, we use the dataKey from each item, respectively.
     * This is the usual pattern for numerical axis, that is the one where bars go up:
     * users don't specify any dataKey by default and expect the axis to "just match the data".
     */ return graphicalItemsData;
    }
    return chartData.slice(dataStartIndex, dataEndIndex + 1);
};
var selectDisplayedData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectCartesianGraphicalItemsData,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexesIfNotInPanoramaPosition4"]
], combineDisplayedData);
var combineAppliedValues = (data, axisSettings, items)=>{
    if ((axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.dataKey) != null) {
        return data.map((item)=>({
                value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(item, axisSettings.dataKey)
            }));
    }
    if (items.length > 0) {
        return items.map((item)=>item.dataKey).flatMap((dataKey)=>data.map((entry)=>({
                    value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(entry, dataKey)
                })));
    }
    return data.map((entry)=>({
            value: entry
        }));
};
var combineAllAppliedValues = (displayedData, axisSettings, items, _ref2, anyItemUsesChartData, graphicalItemsData)=>{
    var { chartData = [], dataStartIndex, dataEndIndex } = _ref2;
    var appliedValues = combineAppliedValues(displayedData, axisSettings, items);
    if (anyItemUsesChartData && (axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.dataKey) != null && graphicalItemsData.length > 0) {
        var chartDataSlice = chartData.slice(dataStartIndex, dataEndIndex + 1);
        var chartAppliedValues = chartDataSlice.map((item)=>({
                value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(item, axisSettings.dataKey)
            })).filter((av)=>av.value != null);
        return [
            ...chartAppliedValues,
            ...appliedValues
        ];
    }
    return appliedValues;
};
var selectAllAppliedValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectDisplayedData,
    selectBaseAxis,
    selectCartesianItemsSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexesIfNotInPanoramaPosition4"],
    selectAnyCartesianItemsUsesChartData,
    selectCartesianGraphicalItemsData
], combineAllAppliedValues);
function makeNumber(val) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumOrStr"])(val) || val instanceof Date) {
        var n = Number(val);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(n)) {
            return n;
        }
    }
    return undefined;
}
function makeDomain(val) {
    if (Array.isArray(val)) {
        var attempt = [
            makeNumber(val[0]),
            makeNumber(val[1])
        ];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellFormedNumberDomain"])(attempt)) {
            return attempt;
        }
        return undefined;
    }
    var n = makeNumber(val);
    if (n == null) {
        return undefined;
    }
    return [
        n,
        n
    ];
}
function onlyAllowNumbers(data) {
    return data.map(makeNumber).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
}
function sortBy(a, b) {
    var aNum = makeNumber(a);
    var bNum = makeNumber(b);
    if (aNum == null && bNum == null) {
        return 0;
    }
    if (aNum == null) {
        return -1;
    }
    if (bNum == null) {
        return 1;
    }
    return aNum - bNum;
}
var selectSortedDataPoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllAppliedValues
], (appliedData)=>{
    return appliedData === null || appliedData === void 0 ? void 0 : appliedData.map((item)=>item.value).sort(sortBy);
});
function isErrorBarRelevantForAxisType(axisType, errorBar) {
    switch(axisType){
        case 'xAxis':
            return errorBar.direction === 'x';
        case 'yAxis':
            return errorBar.direction === 'y';
        default:
            return false;
    }
}
function getErrorDomainByDataKey(entry, appliedValue, relevantErrorBars) {
    if (!relevantErrorBars) {
        return [];
    }
    if (!relevantErrorBars.length) {
        return [];
    }
    var appliedNumericValue;
    if (typeof appliedValue === 'number' && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNan"])(appliedValue)) {
        appliedNumericValue = appliedValue;
    } else if (Array.isArray(appliedValue)) {
        var numericRangeValues = onlyAllowNumbers(appliedValue);
        if (numericRangeValues.length > 0) {
            appliedNumericValue = Math.max(...numericRangeValues);
        }
    }
    if (appliedNumericValue == null) {
        return [];
    }
    return onlyAllowNumbers(relevantErrorBars.flatMap((eb)=>{
        var errorValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(entry, eb.dataKey);
        var lowBound, highBound;
        if (Array.isArray(errorValue)) {
            [lowBound, highBound] = errorValue;
        } else {
            lowBound = highBound = errorValue;
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(lowBound) || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(highBound)) {
            return undefined;
        }
        return [
            appliedNumericValue - lowBound,
            appliedNumericValue + highBound
        ];
    }));
}
var selectTooltipAxis = (state)=>{
    var axisType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"])(state);
    var axisId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisId"])(state);
    return selectRenderableAxisSettings(state, axisType, axisId);
};
var selectTooltipAxisDataKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipAxis
], (axis)=>axis === null || axis === void 0 ? void 0 : axis.dataKey);
var selectDisplayedStackedData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectStackedCartesianItemsSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexesIfNotInPanoramaPosition4"],
    selectTooltipAxis
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineDisplayedStackedData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineDisplayedStackedData"]);
var combineStackGroups = (displayedData, items, stackOffsetType, reverseStackOrder)=>{
    var initialItemsGroups = {};
    var itemsGroup = items.reduce((acc, item)=>{
        if (item.stackId == null) {
            return acc;
        }
        var stack = acc[item.stackId];
        if (stack == null) {
            stack = [];
        }
        stack.push(item);
        acc[item.stackId] = stack;
        return acc;
    }, initialItemsGroups);
    return Object.fromEntries(Object.entries(itemsGroup).map((_ref3)=>{
        var [stackId, graphicalItems] = _ref3;
        var orderedGraphicalItems = reverseStackOrder ? [
            ...graphicalItems
        ].reverse() : graphicalItems;
        var dataKeys = orderedGraphicalItems.map(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$stacks$2f$getStackSeriesIdentifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStackSeriesIdentifier"]);
        return [
            stackId,
            {
                // @ts-expect-error getStackedData requires that the input is array of objects, Recharts does not test for that
                stackedData: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStackedData"])(displayedData, dataKeys, stackOffsetType),
                graphicalItems: orderedGraphicalItems
            }
        ];
    }));
};
var selectStackGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectDisplayedStackedData,
    selectStackedCartesianItemsSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectStackOffsetType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectReverseStackOrder"]
], combineStackGroups);
var combineDomainOfStackGroups = (stackGroups, _ref4, axisType, domainFromUserPreference)=>{
    var { dataStartIndex, dataEndIndex } = _ref4;
    if (domainFromUserPreference != null) {
        // User has specified a domain, so we respect that and we can skip computing anything else
        return undefined;
    }
    if (axisType === 'zAxis') {
        // ZAxis ignores stacks
        return undefined;
    }
    var domainOfStackGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDomainOfStackGroups"])(stackGroups, dataStartIndex, dataEndIndex);
    if (domainOfStackGroups != null && domainOfStackGroups[0] === 0 && domainOfStackGroups[1] === 0) {
        return undefined;
    }
    return domainOfStackGroups;
};
var selectAllowsDataOverflow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBaseAxis
], (axisSettings)=>axisSettings.allowDataOverflow);
var getDomainDefinition = (axisSettings)=>{
    var _axisSettings$domain;
    if (axisSettings == null || !('domain' in axisSettings)) {
        return defaultNumericDomain;
    }
    if (axisSettings.domain != null) {
        return axisSettings.domain;
    }
    if ('ticks' in axisSettings && axisSettings.ticks != null) {
        if (axisSettings.type === 'number') {
            var allValues = onlyAllowNumbers(axisSettings.ticks);
            return [
                Math.min(...allValues),
                Math.max(...allValues)
            ];
        }
        if (axisSettings.type === 'category') {
            return axisSettings.ticks.map(String);
        }
    }
    return (_axisSettings$domain = axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.domain) !== null && _axisSettings$domain !== void 0 ? _axisSettings$domain : defaultNumericDomain;
};
var selectDomainDefinition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBaseAxis
], getDomainDefinition);
var selectDomainFromUserPreference = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectDomainDefinition,
    selectAllowsDataOverflow
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["numericalDomainSpecifiedWithoutRequiringData"]);
var selectDomainOfStackGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectStackGroups,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexes"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"],
    selectDomainFromUserPreference
], combineDomainOfStackGroups, {
    memoizeOptions: {
        resultEqualityCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$numberDomainEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["numberDomainEqualityCheck"]
    }
});
var selectAllErrorBarSettings = (state)=>state.errorBars;
var combineRelevantErrorBarSettings = (cartesianItemsSettings, allErrorBarSettings, axisType)=>{
    return cartesianItemsSettings.flatMap((item)=>{
        return allErrorBarSettings[item.id];
    }).filter(Boolean).filter((e)=>{
        return isErrorBarRelevantForAxisType(axisType, e);
    });
};
var mergeDomains = function mergeDomains() {
    for(var _len = arguments.length, domains = new Array(_len), _key = 0; _key < _len; _key++){
        domains[_key] = arguments[_key];
    }
    var allDomains = domains.filter(Boolean);
    if (allDomains.length === 0) {
        return undefined;
    }
    var allValues = allDomains.flat();
    var min = Math.min(...allValues);
    var max = Math.max(...allValues);
    return [
        min,
        max
    ];
};
var combineDomainOfAllAppliedNumericalValuesIncludingErrorValues = function combineDomainOfAllAppliedNumericalValuesIncludingErrorValues(displayedData, axisSettings, items, errorBars, axisType) {
    var chartDataSlice = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : [];
    var lowerEnd, upperEnd;
    if (items.length > 0) {
        /*
     * Iterate item-first so each item can use its own `data` prop when present,
     * falling back to the chart-level data slice for items that rely on it.
     * This ensures that mixing items with and without own data (e.g. Bar reading
     * chart-level data alongside a Scatter with its own outlier data) produces a
     * domain that covers all values from all sources.
     */ items.forEach((item)=>{
            var _errorBars$item$id;
            var itemData = item.data != null ? [
                ...item.data
            ] : chartDataSlice;
            var relevantErrorBars = (_errorBars$item$id = errorBars[item.id]) === null || _errorBars$item$id === void 0 ? void 0 : _errorBars$item$id.filter((errorBar)=>isErrorBarRelevantForAxisType(axisType, errorBar));
            itemData.forEach((entry)=>{
                var _axisSettings$dataKey;
                var valueByDataKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(entry, (_axisSettings$dataKey = axisSettings.dataKey) !== null && _axisSettings$dataKey !== void 0 ? _axisSettings$dataKey : item.dataKey);
                var errorDomain = getErrorDomainByDataKey(entry, valueByDataKey, relevantErrorBars);
                if (errorDomain.length >= 2) {
                    var localLower = Math.min(...errorDomain);
                    var localUpper = Math.max(...errorDomain);
                    if (lowerEnd == null || localLower < lowerEnd) {
                        lowerEnd = localLower;
                    }
                    if (upperEnd == null || localUpper > upperEnd) {
                        upperEnd = localUpper;
                    }
                }
                var dataValueDomain = makeDomain(valueByDataKey);
                if (dataValueDomain != null) {
                    lowerEnd = lowerEnd == null ? dataValueDomain[0] : Math.min(lowerEnd, dataValueDomain[0]);
                    upperEnd = upperEnd == null ? dataValueDomain[1] : Math.max(upperEnd, dataValueDomain[1]);
                }
            });
        });
    }
    if ((axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.dataKey) != null && items.length === 0) {
        // When there are no items, fall back to the displayed data (chart-level or graphical item data).
        displayedData.forEach((item)=>{
            var dataValueDomain = makeDomain((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(item, axisSettings.dataKey));
            if (dataValueDomain != null) {
                lowerEnd = lowerEnd == null ? dataValueDomain[0] : Math.min(lowerEnd, dataValueDomain[0]);
                upperEnd = upperEnd == null ? dataValueDomain[1] : Math.max(upperEnd, dataValueDomain[1]);
            }
        });
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(lowerEnd) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(upperEnd)) {
        return [
            lowerEnd,
            upperEnd
        ];
    }
    return undefined;
};
var selectDomainOfAllAppliedNumericalValuesIncludingErrorValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectDisplayedData,
    selectBaseAxis,
    selectCartesianItemsSettingsExceptStacked,
    selectAllErrorBarSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataSliceIfNotInPanorama"]
], combineDomainOfAllAppliedNumericalValuesIncludingErrorValues, {
    memoizeOptions: {
        resultEqualityCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$numberDomainEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["numberDomainEqualityCheck"]
    }
});
function onlyAllowNumbersAndStringsAndDates(item) {
    var { value } = item;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumOrStr"])(value) || value instanceof Date) {
        return value;
    }
    return undefined;
}
var computeDomainOfTypeCategory = (allDataSquished, axisSettings, isCategorical)=>{
    var categoricalDomain = allDataSquished.map(onlyAllowNumbersAndStringsAndDates).filter((v)=>v != null);
    if (isCategorical && (axisSettings.dataKey == null || axisSettings.allowDuplicatedCategory && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasDuplicate"])(categoricalDomain))) {
        /*
     * 1. In an absence of dataKey, Recharts will use array indexes as its categorical domain
     * 2. When category axis has duplicated text, serial numbers are used to generate scale
     */ return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$es$2d$toolkit$2f$compat$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(0, allDataSquished.length);
    }
    if (axisSettings.allowDuplicatedCategory) {
        return categoricalDomain;
    }
    return Array.from(new Set(categoricalDomain));
};
var selectReferenceDots = (state)=>state.referenceElements.dots;
var filterReferenceElements = (elements, axisType, axisId)=>{
    return elements.filter((el)=>el.ifOverflow === 'extendDomain').filter((el)=>{
        if (axisType === 'xAxis') {
            return el.xAxisId === axisId;
        }
        return el.yAxisId === axisId;
    });
};
var selectReferenceDotsByAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectReferenceDots,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisId"]
], filterReferenceElements);
var selectReferenceAreas = (state)=>state.referenceElements.areas;
var selectReferenceAreasByAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectReferenceAreas,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisId"]
], filterReferenceElements);
var selectReferenceLines = (state)=>state.referenceElements.lines;
var selectReferenceLinesByAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectReferenceLines,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisId"]
], filterReferenceElements);
var combineDotsDomain = (dots, axisType)=>{
    if (dots == null) {
        return undefined;
    }
    var allCoords = onlyAllowNumbers(dots.map((dot)=>axisType === 'xAxis' ? dot.x : dot.y));
    if (allCoords.length === 0) {
        return undefined;
    }
    return [
        Math.min(...allCoords),
        Math.max(...allCoords)
    ];
};
var selectReferenceDotsDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(selectReferenceDotsByAxis, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"], combineDotsDomain);
var combineAreasDomain = (areas, axisType)=>{
    if (areas == null) {
        return undefined;
    }
    var allCoords = onlyAllowNumbers(areas.flatMap((area)=>[
            axisType === 'xAxis' ? area.x1 : area.y1,
            axisType === 'xAxis' ? area.x2 : area.y2
        ]));
    if (allCoords.length === 0) {
        return undefined;
    }
    return [
        Math.min(...allCoords),
        Math.max(...allCoords)
    ];
};
var selectReferenceAreasDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectReferenceAreasByAxis,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], combineAreasDomain);
function extractXCoordinates(line) {
    var _line$segment;
    if (line.x != null) {
        return onlyAllowNumbers([
            line.x
        ]);
    }
    var segmentCoordinates = (_line$segment = line.segment) === null || _line$segment === void 0 ? void 0 : _line$segment.map((s)=>s.x);
    if (segmentCoordinates == null || segmentCoordinates.length === 0) {
        return [];
    }
    return onlyAllowNumbers(segmentCoordinates);
}
function extractYCoordinates(line) {
    var _line$segment2;
    if (line.y != null) {
        return onlyAllowNumbers([
            line.y
        ]);
    }
    var segmentCoordinates = (_line$segment2 = line.segment) === null || _line$segment2 === void 0 ? void 0 : _line$segment2.map((s)=>s.y);
    if (segmentCoordinates == null || segmentCoordinates.length === 0) {
        return [];
    }
    return onlyAllowNumbers(segmentCoordinates);
}
var combineLinesDomain = (lines, axisType)=>{
    if (lines == null) {
        return undefined;
    }
    var allCoords = lines.flatMap((line)=>axisType === 'xAxis' ? extractXCoordinates(line) : extractYCoordinates(line));
    if (allCoords.length === 0) {
        return undefined;
    }
    return [
        Math.min(...allCoords),
        Math.max(...allCoords)
    ];
};
var selectReferenceLinesDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectReferenceLinesByAxis,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], combineLinesDomain);
var selectReferenceElementsDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(selectReferenceDotsDomain, selectReferenceLinesDomain, selectReferenceAreasDomain, (dotsDomain, linesDomain, areasDomain)=>{
    return mergeDomains(dotsDomain, areasDomain, linesDomain);
});
var combineNumericalDomain = (axisSettings, domainDefinition, domainFromUserPreference, domainOfStackGroups, dataAndErrorBarsDomain, referenceElementsDomain, layout, axisType)=>{
    if (domainFromUserPreference != null) {
        // We're done! No need to compute anything else.
        return domainFromUserPreference;
    }
    var shouldIncludeDomainOfStackGroups = layout === 'vertical' && axisType === 'xAxis' || layout === 'horizontal' && axisType === 'yAxis';
    var mergedDomains = shouldIncludeDomainOfStackGroups ? mergeDomains(domainOfStackGroups, referenceElementsDomain, dataAndErrorBarsDomain) : mergeDomains(referenceElementsDomain, dataAndErrorBarsDomain);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseNumericalUserDomain"])(domainDefinition, mergedDomains, axisSettings.allowDataOverflow);
};
var selectNumericalDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBaseAxis,
    selectDomainDefinition,
    selectDomainFromUserPreference,
    selectDomainOfStackGroups,
    selectDomainOfAllAppliedNumericalValuesIncludingErrorValues,
    selectReferenceElementsDomain,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], combineNumericalDomain, {
    memoizeOptions: {
        resultEqualityCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$numberDomainEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["numberDomainEqualityCheck"]
    }
});
/**
 * Expand by design maps everything between 0 and 1,
 * there is nothing to compute.
 * See https://d3js.org/d3-shape/stack#stack-offsets
 */ var expandDomain = [
    0,
    1
];
var combineAxisDomain = (axisSettings, layout, displayedData, allAppliedValues, stackOffsetType, axisType, numericalDomain)=>{
    if ((axisSettings == null || displayedData == null || displayedData.length === 0) && numericalDomain === undefined) {
        return undefined;
    }
    var { dataKey, type } = axisSettings;
    var isCategorical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCategoricalAxis"])(layout, axisType);
    if (isCategorical && dataKey == null) {
        var _displayedData$length;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$es$2d$toolkit$2f$compat$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(0, (_displayedData$length = displayedData === null || displayedData === void 0 ? void 0 : displayedData.length) !== null && _displayedData$length !== void 0 ? _displayedData$length : 0);
    }
    if (type === 'category') {
        return computeDomainOfTypeCategory(allAppliedValues, axisSettings, isCategorical);
    }
    if (stackOffsetType === 'expand' && !isCategorical) {
        return expandDomain;
    }
    return numericalDomain;
};
var selectAxisDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBaseAxis,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectDisplayedData,
    selectAllAppliedValues,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectStackOffsetType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"],
    selectNumericalDomain
], combineAxisDomain);
var selectRealScaleType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBaseAxis,
    selectHasBar,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartName"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineRealScaleType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineRealScaleType"]);
var combineNiceTicks = (axisDomain, axisSettings, realScaleType)=>{
    var { niceTicks } = axisSettings;
    if (niceTicks === 'none') {
        return undefined;
    }
    var domainDefinition = getDomainDefinition(axisSettings);
    var hasDomainAutoKeyword = Array.isArray(domainDefinition) && (domainDefinition[0] === 'auto' || domainDefinition[1] === 'auto');
    if ((niceTicks === 'snap125' || niceTicks === 'adaptive') && axisSettings != null && axisSettings.tickCount && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellFormedNumberDomain"])(axisDomain)) {
        if (hasDomainAutoKeyword) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$getNiceTickValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNiceTickValues"])(axisDomain, axisSettings.tickCount, axisSettings.allowDecimals, niceTicks);
        }
        if (axisSettings.type === 'number') {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$getNiceTickValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTickValuesFixedDomain"])(axisDomain, axisSettings.tickCount, axisSettings.allowDecimals, niceTicks);
        }
    }
    if (niceTicks === 'auto' && realScaleType === 'linear' && axisSettings != null && axisSettings.tickCount) {
        // Current magic-selector behaviour: apply nice ticks when the domain contains
        // an 'auto' keyword (may extend the domain), or for any fixed number-type axis.
        // Always uses the space-efficient algorithm (adaptive).
        if (hasDomainAutoKeyword && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellFormedNumberDomain"])(axisDomain)) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$getNiceTickValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNiceTickValues"])(axisDomain, axisSettings.tickCount, axisSettings.allowDecimals, 'adaptive');
        }
        if (axisSettings.type === 'number' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellFormedNumberDomain"])(axisDomain)) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$getNiceTickValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTickValuesFixedDomain"])(axisDomain, axisSettings.tickCount, axisSettings.allowDecimals, 'adaptive');
        }
    }
    return undefined;
};
var selectNiceTicks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAxisDomain,
    selectRenderableAxisSettings,
    selectRealScaleType
], combineNiceTicks);
var combineAxisDomainWithNiceTicks = (axisSettings, domain, niceTicks, axisType)=>{
    if (/*
   * Angle axis for some reason uses nice ticks when rendering axis tick labels,
   * but doesn't use nice ticks for extending domain like all the other axes do.
   * Not really sure why? Is there a good reason,
   * or is it just because someone added support for nice ticks to the other axes and forgot this one?
   */ axisType !== 'angleAxis' && (axisSettings === null || axisSettings === void 0 ? void 0 : axisSettings.type) === 'number' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellFormedNumberDomain"])(domain) && Array.isArray(niceTicks) && niceTicks.length > 0) {
        var _niceTicks$, _niceTicks;
        var minFromDomain = domain[0];
        var minFromTicks = (_niceTicks$ = niceTicks[0]) !== null && _niceTicks$ !== void 0 ? _niceTicks$ : 0;
        var maxFromDomain = domain[1];
        var maxFromTicks = (_niceTicks = niceTicks[niceTicks.length - 1]) !== null && _niceTicks !== void 0 ? _niceTicks : 0;
        return [
            Math.min(minFromDomain, minFromTicks),
            Math.max(maxFromDomain, maxFromTicks)
        ];
    }
    return domain;
};
var selectAxisDomainIncludingNiceTicks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBaseAxis,
    selectAxisDomain,
    selectNiceTicks,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], combineAxisDomainWithNiceTicks);
var selectSmallestDistanceBetweenValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(selectAllAppliedValues, selectBaseAxis, (allDataSquished, axisSettings)=>{
    if (!axisSettings || axisSettings.type !== 'number') {
        return undefined;
    }
    var smallestDistanceBetweenValues = Infinity;
    var sortedValues = Array.from(onlyAllowNumbers(allDataSquished.map((d)=>d.value))).sort((a, b)=>a - b);
    var first = sortedValues[0];
    var last = sortedValues[sortedValues.length - 1];
    if (first == null || last == null) {
        return Infinity;
    }
    var diff = last - first;
    if (diff === 0) {
        return Infinity;
    }
    // Only do n - 1 distance calculations because there's only n - 1 distances between n values.
    for(var i = 0; i < sortedValues.length - 1; i++){
        var curr = sortedValues[i];
        var next = sortedValues[i + 1];
        if (curr == null || next == null) {
            continue;
        }
        var distance = next - curr;
        smallestDistanceBetweenValues = Math.min(smallestDistanceBetweenValues, distance);
    }
    return smallestDistanceBetweenValues / diff;
});
var selectCalculatedPadding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(selectSmallestDistanceBetweenValues, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectBarCategoryGap"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"], (_1, _2, _3, _4, padding)=>padding, (smallestDistanceInPercent, layout, barCategoryGap, offset, padding)=>{
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(smallestDistanceInPercent)) {
        return 0;
    }
    var rangeWidth = layout === 'vertical' ? offset.height : offset.width;
    if (padding === 'gap') {
        return smallestDistanceInPercent * rangeWidth / 2;
    }
    if (padding === 'no-gap') {
        var gap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPercentValue"])(barCategoryGap, smallestDistanceInPercent * rangeWidth);
        var halfBand = smallestDistanceInPercent * rangeWidth / 2;
        return halfBand - gap - (halfBand - gap) / rangeWidth * gap;
    }
    return 0;
});
var selectCalculatedXAxisPadding = (state, axisId, isPanorama)=>{
    var xAxisSettings = selectXAxisSettings(state, axisId);
    if (xAxisSettings == null || typeof xAxisSettings.padding !== 'string') {
        return 0;
    }
    return selectCalculatedPadding(state, 'xAxis', axisId, isPanorama, xAxisSettings.padding);
};
var selectCalculatedYAxisPadding = (state, axisId, isPanorama)=>{
    var yAxisSettings = selectYAxisSettings(state, axisId);
    if (yAxisSettings == null || typeof yAxisSettings.padding !== 'string') {
        return 0;
    }
    return selectCalculatedPadding(state, 'yAxis', axisId, isPanorama, yAxisSettings.padding);
};
var selectXAxisPadding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(selectXAxisSettings, selectCalculatedXAxisPadding, (xAxisSettings, calculated)=>{
    var _padding$left, _padding$right;
    if (xAxisSettings == null) {
        return {
            left: 0,
            right: 0
        };
    }
    var { padding } = xAxisSettings;
    if (typeof padding === 'string') {
        return {
            left: calculated,
            right: calculated
        };
    }
    return {
        left: ((_padding$left = padding.left) !== null && _padding$left !== void 0 ? _padding$left : 0) + calculated,
        right: ((_padding$right = padding.right) !== null && _padding$right !== void 0 ? _padding$right : 0) + calculated
    };
});
var selectYAxisPadding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(selectYAxisSettings, selectCalculatedYAxisPadding, (yAxisSettings, calculated)=>{
    var _padding$top, _padding$bottom;
    if (yAxisSettings == null) {
        return {
            top: 0,
            bottom: 0
        };
    }
    var { padding } = yAxisSettings;
    if (typeof padding === 'string') {
        return {
            top: calculated,
            bottom: calculated
        };
    }
    return {
        top: ((_padding$top = padding.top) !== null && _padding$top !== void 0 ? _padding$top : 0) + calculated,
        bottom: ((_padding$bottom = padding.bottom) !== null && _padding$bottom !== void 0 ? _padding$bottom : 0) + calculated
    };
});
var selectXAxisRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"],
    selectXAxisPadding,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$brushSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectBrushDimensions"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$brushSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectBrushSettings"],
    (_state, _axisId, isPanorama)=>isPanorama
], (offset, padding, brushDimensions, _ref5, isPanorama)=>{
    var { padding: brushPadding } = _ref5;
    if (isPanorama) {
        return [
            brushPadding.left,
            brushDimensions.width - brushPadding.right
        ];
    }
    return [
        offset.left + padding.left,
        offset.left + offset.width - padding.right
    ];
});
var selectYAxisRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectYAxisPadding,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$brushSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectBrushDimensions"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$brushSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectBrushSettings"],
    (_state, _axisId, isPanorama)=>isPanorama
], (offset, layout, padding, brushDimensions, _ref6, isPanorama)=>{
    var { padding: brushPadding } = _ref6;
    if (isPanorama) {
        return [
            brushDimensions.height - brushPadding.bottom,
            brushPadding.top
        ];
    }
    if (layout === 'horizontal') {
        return [
            offset.top + offset.height - padding.bottom,
            offset.top + padding.top
        ];
    }
    return [
        offset.top + padding.top,
        offset.top + offset.height - padding.bottom
    ];
});
var selectAxisRange = (state, axisType, axisId, isPanorama)=>{
    var _selectZAxisSettings;
    switch(axisType){
        case 'xAxis':
            return selectXAxisRange(state, axisId, isPanorama);
        case 'yAxis':
            return selectYAxisRange(state, axisId, isPanorama);
        case 'zAxis':
            return (_selectZAxisSettings = selectZAxisSettings(state, axisId)) === null || _selectZAxisSettings === void 0 ? void 0 : _selectZAxisSettings.range;
        case 'angleAxis':
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$polarAxisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAngleAxisRange"])(state);
        case 'radiusAxis':
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$polarAxisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectRadiusAxisRange"])(state, axisId);
        default:
            return undefined;
    }
};
var selectAxisRangeWithReverse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBaseAxis,
    selectAxisRange
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineAxisRangeWithReverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineAxisRangeWithReverse"]);
var selectCheckedAxisDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectRealScaleType,
    selectAxisDomainIncludingNiceTicks
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineCheckedDomain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineCheckedDomain"]);
var selectConfiguredScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBaseAxis,
    selectRealScaleType,
    selectCheckedAxisDomain,
    selectAxisRangeWithReverse
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineConfiguredScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineConfiguredScale"]);
var combineCategoricalDomain = (layout, appliedValues, axis, axisType)=>{
    if (axis == null || axis.dataKey == null) {
        return undefined;
    }
    var { type, scale } = axis;
    var isCategorical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCategoricalAxis"])(layout, axisType);
    if (isCategorical && (type === 'number' || scale !== 'auto')) {
        return appliedValues.map((d)=>d.value);
    }
    return undefined;
};
var selectCategoricalDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectAllAppliedValues,
    selectRenderableAxisSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], combineCategoricalDomain);
var selectAxisScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectConfiguredScale
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$RechartsScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rechartsScaleFactory"]);
var selectAxisInverseScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectConfiguredScale
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineInverseScaleFunction$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineInverseScaleFunction"]);
var selectAxisInverseDataSnapScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectConfiguredScale,
    selectSortedDataPoints
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$createCategoricalInverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCategoricalInverse"]);
var selectErrorBarsSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectCartesianItemsSettings,
    selectAllErrorBarSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], combineRelevantErrorBarSettings);
function compareIds(a, b) {
    if (a.id < b.id) {
        return -1;
    }
    if (a.id > b.id) {
        return 1;
    }
    return 0;
}
var pickAxisOrientation = (_state, orientation)=>orientation;
var pickMirror = (_state, _orientation, mirror)=>mirror;
var selectAllXAxesWithOffsetType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllXAxes"], pickAxisOrientation, pickMirror, (allAxes, orientation, mirror)=>allAxes.filter((axis)=>axis.orientation === orientation).filter((axis)=>axis.mirror === mirror).sort(compareIds));
var selectAllYAxesWithOffsetType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllYAxes"], pickAxisOrientation, pickMirror, (allAxes, orientation, mirror)=>allAxes.filter((axis)=>axis.orientation === orientation).filter((axis)=>axis.mirror === mirror).sort(compareIds));
var getXAxisSize = (offset, axisSettings)=>{
    return {
        width: offset.width,
        height: axisSettings.height
    };
};
var getYAxisSize = (offset, axisSettings)=>{
    var width = typeof axisSettings.width === 'number' ? axisSettings.width : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_Y_AXIS_WIDTH"];
    return {
        width,
        height: offset.height
    };
};
var selectXAxisSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"], selectXAxisSettings, getXAxisSize);
var combineXAxisPositionStartingPoint = (offset, orientation, chartHeight)=>{
    switch(orientation){
        case 'top':
            return offset.top;
        case 'bottom':
            return chartHeight - offset.bottom;
        default:
            return 0;
    }
};
var combineYAxisPositionStartingPoint = (offset, orientation, chartWidth)=>{
    switch(orientation){
        case 'left':
            return offset.left;
        case 'right':
            return chartWidth - offset.right;
        default:
            return 0;
    }
};
var selectAllXAxesOffsetSteps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartHeight"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"], selectAllXAxesWithOffsetType, pickAxisOrientation, pickMirror, (chartHeight, offset, allAxesWithSameOffsetType, orientation, mirror)=>{
    var steps = {};
    var position;
    allAxesWithSameOffsetType.forEach((axis)=>{
        var axisSize = getXAxisSize(offset, axis);
        if (position == null) {
            position = combineXAxisPositionStartingPoint(offset, orientation, chartHeight);
        }
        var needSpace = orientation === 'top' && !mirror || orientation === 'bottom' && mirror;
        steps[axis.id] = position - Number(needSpace) * axisSize.height;
        position += (needSpace ? -1 : 1) * axisSize.height;
    });
    return steps;
});
var selectAllYAxesOffsetSteps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartWidth"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"], selectAllYAxesWithOffsetType, pickAxisOrientation, pickMirror, (chartWidth, offset, allAxesWithSameOffsetType, orientation, mirror)=>{
    var steps = {};
    var position;
    allAxesWithSameOffsetType.forEach((axis)=>{
        var axisSize = getYAxisSize(offset, axis);
        if (position == null) {
            position = combineYAxisPositionStartingPoint(offset, orientation, chartWidth);
        }
        var needSpace = orientation === 'left' && !mirror || orientation === 'right' && mirror;
        steps[axis.id] = position - Number(needSpace) * axisSize.width;
        position += (needSpace ? -1 : 1) * axisSize.width;
    });
    return steps;
});
var selectXAxisOffsetSteps = (state, axisId)=>{
    var axisSettings = selectXAxisSettings(state, axisId);
    if (axisSettings == null) {
        return undefined;
    }
    return selectAllXAxesOffsetSteps(state, axisSettings.orientation, axisSettings.mirror);
};
var selectXAxisPosition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"],
    selectXAxisSettings,
    selectXAxisOffsetSteps,
    (_, axisId)=>axisId
], (offset, axisSettings, allSteps, axisId)=>{
    if (axisSettings == null) {
        return undefined;
    }
    var stepOfThisAxis = allSteps === null || allSteps === void 0 ? void 0 : allSteps[axisId];
    if (stepOfThisAxis == null) {
        return {
            x: offset.left,
            y: 0
        };
    }
    return {
        x: offset.left,
        y: stepOfThisAxis
    };
});
var selectYAxisOffsetSteps = (state, axisId)=>{
    var axisSettings = selectYAxisSettings(state, axisId);
    if (axisSettings == null) {
        return undefined;
    }
    return selectAllYAxesOffsetSteps(state, axisSettings.orientation, axisSettings.mirror);
};
var selectYAxisPosition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"],
    selectYAxisSettings,
    selectYAxisOffsetSteps,
    (_, axisId)=>axisId
], (offset, axisSettings, allSteps, axisId)=>{
    if (axisSettings == null) {
        return undefined;
    }
    var stepOfThisAxis = allSteps === null || allSteps === void 0 ? void 0 : allSteps[axisId];
    if (stepOfThisAxis == null) {
        return {
            x: 0,
            y: offset.top
        };
    }
    return {
        x: stepOfThisAxis,
        y: offset.top
    };
});
var selectYAxisSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"], selectYAxisSettings, (offset, axisSettings)=>{
    var width = typeof axisSettings.width === 'number' ? axisSettings.width : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_Y_AXIS_WIDTH"];
    return {
        width,
        height: offset.height
    };
});
var selectCartesianAxisSize = (state, axisType, axisId)=>{
    switch(axisType){
        case 'xAxis':
            {
                return selectXAxisSize(state, axisId).width;
            }
        case 'yAxis':
            {
                return selectYAxisSize(state, axisId).height;
            }
        default:
            {
                return undefined;
            }
    }
};
var combineDuplicateDomain = (chartLayout, appliedValues, axis, axisType)=>{
    if (axis == null) {
        return undefined;
    }
    var { allowDuplicatedCategory, type, dataKey } = axis;
    var isCategorical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCategoricalAxis"])(chartLayout, axisType);
    var allData = appliedValues.map((av)=>av.value);
    var validData = allData.filter((v)=>v != null);
    if (dataKey && isCategorical && type === 'category' && allowDuplicatedCategory && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasDuplicate"])(validData)) {
        return allData;
    }
    return undefined;
};
var selectDuplicateDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectAllAppliedValues,
    selectBaseAxis,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], combineDuplicateDomain);
var selectAxisPropsNeededForCartesianGridTicksGenerator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectCartesianAxisSettings,
    selectRealScaleType,
    selectAxisScale,
    selectDuplicateDomain,
    selectCategoricalDomain,
    selectAxisRange,
    selectNiceTicks,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], (layout, axis, realScaleType, scale, duplicateDomain, categoricalDomain, axisRange, niceTicks, axisType)=>{
    if (axis == null) {
        return undefined;
    }
    var isCategorical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCategoricalAxis"])(layout, axisType);
    return {
        angle: axis.angle,
        interval: axis.interval,
        minTickGap: axis.minTickGap,
        orientation: axis.orientation,
        tick: axis.tick,
        tickCount: axis.tickCount,
        tickFormatter: axis.tickFormatter,
        ticks: axis.ticks,
        type: axis.type,
        unit: axis.unit,
        axisType,
        categoricalDomain,
        duplicateDomain,
        isCategorical,
        niceTicks,
        range: axisRange,
        realScaleType,
        scale
    };
});
var combineAxisTicks = (layout, axis, realScaleType, scale, niceTicks, axisRange, duplicateDomain, categoricalDomain, axisType)=>{
    if (axis == null || scale == null) {
        return undefined;
    }
    var isCategorical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCategoricalAxis"])(layout, axisType);
    var { type, ticks, tickCount } = axis;
    var offsetForBand = // @ts-expect-error This is testing for `scaleBand` but for band axis the type is reported as `band` so this looks like a dead code with a workaround elsewhere?
    realScaleType === 'scaleBand' && typeof scale.bandwidth === 'function' ? scale.bandwidth() / 2 : 2;
    var offset = type === 'category' && scale.bandwidth ? scale.bandwidth() / offsetForBand : 0;
    offset = axisType === 'angleAxis' && axisRange != null && axisRange.length >= 2 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathSign"])(axisRange[0] - axisRange[1]) * 2 * offset : offset;
    // The ticks set by user should only affect the ticks adjacent to axis line
    var ticksOrNiceTicks = ticks || niceTicks;
    if (ticksOrNiceTicks) {
        return ticksOrNiceTicks.map((entry, index)=>{
            var scaleContent = duplicateDomain ? duplicateDomain.indexOf(entry) : entry;
            var scaled = scale.map(scaleContent);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(scaled)) {
                return null;
            }
            return {
                index,
                coordinate: scaled + offset,
                value: entry,
                offset
            };
        }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
    }
    // When axis is a categorical axis, but the type of axis is not number and scale is not "auto"
    // For type='number' with linear scale (where niceTicks are available), skip this branch
    // so ticks are evenly spaced instead of placed at data positions (GitHub issue #4271)
    if (isCategorical && categoricalDomain) {
        return categoricalDomain.map((entry, index)=>{
            var scaled = scale.map(entry);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(scaled)) {
                return null;
            }
            return {
                coordinate: scaled + offset,
                value: entry,
                index,
                offset
            };
        }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
    }
    if (scale.ticks) {
        return scale.ticks(tickCount).map((entry, index)=>{
            var scaled = scale.map(entry);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(scaled)) {
                return null;
            }
            return {
                coordinate: scaled + offset,
                value: entry,
                index,
                offset
            };
        }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
    }
    // When axis has duplicated text, serial numbers are used to generate scale
    return scale.domain().map((entry, index)=>{
        var scaled = scale.map(entry);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(scaled)) {
            return null;
        }
        return {
            coordinate: scaled + offset,
            // @ts-expect-error can't use Date as index
            value: duplicateDomain ? duplicateDomain[entry] : entry,
            index,
            offset
        };
    }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
};
var selectTicksOfAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectRenderableAxisSettings,
    selectRealScaleType,
    selectAxisScale,
    selectNiceTicks,
    selectAxisRange,
    selectDuplicateDomain,
    selectCategoricalDomain,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], combineAxisTicks);
var combineGraphicalItemTicks = (layout, axis, scale, axisRange, duplicateDomain, categoricalDomain, axisType)=>{
    if (axis == null || scale == null || axisRange == null || axisRange[0] === axisRange[1]) {
        return undefined;
    }
    var isCategorical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCategoricalAxis"])(layout, axisType);
    var { tickCount } = axis;
    var offset = 0;
    offset = axisType === 'angleAxis' && (axisRange === null || axisRange === void 0 ? void 0 : axisRange.length) >= 2 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathSign"])(axisRange[0] - axisRange[1]) * 2 * offset : offset;
    // When axis is a categorical axis, but the type of axis is number or the scale of axis is not "auto"
    if (isCategorical && categoricalDomain) {
        return categoricalDomain.map((entry, index)=>{
            var scaled = scale.map(entry);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(scaled)) {
                return null;
            }
            return {
                coordinate: scaled + offset,
                value: entry,
                index,
                offset
            };
        }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
    }
    if (scale.ticks) {
        return scale.ticks(tickCount).map((entry, index)=>{
            var scaled = scale.map(entry);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(scaled)) {
                return null;
            }
            return {
                coordinate: scaled + offset,
                value: entry,
                index,
                offset
            };
        }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
    }
    // When axis has duplicated text, serial numbers are used to generate scale
    return scale.domain().map((entry, index)=>{
        var scaled = scale.map(entry);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(scaled)) {
            return null;
        }
        return {
            coordinate: scaled + offset,
            // @ts-expect-error can't use unknown as index
            value: duplicateDomain ? duplicateDomain[entry] : entry,
            index,
            offset
        };
    }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
};
var selectTicksOfGraphicalItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectRenderableAxisSettings,
    selectAxisScale,
    selectAxisRange,
    selectDuplicateDomain,
    selectCategoricalDomain,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$pickAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickAxisType"]
], combineGraphicalItemTicks);
var selectAxisWithScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(selectBaseAxis, selectAxisScale, (axis, scale)=>{
    if (axis == null || scale == null) {
        return undefined;
    }
    return _objectSpread(_objectSpread({}, axis), {}, {
        scale
    });
});
var selectZAxisConfiguredScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectBaseAxis,
    selectRealScaleType,
    selectAxisDomain,
    selectAxisRangeWithReverse
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineConfiguredScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineConfiguredScale"]);
var selectZAxisScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectZAxisConfiguredScale
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$RechartsScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rechartsScaleFactory"]);
var selectZAxisWithScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])((state, _axisType, axisId)=>selectZAxisSettings(state, axisId), selectZAxisScale, (axis, scale)=>{
    if (axis == null || scale == null) {
        return undefined;
    }
    return _objectSpread(_objectSpread({}, axis), {}, {
        scale
    });
});
var selectChartDirection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllXAxes"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectAllAxes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllYAxes"]
], (layout, allXAxes, allYAxes)=>{
    switch(layout){
        case 'horizontal':
            {
                return allXAxes.some((axis)=>axis.reversed) ? 'right-to-left' : 'left-to-right';
            }
        case 'vertical':
            {
                return allYAxes.some((axis)=>axis.reversed) ? 'bottom-to-top' : 'top-to-bottom';
            }
        // TODO: make this better. For now, right arrow triggers "forward", left arrow "back"
        // however, the tooltip moves an unintuitive direction because of how the indices are rendered
        case 'centric':
        case 'radial':
            {
                return 'left-to-right';
            }
        default:
            {
                return undefined;
            }
    }
});
var selectRenderedTicksOfAxis = (state, axisType, axisId)=>{
    var _state$renderedTicks$;
    return (_state$renderedTicks$ = state.renderedTicks[axisType]) === null || _state$renderedTicks$ === void 0 ? void 0 : _state$renderedTicks$[axisId];
};
var selectAxisInverseTickSnapScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectRenderedTicksOfAxis
], (ticks)=>{
    if (!ticks || ticks.length === 0) {
        return undefined;
    }
    return (pixelValue)=>{
        var _closestTick;
        // Find the tick with the closest coordinate to pixelValue
        var minDistance = Infinity;
        var closestTick = ticks[0];
        for (var tick of ticks){
            var distance = Math.abs(tick.coordinate - pixelValue);
            if (distance < minDistance) {
                minDistance = distance;
                closestTick = tick;
            }
        }
        return (_closestTick = closestTick) === null || _closestTick === void 0 ? void 0 : _closestTick.value;
    };
});
}),
"[project]/node_modules/recharts/es6/state/selectors/selectTooltipEventType.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineTooltipEventType",
    ()=>combineTooltipEventType,
    "selectDefaultTooltipEventType",
    ()=>selectDefaultTooltipEventType,
    "selectTooltipEventType",
    ()=>selectTooltipEventType,
    "selectValidateTooltipEventTypes",
    ()=>selectValidateTooltipEventTypes,
    "useTooltipEventType",
    ()=>useTooltipEventType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/hooks.js [app-client] (ecmascript)");
;
var selectDefaultTooltipEventType = (state)=>state.options.defaultTooltipEventType;
var selectValidateTooltipEventTypes = (state)=>state.options.validateTooltipEventTypes;
function combineTooltipEventType(shared, defaultTooltipEventType, validateTooltipEventTypes) {
    if (shared == null) {
        return defaultTooltipEventType;
    }
    var eventType = shared ? 'axis' : 'item';
    if (validateTooltipEventTypes == null) {
        return defaultTooltipEventType;
    }
    return validateTooltipEventTypes.includes(eventType) ? eventType : defaultTooltipEventType;
}
function selectTooltipEventType(state, shared) {
    var defaultTooltipEventType = selectDefaultTooltipEventType(state);
    var validateTooltipEventTypes = selectValidateTooltipEventTypes(state);
    return combineTooltipEventType(shared, defaultTooltipEventType, validateTooltipEventTypes);
}
function useTooltipEventType(shared) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppSelector"])({
        "useTooltipEventType.useAppSelector": (state)=>selectTooltipEventType(state, shared)
    }["useTooltipEventType.useAppSelector"]);
}
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineActiveLabel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineActiveLabel",
    ()=>combineActiveLabel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/DataUtils.js [app-client] (ecmascript)");
;
var combineActiveLabel = (tooltipTicks, activeIndex)=>{
    var _tooltipTicks$n;
    var n = Number(activeIndex);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNan"])(n) || activeIndex == null) {
        return undefined;
    }
    return n >= 0 ? tooltipTicks === null || tooltipTicks === void 0 || (_tooltipTicks$n = tooltipTicks[n]) === null || _tooltipTicks$n === void 0 ? void 0 : _tooltipTicks$n.value : undefined;
};
}),
"[project]/node_modules/recharts/es6/state/selectors/selectTooltipSettings.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectTooltipSettings",
    ()=>selectTooltipSettings
]);
var selectTooltipSettings = (state)=>state.tooltip.settings;
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineTooltipInteractionState.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineTooltipInteractionState",
    ()=>combineTooltipInteractionState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/tooltipSlice.js [app-client] (ecmascript)");
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
function chooseAppropriateMouseInteraction(tooltipState, tooltipEventType, trigger) {
    if (tooltipEventType === 'axis') {
        if (trigger === 'click') {
            return tooltipState.axisInteraction.click;
        }
        return tooltipState.axisInteraction.hover;
    }
    if (trigger === 'click') {
        return tooltipState.itemInteraction.click;
    }
    return tooltipState.itemInteraction.hover;
}
function hasBeenActivePreviously(tooltipInteractionState) {
    return tooltipInteractionState.index != null;
}
var combineTooltipInteractionState = (tooltipState, tooltipEventType, trigger, defaultIndex)=>{
    if (tooltipEventType == null) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noInteraction"];
    }
    var appropriateMouseInteraction = chooseAppropriateMouseInteraction(tooltipState, tooltipEventType, trigger);
    if (appropriateMouseInteraction == null) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noInteraction"];
    }
    if (appropriateMouseInteraction.active) {
        return appropriateMouseInteraction;
    }
    if (tooltipState.keyboardInteraction.active) {
        return tooltipState.keyboardInteraction;
    }
    if (tooltipState.syncInteraction.active && tooltipState.syncInteraction.index != null) {
        return tooltipState.syncInteraction;
    }
    var activeFromProps = tooltipState.settings.active === true;
    if (hasBeenActivePreviously(appropriateMouseInteraction)) {
        if (activeFromProps) {
            return _objectSpread(_objectSpread({}, appropriateMouseInteraction), {}, {
                active: true
            });
        }
    } else if (defaultIndex != null) {
        return {
            active: true,
            coordinate: undefined,
            dataKey: undefined,
            index: defaultIndex,
            graphicalItemId: undefined
        };
    }
    return _objectSpread(_objectSpread({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noInteraction"]), {}, {
        coordinate: appropriateMouseInteraction.coordinate
    });
};
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineActiveTooltipIndex.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineActiveTooltipIndex",
    ()=>combineActiveTooltipIndex
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/isWellBehavedNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/ChartUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/isDomainSpecifiedByUser.js [app-client] (ecmascript)");
;
;
;
function toFiniteNumber(value) {
    if (typeof value === 'number') {
        return Number.isFinite(value) ? value : undefined;
    }
    if (value instanceof Date) {
        var numericValue = value.valueOf();
        return Number.isFinite(numericValue) ? numericValue : undefined;
    }
    var parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : undefined;
}
function isValueWithinNumberDomain(value, domain) {
    var numericValue = toFiniteNumber(value);
    var lowerBound = domain[0];
    var upperBound = domain[1];
    if (numericValue === undefined) {
        return false;
    }
    var min = Math.min(lowerBound, upperBound);
    var max = Math.max(lowerBound, upperBound);
    return numericValue >= min && numericValue <= max;
}
function isValueWithinDomain(entry, axisDataKey, domain) {
    if (domain == null || axisDataKey == null) {
        return true;
    }
    var value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(entry, axisDataKey);
    if (value == null) {
        return true;
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellFormedNumberDomain"])(domain)) {
        return true;
    }
    return isValueWithinNumberDomain(value, domain);
}
var combineActiveTooltipIndex = (tooltipInteraction, chartData, axisDataKey, domain)=>{
    var desiredIndex = tooltipInteraction === null || tooltipInteraction === void 0 ? void 0 : tooltipInteraction.index;
    if (desiredIndex == null) {
        return null;
    }
    var indexAsNumber = Number(desiredIndex);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(indexAsNumber)) {
        // this is for charts like Sankey and Treemap that do not support numerical indexes. We need a proper solution for this before we can start supporting keyboard events on these charts.
        return desiredIndex;
    }
    /*
   * Zero is a trivial limit for single-dimensional charts like Line and Area,
   * but this also needs a support for multidimensional charts like Sankey and Treemap! TODO
   */ var lowerLimit = 0;
    var upperLimit = +Infinity;
    if (chartData.length > 0) {
        upperLimit = chartData.length - 1;
    }
    // now let's clamp the desiredIndex between the limits
    var clampedIndex = Math.max(lowerLimit, Math.min(indexAsNumber, upperLimit));
    var entry = chartData[clampedIndex];
    if (entry == null) {
        return String(clampedIndex);
    }
    if (!isValueWithinDomain(entry, axisDataKey, domain)) {
        return null;
    }
    return String(clampedIndex);
};
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineCoordinateForDefaultIndex.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineCoordinateForDefaultIndex",
    ()=>combineCoordinateForDefaultIndex
]);
var combineCoordinateForDefaultIndex = (width, height, layout, offset, tooltipTicks, defaultIndex, tooltipConfigurations)=>{
    if (defaultIndex == null) {
        return undefined;
    }
    /*
   * With defaultIndex alone, we don't have enough information to decide _which_ of the multiple tooltips to display.
   * Maybe one day we could add new prop `activeGraphicalItemId` to the chart to help with that.
   * Until then, we choose the first one.
   */ var firstConfiguration = tooltipConfigurations[0];
    var maybePosition = firstConfiguration === null || firstConfiguration === void 0 ? void 0 : firstConfiguration.getPosition(defaultIndex);
    if (maybePosition != null) {
        return maybePosition;
    }
    var tick = tooltipTicks === null || tooltipTicks === void 0 ? void 0 : tooltipTicks[Number(defaultIndex)];
    if (!tick) {
        return undefined;
    }
    switch(layout){
        case 'horizontal':
            {
                return {
                    x: tick.coordinate,
                    y: (offset.top + height) / 2
                };
            }
        default:
            {
                // This logic is not super sound - it conflates vertical, radial, centric layouts into just one. TODO improve!
                return {
                    x: (offset.left + width) / 2,
                    y: tick.coordinate
                };
            }
    }
};
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineTooltipPayloadConfigurations.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineTooltipPayloadConfigurations",
    ()=>combineTooltipPayloadConfigurations
]);
var combineTooltipPayloadConfigurations = (tooltipState, tooltipEventType, trigger, defaultIndex)=>{
    // if tooltip reacts to axis interaction, then we display all items at the same time.
    if (tooltipEventType === 'axis') {
        return tooltipState.tooltipItemPayloads;
    }
    /*
   * By now we already know that tooltipEventType is 'item', so we can only search in itemInteractions.
   * item means that only the hovered or clicked item will be present in the tooltip.
   */ if (tooltipState.tooltipItemPayloads.length === 0) {
        // No point filtering if the payload is empty
        return [];
    }
    var filterByGraphicalItemId;
    if (trigger === 'hover') {
        filterByGraphicalItemId = tooltipState.itemInteraction.hover.graphicalItemId;
    } else {
        filterByGraphicalItemId = tooltipState.itemInteraction.click.graphicalItemId;
    }
    if (tooltipState.syncInteraction.active && filterByGraphicalItemId == null) {
        /*
     * When a tooltip is synchronised from another chart, the local itemInteraction
     * has no graphicalItemId because the user hasn't hovered over this chart.
     * In that case we show all tooltip items so the receiving chart can display
     * its own data at the synced index — matching the behaviour of axis-type tooltips.
     */ return tooltipState.tooltipItemPayloads;
    }
    if (filterByGraphicalItemId == null && (defaultIndex != null || tooltipState.keyboardInteraction.active)) {
        /*
     * So when we use `defaultIndex` - we don't have a dataKey to filter by because user did not hover over anything yet.
     * In that case let's display the first item in the tooltip; after all, this is `item` interaction case,
     * so we should display only one item at a time instead of all.
     */ var firstItemPayload = tooltipState.tooltipItemPayloads[0];
        if (firstItemPayload != null) {
            return [
                firstItemPayload
            ];
        }
        return [];
    }
    return tooltipState.tooltipItemPayloads.filter((tpc)=>{
        var _tpc$settings;
        return ((_tpc$settings = tpc.settings) === null || _tpc$settings === void 0 ? void 0 : _tpc$settings.graphicalItemId) === filterByGraphicalItemId;
    });
};
}),
"[project]/node_modules/recharts/es6/state/selectors/selectTooltipPayloadSearcher.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectTooltipPayloadSearcher",
    ()=>selectTooltipPayloadSearcher
]);
var selectTooltipPayloadSearcher = (state)=>state.options.tooltipPayloadSearcher;
}),
"[project]/node_modules/recharts/es6/state/selectors/selectTooltipState.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectTooltipState",
    ()=>selectTooltipState
]);
var selectTooltipState = (state)=>state.tooltip;
}),
"[project]/node_modules/recharts/es6/state/selectors/combiners/combineTooltipPayload.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineTooltipPayload",
    ()=>combineTooltipPayload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/DataUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/ChartUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getSliced$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/getSliced.js [app-client] (ecmascript)");
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
;
;
function parseName(value) {
    if (typeof value === 'string' || typeof value === 'number') {
        return value;
    }
    return undefined;
}
function parseUnit(value) {
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
        return value;
    }
    return undefined;
}
function parseDataKey(value) {
    if (typeof value === 'string' || typeof value === 'number') {
        return value;
    }
    if (typeof value === 'function') {
        return (obj)=>value(obj);
    }
    return undefined;
}
function parseColor(value) {
    if (typeof value === 'string') {
        return value;
    }
    return undefined;
}
function parseTooltipPayloadItem(item) {
    if (item == null || typeof item !== 'object') {
        return undefined;
    }
    var name = 'name' in item ? parseName(item.name) : undefined;
    var unit = 'unit' in item ? parseUnit(item.unit) : undefined;
    var dataKey = 'dataKey' in item ? parseDataKey(item.dataKey) : undefined;
    var payload = 'payload' in item ? item.payload : undefined;
    var color = 'color' in item ? parseColor(item.color) : undefined;
    var fill = 'fill' in item ? parseColor(item.fill) : undefined;
    return {
        name,
        unit,
        dataKey,
        payload,
        color,
        fill
    };
}
function selectFinalData(dataDefinedOnItem, dataDefinedOnChart) {
    /*
   * If a payload has data specified directly from the graphical item, prefer that.
   * Otherwise, fill in data from the chart level, using the same index.
   */ if (dataDefinedOnItem != null) {
        return dataDefinedOnItem;
    }
    return dataDefinedOnChart;
}
var combineTooltipPayload = (tooltipPayloadConfigurations, activeIndex, chartDataState, tooltipAxisDataKey, activeLabel, tooltipPayloadSearcher, tooltipEventType)=>{
    if (activeIndex == null || tooltipPayloadSearcher == null) {
        return undefined;
    }
    var { chartData, computedData, dataStartIndex, dataEndIndex } = chartDataState;
    var init = [];
    return tooltipPayloadConfigurations.reduce((agg, _ref)=>{
        var _settings$dataKey;
        var { dataDefinedOnItem, settings } = _ref;
        var finalData = selectFinalData(dataDefinedOnItem, chartData);
        var sliced = Array.isArray(finalData) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getSliced$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSliced"])(finalData, dataStartIndex, dataEndIndex) : finalData;
        var finalDataKey = (_settings$dataKey = settings === null || settings === void 0 ? void 0 : settings.dataKey) !== null && _settings$dataKey !== void 0 ? _settings$dataKey : tooltipAxisDataKey;
        // BaseAxisProps does not support nameKey but it could!
        var finalNameKey = settings === null || settings === void 0 ? void 0 : settings.nameKey; // ?? tooltipAxis?.nameKey;
        var tooltipPayload;
        if (tooltipAxisDataKey && Array.isArray(sliced) && /*
     * findEntryInArray won't work for Scatter because Scatter provides an array of arrays
     * as tooltip payloads and findEntryInArray is not prepared to handle that.
     * Sad but also ScatterChart only allows 'item' tooltipEventType
     * and also this is only a problem if there are multiple Scatters and each has its own data array
     * so let's fix that some other time.
     */ !Array.isArray(sliced[0]) && /*
     * If the tooltipEventType is 'axis', we should search for the dataKey in the sliced data
     * because thanks to allowDuplicatedCategory=false, the order of elements in the array
     * no longer matches the order of elements in the original data
     * and so we need to search by the active dataKey + label rather than by index.
     *
     * The same happens if multiple graphical items are present in the chart
     * and each of them has its own data array. Those arrays get concatenated
     * and again the tooltip index no longer matches the original data.
     *
     * On the other hand the tooltipEventType 'item' should always search by index
     * because we get the index from interacting over the individual elements
     * which is always accurate, irrespective of the allowDuplicatedCategory setting.
     */ tooltipEventType === 'axis') {
            tooltipPayload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findEntryInArray"])(sliced, tooltipAxisDataKey, activeLabel);
        } else {
            /*
       * This is a problem because it assumes that the index is pointing to the displayed data
       * which it isn't because the index is pointing to the tooltip ticks array.
       * The above approach (with findEntryInArray) is the correct one, but it only works
       * if the axis dataKey is defined explicitly, and if the data is an array of objects.
       */ tooltipPayload = tooltipPayloadSearcher(sliced, activeIndex, computedData, finalNameKey);
        }
        if (Array.isArray(tooltipPayload)) {
            tooltipPayload.forEach((item)=>{
                var _parsedItem$color, _parsedItem$fill;
                var parsedItem = parseTooltipPayloadItem(item);
                var itemName = parsedItem === null || parsedItem === void 0 ? void 0 : parsedItem.name;
                var itemDataKey = parsedItem === null || parsedItem === void 0 ? void 0 : parsedItem.dataKey;
                var itemPayload = parsedItem === null || parsedItem === void 0 ? void 0 : parsedItem.payload;
                var newSettings = _objectSpread(_objectSpread({}, settings), {}, {
                    name: itemName,
                    unit: parsedItem === null || parsedItem === void 0 ? void 0 : parsedItem.unit,
                    // Preserve item-level color/fill from graphical items.
                    color: (_parsedItem$color = parsedItem === null || parsedItem === void 0 ? void 0 : parsedItem.color) !== null && _parsedItem$color !== void 0 ? _parsedItem$color : settings === null || settings === void 0 ? void 0 : settings.color,
                    fill: (_parsedItem$fill = parsedItem === null || parsedItem === void 0 ? void 0 : parsedItem.fill) !== null && _parsedItem$fill !== void 0 ? _parsedItem$fill : settings === null || settings === void 0 ? void 0 : settings.fill
                });
                agg.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTooltipEntry"])({
                    tooltipEntrySettings: newSettings,
                    dataKey: itemDataKey,
                    payload: itemPayload,
                    value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(itemPayload, itemDataKey),
                    name: itemName == null ? undefined : String(itemName)
                }));
            });
        } else {
            var _getValueByDataKey;
            // I am not quite sure why these two branches (Array vs Array of Arrays) have to behave differently - I imagine we should unify these. 3.x breaking change?
            agg.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTooltipEntry"])({
                tooltipEntrySettings: settings,
                dataKey: finalDataKey,
                payload: tooltipPayload,
                // getValueByDataKey does not validate the output type
                value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(tooltipPayload, finalDataKey),
                // getValueByDataKey does not validate the output type
                name: (_getValueByDataKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueByDataKey"])(tooltipPayload, finalNameKey)) !== null && _getValueByDataKey !== void 0 ? _getValueByDataKey : settings === null || settings === void 0 ? void 0 : settings.name
            }));
        }
        return agg;
    }, init);
};
}),
"[project]/node_modules/recharts/es6/state/selectors/tooltipSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectActiveLabel",
    ()=>selectActiveLabel,
    "selectActiveTooltipCoordinate",
    ()=>selectActiveTooltipCoordinate,
    "selectActiveTooltipDataKey",
    ()=>selectActiveTooltipDataKey,
    "selectActiveTooltipDataPoints",
    ()=>selectActiveTooltipDataPoints,
    "selectActiveTooltipGraphicalItemId",
    ()=>selectActiveTooltipGraphicalItemId,
    "selectActiveTooltipIndex",
    ()=>selectActiveTooltipIndex,
    "selectActiveTooltipPayload",
    ()=>selectActiveTooltipPayload,
    "selectAllGraphicalItemsSettings",
    ()=>selectAllGraphicalItemsSettings,
    "selectAllUnfilteredGraphicalItems",
    ()=>selectAllUnfilteredGraphicalItems,
    "selectIsTooltipActive",
    ()=>selectIsTooltipActive,
    "selectTooltipAxisDomain",
    ()=>selectTooltipAxisDomain,
    "selectTooltipAxisDomainIncludingNiceTicks",
    ()=>selectTooltipAxisDomainIncludingNiceTicks,
    "selectTooltipAxisRangeWithReverse",
    ()=>selectTooltipAxisRangeWithReverse,
    "selectTooltipAxisRealScaleType",
    ()=>selectTooltipAxisRealScaleType,
    "selectTooltipAxisScale",
    ()=>selectTooltipAxisScale,
    "selectTooltipAxisTicks",
    ()=>selectTooltipAxisTicks,
    "selectTooltipCategoricalDomain",
    ()=>selectTooltipCategoricalDomain,
    "selectTooltipDisplayedData",
    ()=>selectTooltipDisplayedData,
    "selectTooltipGraphicalItemsData",
    ()=>selectTooltipGraphicalItemsData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/axisSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/chartLayoutContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/ChartUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/dataSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/rootPropsSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/DataUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineAxisRangeWithReverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineAxisRangeWithReverse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipEventType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineActiveLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipSettings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipSettings.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipInteractionState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineTooltipInteractionState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveTooltipIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineActiveTooltipIndex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineCoordinateForDefaultIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineCoordinateForDefaultIndex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/containerSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectChartOffsetInternal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipPayloadConfigurations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineTooltipPayloadConfigurations.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipPayloadSearcher$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipPayloadSearcher.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipPayload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineTooltipPayload.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipAxisId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipAxisType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineDisplayedStackedData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineDisplayedStackedData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$types$2f$StackedGraphicalItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/types/StackedGraphicalItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/isDomainSpecifiedByUser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$numberDomainEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/numberDomainEqualityCheck.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$arrayEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/arrayEqualityCheck.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$RechartsScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/scale/RechartsScale.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/isWellBehavedNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineRealScaleType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineRealScaleType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineConfiguredScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineConfiguredScale.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var selectTooltipAxisRealScaleType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectHasBar"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartName"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineRealScaleType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineRealScaleType"]);
var selectAllUnfilteredGraphicalItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    (state)=>state.graphicalItems.cartesianItems,
    (state)=>state.graphicalItems.polarItems
], (cartesianItems, polarItems)=>[
        ...cartesianItems,
        ...polarItems
    ]);
var selectTooltipAxisPredicate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisId"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["itemAxisPredicate"]);
var selectAllGraphicalItemsSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllUnfilteredGraphicalItems,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    selectTooltipAxisPredicate
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineGraphicalItemsSettings"], {
    memoizeOptions: {
        resultEqualityCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$arrayEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyArraysAreEqualCheck"]
    }
});
var selectAllStackedGraphicalItemsSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllGraphicalItemsSettings
], (graphicalItems)=>graphicalItems.filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$types$2f$StackedGraphicalItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isStacked"]));
var selectTooltipGraphicalItemsData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllGraphicalItemsSettings
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineGraphicalItemsData"], {
    memoizeOptions: {
        resultEqualityCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$arrayEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emptyArraysAreEqualCheck"]
    }
});
var selectAnyTooltipItemUsesChartData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllGraphicalItemsSettings
], (items)=>items.some((item)=>!item.data));
var selectTooltipDisplayedData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipGraphicalItemsData,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexes"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineDisplayedData"]);
var selectTooltipStackedData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllStackedGraphicalItemsSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexes"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineDisplayedStackedData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineDisplayedStackedData"]);
var selectAllTooltipAppliedValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipDisplayedData,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    selectAllGraphicalItemsSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexes"],
    selectAnyTooltipItemUsesChartData,
    selectTooltipGraphicalItemsData
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineAllAppliedValues"]);
var selectTooltipAxisDomainDefinition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDomainDefinition"]);
var selectTooltipDataOverflow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"]
], (axisSettings)=>axisSettings.allowDataOverflow);
var selectTooltipDomainFromUserPreferences = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipAxisDomainDefinition,
    selectTooltipDataOverflow
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isDomainSpecifiedByUser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["numericalDomainSpecifiedWithoutRequiringData"]);
var selectAllStackedGraphicalItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllGraphicalItemsSettings
], (graphicalItems)=>graphicalItems.filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$types$2f$StackedGraphicalItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isStacked"]));
var selectTooltipStackGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipStackedData,
    selectAllStackedGraphicalItems,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectStackOffsetType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectReverseStackOrder"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineStackGroups"]);
var selectTooltipDomainOfStackGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipStackGroups,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexes"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"],
    selectTooltipDomainFromUserPreferences
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineDomainOfStackGroups"]);
var selectTooltipItemsSettingsExceptStacked = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllGraphicalItemsSettings
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterGraphicalNotStackedItems"]);
var selectDomainOfAllAppliedNumericalValuesIncludingErrorValues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipDisplayedData,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    selectTooltipItemsSettingsExceptStacked,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllErrorBarSettings"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataSliceWithIndexes"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineDomainOfAllAppliedNumericalValuesIncludingErrorValues"], {
    memoizeOptions: {
        resultEqualityCheck: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$numberDomainEqualityCheck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["numberDomainEqualityCheck"]
    }
});
var selectReferenceDotsByTooltipAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectReferenceDots"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisId"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterReferenceElements"]);
var selectTooltipReferenceDotsDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectReferenceDotsByTooltipAxis,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineDotsDomain"]);
var selectReferenceAreasByTooltipAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectReferenceAreas"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisId"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterReferenceElements"]);
var selectTooltipReferenceAreasDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectReferenceAreasByTooltipAxis,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineAreasDomain"]);
var selectReferenceLinesByTooltipAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectReferenceLines"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisId"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterReferenceElements"]);
var selectTooltipReferenceLinesDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectReferenceLinesByTooltipAxis,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineLinesDomain"]);
var selectTooltipReferenceElementsDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipReferenceDotsDomain,
    selectTooltipReferenceLinesDomain,
    selectTooltipReferenceAreasDomain
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeDomains"]);
var selectTooltipNumericalDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    selectTooltipAxisDomainDefinition,
    selectTooltipDomainFromUserPreferences,
    selectTooltipDomainOfStackGroups,
    selectDomainOfAllAppliedNumericalValuesIncludingErrorValues,
    selectTooltipReferenceElementsDomain,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineNumericalDomain"]);
var selectTooltipAxisDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectTooltipDisplayedData,
    selectAllTooltipAppliedValues,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectStackOffsetType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"],
    selectTooltipNumericalDomain
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineAxisDomain"]);
var selectTooltipNiceTicks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipAxisDomain,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    selectTooltipAxisRealScaleType
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineNiceTicks"]);
var selectTooltipAxisDomainIncludingNiceTicks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    selectTooltipAxisDomain,
    selectTooltipNiceTicks,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineAxisDomainWithNiceTicks"]);
var selectTooltipAxisRange = (state)=>{
    var axisType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"])(state);
    var axisId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisId"])(state);
    var isPanorama = false; // Tooltip never displays in panorama so this is safe to assume
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAxisRange"])(state, axisType, axisId, isPanorama);
};
var selectTooltipAxisRangeWithReverse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    selectTooltipAxisRange
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineAxisRangeWithReverse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineAxisRangeWithReverse"]);
var selectTooltipConfiguredScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    selectTooltipAxisRealScaleType,
    selectTooltipAxisDomainIncludingNiceTicks,
    selectTooltipAxisRangeWithReverse
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineConfiguredScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineConfiguredScale"]);
var selectTooltipAxisScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipConfiguredScale
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$scale$2f$RechartsScale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rechartsScaleFactory"]);
var selectTooltipDuplicateDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectAllTooltipAppliedValues,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineDuplicateDomain"]);
var selectTooltipCategoricalDomain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectAllTooltipAppliedValues,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineCategoricalDomain"]);
var combineTicksOfTooltipAxis = (layout, axis, realScaleType, scale, range, duplicateDomain, categoricalDomain, axisType)=>{
    if (!axis) {
        return undefined;
    }
    var { type } = axis;
    var isCategorical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCategoricalAxis"])(layout, axisType);
    if (!scale) {
        return undefined;
    }
    var offsetForBand = realScaleType === 'scaleBand' && scale.bandwidth ? scale.bandwidth() / 2 : 2;
    var offset = type === 'category' && scale.bandwidth ? scale.bandwidth() / offsetForBand : 0;
    offset = axisType === 'angleAxis' && range != null && (range === null || range === void 0 ? void 0 : range.length) >= 2 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mathSign"])(range[0] - range[1]) * 2 * offset : offset;
    // When axis is a categorical axis, but the type of axis is number or the scale of axis is not "auto"
    if (isCategorical && categoricalDomain) {
        return categoricalDomain.map((entry, index)=>{
            var scaled = scale.map(entry);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(scaled)) {
                return null;
            }
            return {
                coordinate: scaled + offset,
                value: entry,
                index,
                offset
            };
        }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
    }
    // When axis has duplicated text, serial numbers are used to generate scale
    return scale.domain().map((entry, index)=>{
        var scaled = scale.map(entry);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$isWellBehavedNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWellBehavedNumber"])(scaled)) {
            return null;
        }
        return {
            coordinate: scaled + offset,
            // @ts-expect-error can't use Date as an index
            value: duplicateDomain ? duplicateDomain[entry] : entry,
            index,
            offset
        };
    }).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$DataUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNotNil"]);
};
var selectTooltipAxisTicks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxis"],
    selectTooltipAxisRealScaleType,
    selectTooltipAxisScale,
    selectTooltipAxisRange,
    selectTooltipDuplicateDomain,
    selectTooltipCategoricalDomain,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"]
], combineTicksOfTooltipAxis);
var selectTooltipEventType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectDefaultTooltipEventType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectValidateTooltipEventTypes"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipSettings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipSettings"]
], (defaultTooltipEventType, validateTooltipEventType, settings)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineTooltipEventType"])(settings.shared, defaultTooltipEventType, validateTooltipEventType));
var selectTooltipTrigger = (state)=>state.tooltip.settings.trigger;
var selectDefaultIndex = (state)=>state.tooltip.settings.defaultIndex;
var selectTooltipInteractionState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipState"],
    selectTooltipEventType,
    selectTooltipTrigger,
    selectDefaultIndex
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipInteractionState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineTooltipInteractionState"]);
var selectActiveTooltipIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipInteractionState,
    selectTooltipDisplayedData,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisDataKey"],
    selectTooltipAxisDomain
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveTooltipIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineActiveTooltipIndex"]);
var selectActiveLabel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipAxisTicks,
    selectActiveTooltipIndex
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineActiveLabel"]);
var selectActiveTooltipDataKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipInteractionState
], (tooltipInteraction)=>{
    if (!tooltipInteraction) {
        return undefined;
    }
    return tooltipInteraction.dataKey;
});
var selectActiveTooltipGraphicalItemId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipInteractionState
], (tooltipInteraction)=>{
    if (!tooltipInteraction) {
        return undefined;
    }
    return tooltipInteraction.graphicalItemId;
});
var selectTooltipPayloadConfigurations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipState"],
    selectTooltipEventType,
    selectTooltipTrigger,
    selectDefaultIndex
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipPayloadConfigurations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineTooltipPayloadConfigurations"]);
var selectTooltipCoordinateForDefaultIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartWidth"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartHeight"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"],
    selectTooltipAxisTicks,
    selectDefaultIndex,
    selectTooltipPayloadConfigurations
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineCoordinateForDefaultIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineCoordinateForDefaultIndex"]);
var selectActiveTooltipCoordinate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipInteractionState,
    selectTooltipCoordinateForDefaultIndex
], (tooltipInteractionState, defaultIndexCoordinate)=>{
    if (tooltipInteractionState !== null && tooltipInteractionState !== void 0 && tooltipInteractionState.coordinate) {
        return tooltipInteractionState.coordinate;
    }
    return defaultIndexCoordinate;
});
var selectIsTooltipActive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipInteractionState
], (tooltipInteractionState)=>{
    var _tooltipInteractionSt;
    return (_tooltipInteractionSt = tooltipInteractionState === null || tooltipInteractionState === void 0 ? void 0 : tooltipInteractionState.active) !== null && _tooltipInteractionSt !== void 0 ? _tooltipInteractionSt : false;
});
var selectActiveTooltipPayload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipPayloadConfigurations,
    selectActiveTooltipIndex,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexes"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisDataKey"],
    selectActiveLabel,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipPayloadSearcher$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipPayloadSearcher"],
    selectTooltipEventType
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipPayload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineTooltipPayload"]);
var selectActiveTooltipDataPoints = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectActiveTooltipPayload
], (payload)=>{
    if (payload == null) {
        return undefined;
    }
    var dataPoints = payload.map((p)=>p.payload).filter((p)=>p != null);
    return Array.from(new Set(dataPoints));
});
}),
"[project]/node_modules/recharts/es6/state/selectors/selectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combineActiveProps",
    ()=>combineActiveProps,
    "selectActiveCoordinate",
    ()=>selectActiveCoordinate,
    "selectActiveIndex",
    ()=>selectActiveIndex,
    "selectActiveLabel",
    ()=>selectActiveLabel,
    "selectCoordinateForDefaultIndex",
    ()=>selectCoordinateForDefaultIndex,
    "selectIsTooltipActive",
    ()=>selectIsTooltipActive,
    "selectOrderedTooltipTicks",
    ()=>selectOrderedTooltipTicks,
    "selectTooltipDataKey",
    ()=>selectTooltipDataKey,
    "selectTooltipInteractionState",
    ()=>selectTooltipInteractionState,
    "selectTooltipPayload",
    ()=>selectTooltipPayload,
    "selectTooltipPayloadConfigurations",
    ()=>selectTooltipPayloadConfigurations,
    "useChartName",
    ()=>useChartName
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$es$2d$toolkit$2f$compat$2f$sortBy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/es-toolkit/compat/sortBy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/ChartUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/dataSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/tooltipSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/axisSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/rootPropsSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/chartLayoutContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectChartOffsetInternal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/containerSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineActiveLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipInteractionState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineTooltipInteractionState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveTooltipIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineActiveTooltipIndex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineCoordinateForDefaultIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineCoordinateForDefaultIndex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipPayloadConfigurations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineTooltipPayloadConfigurations.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipPayloadSearcher$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipPayloadSearcher.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipPayload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineTooltipPayload.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getActiveCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/getActiveCoordinate.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$PolarUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/PolarUtils.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var useChartName = ()=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartName"]);
};
var pickTooltipEventType = (_state, tooltipEventType)=>tooltipEventType;
var pickTrigger = (_state, _tooltipEventType, trigger)=>trigger;
var pickDefaultIndex = (_state, _tooltipEventType, _trigger, defaultIndex)=>defaultIndex;
var selectOrderedTooltipTicks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisTicks"], (ticks)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$es$2d$toolkit$2f$compat$2f$sortBy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ticks, (o)=>o.coordinate));
var selectTooltipInteractionState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipState"],
    pickTooltipEventType,
    pickTrigger,
    pickDefaultIndex
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipInteractionState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineTooltipInteractionState"]);
var selectActiveIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipInteractionState,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipDisplayedData"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisDataKey"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisDomain"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveTooltipIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineActiveTooltipIndex"]);
var selectTooltipDataKey = (state, tooltipEventType, trigger)=>{
    if (tooltipEventType == null) {
        return undefined;
    }
    var tooltipState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipState"])(state);
    if (tooltipEventType === 'axis') {
        if (trigger === 'hover') {
            return tooltipState.axisInteraction.hover.dataKey;
        }
        return tooltipState.axisInteraction.click.dataKey;
    }
    if (trigger === 'hover') {
        return tooltipState.itemInteraction.hover.dataKey;
    }
    return tooltipState.itemInteraction.click.dataKey;
};
var selectTooltipPayloadConfigurations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipState"],
    pickTooltipEventType,
    pickTrigger,
    pickDefaultIndex
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipPayloadConfigurations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineTooltipPayloadConfigurations"]);
var selectCoordinateForDefaultIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartWidth"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartHeight"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisTicks"],
    pickDefaultIndex,
    selectTooltipPayloadConfigurations
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineCoordinateForDefaultIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineCoordinateForDefaultIndex"]);
var selectActiveCoordinate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipInteractionState,
    selectCoordinateForDefaultIndex
], (tooltipInteractionState, defaultIndexCoordinate)=>{
    var _tooltipInteractionSt;
    return (_tooltipInteractionSt = tooltipInteractionState.coordinate) !== null && _tooltipInteractionSt !== void 0 ? _tooltipInteractionSt : defaultIndexCoordinate;
});
var selectActiveLabel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisTicks"],
    selectActiveIndex
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineActiveLabel"]);
var selectTooltipPayload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipPayloadConfigurations,
    selectActiveIndex,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexes"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisDataKey"],
    selectActiveLabel,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipPayloadSearcher$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipPayloadSearcher"],
    pickTooltipEventType
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineTooltipPayload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineTooltipPayload"]);
var selectIsTooltipActive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectTooltipInteractionState,
    selectActiveIndex
], (tooltipInteractionState, activeIndex)=>{
    return {
        isActive: tooltipInteractionState.active && activeIndex != null,
        activeIndex
    };
});
var combineActiveCartesianProps = (chartEvent, layout, tooltipAxisType, tooltipAxisRange, tooltipTicks, orderedTooltipTicks, offset)=>{
    if (!chartEvent || !tooltipAxisType || !tooltipAxisRange || !tooltipTicks) {
        return undefined;
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getActiveCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInCartesianRange"])(chartEvent, offset)) {
        return undefined;
    }
    var pos = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateCartesianTooltipPos"])(chartEvent, layout);
    var activeIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getActiveCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateActiveTickIndex"])(pos, orderedTooltipTicks, tooltipTicks, tooltipAxisType, tooltipAxisRange);
    var activeCoordinate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getActiveCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getActiveCartesianCoordinate"])(layout, tooltipTicks, activeIndex, chartEvent);
    return {
        activeIndex: String(activeIndex),
        activeCoordinate
    };
};
var combineActivePolarProps = (chartEvent, layout, polarViewBox, tooltipAxisType, tooltipAxisRange, tooltipTicks, orderedTooltipTicks)=>{
    if (!chartEvent || !tooltipAxisType || !tooltipAxisRange || !tooltipTicks || !polarViewBox) {
        return undefined;
    }
    var rangeObj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$PolarUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inRangeOfSector"])(chartEvent, polarViewBox);
    if (!rangeObj) {
        return undefined;
    }
    var pos = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculatePolarTooltipPos"])(rangeObj, layout);
    var activeIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getActiveCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateActiveTickIndex"])(pos, orderedTooltipTicks, tooltipTicks, tooltipAxisType, tooltipAxisRange);
    var activeCoordinate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getActiveCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getActivePolarCoordinate"])(layout, tooltipTicks, activeIndex, rangeObj);
    return {
        activeIndex: String(activeIndex),
        activeCoordinate
    };
};
var combineActiveProps = (chartEvent, layout, polarViewBox, tooltipAxisType, tooltipAxisRange, tooltipTicks, orderedTooltipTicks, offset)=>{
    if (!chartEvent || !layout || !tooltipAxisType || !tooltipAxisRange || !tooltipTicks) {
        return undefined;
    }
    if (layout === 'horizontal' || layout === 'vertical') {
        return combineActiveCartesianProps(chartEvent, layout, tooltipAxisType, tooltipAxisRange, tooltipTicks, orderedTooltipTicks, offset);
    }
    return combineActivePolarProps(chartEvent, layout, polarViewBox, tooltipAxisType, tooltipAxisRange, tooltipTicks, orderedTooltipTicks);
};
}),
"[project]/node_modules/recharts/es6/state/selectors/selectActivePropsFromChartPointer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectActivePropsFromChartPointer",
    ()=>selectActivePropsFromChartPointer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/chartLayoutContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/tooltipSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectChartOffsetInternal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$polarAxisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/polarAxisSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipAxisType.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
var pickChartPointer = (_state, chartPointer)=>chartPointer;
var selectActivePropsFromChartPointer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    pickChartPointer,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$polarAxisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectPolarViewBox"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipAxisType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisType"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisRangeWithReverse"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisTicks"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectOrderedTooltipTicks"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"]
], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineActiveProps"]);
}),
"[project]/node_modules/recharts/es6/state/mouseEventsMiddleware.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mouseClickAction",
    ()=>mouseClickAction,
    "mouseClickMiddleware",
    ()=>mouseClickMiddleware,
    "mouseMoveAction",
    ()=>mouseMoveAction,
    "mouseMoveMiddleware",
    ()=>mouseMoveMiddleware
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/tooltipSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectActivePropsFromChartPointer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectActivePropsFromChartPointer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipEventType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getRelativeCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/getRelativeCoordinate.js [app-client] (ecmascript)");
;
;
;
;
;
var mouseClickAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAction"])('mouseClick');
var mouseClickMiddleware = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createListenerMiddleware"])();
// TODO: there's a bug here when you click the chart the activeIndex resets to zero
mouseClickMiddleware.startListening({
    actionCreator: mouseClickAction,
    effect: (action, listenerApi)=>{
        var mousePointer = action.payload;
        var activeProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectActivePropsFromChartPointer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectActivePropsFromChartPointer"])(listenerApi.getState(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getRelativeCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRelativeCoordinate"])(mousePointer));
        if ((activeProps === null || activeProps === void 0 ? void 0 : activeProps.activeIndex) != null) {
            listenerApi.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMouseClickAxisIndex"])({
                activeIndex: activeProps.activeIndex,
                activeDataKey: undefined,
                activeCoordinate: activeProps.activeCoordinate
            }));
        }
    }
});
var mouseMoveAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAction"])('mouseMove');
var mouseMoveMiddleware = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createListenerMiddleware"])();
/*
 * This single rafId is safe because:
 * 1. Each chart has its own Redux store instance with its own middleware
 * 2. mouseMoveAction only fires from one DOM element (the chart wrapper)
 * 3. Rapid mousemove events from the same element SHOULD debounce - we only care about the latest position
 * This is different from externalEventsMiddleware which handles multiple event types
 * (click, mouseenter, mouseleave, etc.) that should NOT cancel each other.
 */ var rafId = null;
var timeoutId = null;
var latestChartPointer = null;
mouseMoveMiddleware.startListening({
    actionCreator: mouseMoveAction,
    effect: (action, listenerApi)=>{
        var mousePointer = action.payload;
        var state = listenerApi.getState();
        var { throttleDelay, throttledEvents } = state.eventSettings;
        var isThrottled = throttledEvents === 'all' || (throttledEvents === null || throttledEvents === void 0 ? void 0 : throttledEvents.includes('mousemove'));
        // Cancel any pending execution
        if (rafId !== null) {
            cancelAnimationFrame(rafId);
            rafId = null;
        }
        if (timeoutId !== null && (typeof throttleDelay !== 'number' || !isThrottled)) {
            clearTimeout(timeoutId);
            timeoutId = null;
        }
        /*
     * Here it is important to resolve the chart pointer _before_ the callback,
     * because once we leave the current event loop, the mousePointer event object will lose
     * reference to currentTarget which getRelativeCoordinate uses.
     */ latestChartPointer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getRelativeCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRelativeCoordinate"])(mousePointer);
        var callback = ()=>{
            /*
       * Here we read a fresh state again inside the callback to ensure we have the latest state values
       * after any potential actions that may have been dispatched between the original event and this callback.
       */ var currentState = listenerApi.getState();
            var tooltipEventType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipEventType"])(currentState, currentState.tooltip.settings.shared);
            if (!latestChartPointer) {
                rafId = null;
                timeoutId = null;
                return;
            }
            /*
       * This functionality only applies to charts that have axes.
       * Graphical items have its own mouse events handling mechanism where they attach events directly to the items.
       */ if (tooltipEventType === 'axis') {
                var activeProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectActivePropsFromChartPointer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectActivePropsFromChartPointer"])(currentState, latestChartPointer);
                if ((activeProps === null || activeProps === void 0 ? void 0 : activeProps.activeIndex) != null) {
                    listenerApi.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMouseOverAxisIndex"])({
                        activeIndex: activeProps.activeIndex,
                        activeDataKey: undefined,
                        activeCoordinate: activeProps.activeCoordinate
                    }));
                } else {
                    // this is needed to clear tooltip state when the mouse moves out of the inRange (svg - offset) function, but not yet out of the svg
                    listenerApi.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mouseLeaveChart"])());
                }
            }
            rafId = null;
            timeoutId = null;
        };
        if (!isThrottled) {
            callback();
            return;
        }
        if (throttleDelay === 'raf') {
            rafId = requestAnimationFrame(callback);
        } else if (typeof throttleDelay === 'number') {
            if (timeoutId === null) {
                timeoutId = setTimeout(callback, throttleDelay);
            }
        }
    }
});
}),
"[project]/node_modules/recharts/es6/state/reduxDevtoolsJsonStringifyReplacer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reduxDevtoolsJsonStringifyReplacer",
    ()=>reduxDevtoolsJsonStringifyReplacer
]);
function reduxDevtoolsJsonStringifyReplacer(key, value) {
    if (value instanceof HTMLElement) {
        return "HTMLElement <".concat(value.tagName, " class=\"").concat(value.className, "\">");
    }
    if (value === window) {
        return 'global.window';
    }
    if (key === 'children' && typeof value === 'object' && value !== null) {
        return '<<CHILDREN>>';
    }
    return value;
}
}),
"[project]/node_modules/recharts/es6/state/cartesianAxisSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addXAxis",
    ()=>addXAxis,
    "addYAxis",
    ()=>addYAxis,
    "addZAxis",
    ()=>addZAxis,
    "cartesianAxisReducer",
    ()=>cartesianAxisReducer,
    "defaultAxisId",
    ()=>defaultAxisId,
    "removeXAxis",
    ()=>removeXAxis,
    "removeYAxis",
    ()=>removeYAxis,
    "removeZAxis",
    ()=>removeZAxis,
    "replaceXAxis",
    ()=>replaceXAxis,
    "replaceYAxis",
    ()=>replaceYAxis,
    "replaceZAxis",
    ()=>replaceZAxis,
    "updateYAxisWidth",
    ()=>updateYAxisWidth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
;
var defaultAxisId = 0;
/**
 * Properties shared in X, Y, and Z axes.
 * User defined axis settings, coming from props.
 */ /**
 * Controls how Recharts calculates "nice" tick values for numerical axes.
 *
 * - `'none'`: Recharts does not apply any tick-rounding algorithm; tick positions are
 *   determined entirely by d3, evenly spaced but not rounded to human-friendly numbers.
 *   There is no domain-extension logic applied in this mode.
 *
 * - `'auto'` *(default)*: Recharts automatically decides whether and how to apply tick
 *   niceties based on the domain definition. When the domain contains an `'auto'` keyword,
 *   Recharts uses the `'adaptive'` algorithm and may extend the domain slightly to
 *   produce clean tick labels. Otherwise, it applies the same algorithm while keeping
 *   ticks within the fixed domain. This mirrors the default behavior from Recharts v2.
 *
 * - `'adaptive'`: Always applies the space-efficient algorithm (`getAdaptiveStep`),
 *   which fills the available range as densely as possible while still rounding steps
 *   to reasonable numbers (e.g. 10, 20, 25). May produce less "round-looking" labels
 *   than `'snap125'`, but wastes less space. The domain-extension logic still applies
 *   when the domain contains an `'auto'` keyword.
 *
 * - `'snap125'`: Always applies the round-numbers algorithm (`getSnap125Step`), which
 *   snaps step sizes to values from the set {1, 2, 2.5, 5} × 10ⁿ. Produces very
 *   human-friendly labels (e.g. 0, 5, 10, 15, 20) but may leave blank space at the
 *   edges of the chart. The domain-extension logic still applies when the domain
 *   contains an `'auto'` keyword.
 *
 * @see {@link https://recharts.github.io/guide/axisTicks/}
 * @inline
 */ /**
 * These are the external props, visible for users as they set them using our public API.
 * There is all sorts of internal computed things based on these, but they will come through selectors.
 *
 * Properties shared between X and Y axes
 */ /**
 * Z axis is special because it's never displayed. It controls the size of Scatter dots,
 * but it never displays ticks anywhere.
 */ var initialState = {
    xAxis: {},
    yAxis: {},
    zAxis: {}
};
/**
 * This is the slice where each individual Axis element pushes its own configuration.
 * Prefer to use this one instead of axisSlice.
 */ var cartesianAxisSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'cartesianAxis',
    initialState,
    reducers: {
        addXAxis: {
            reducer (state, action) {
                state.xAxis[action.payload.id] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload);
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        replaceXAxis: {
            reducer (state, action) {
                var { prev, next } = action.payload;
                if (state.xAxis[prev.id] !== undefined) {
                    if (prev.id !== next.id) {
                        delete state.xAxis[prev.id];
                    }
                    state.xAxis[next.id] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(next);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        removeXAxis: {
            reducer (state, action) {
                delete state.xAxis[action.payload.id];
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        addYAxis: {
            reducer (state, action) {
                state.yAxis[action.payload.id] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload);
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        replaceYAxis: {
            reducer (state, action) {
                var { prev, next } = action.payload;
                if (state.yAxis[prev.id] !== undefined) {
                    if (prev.id !== next.id) {
                        delete state.yAxis[prev.id];
                    }
                    state.yAxis[next.id] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(next);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        removeYAxis: {
            reducer (state, action) {
                delete state.yAxis[action.payload.id];
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        addZAxis: {
            reducer (state, action) {
                state.zAxis[action.payload.id] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload);
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        replaceZAxis: {
            reducer (state, action) {
                var { prev, next } = action.payload;
                if (state.zAxis[prev.id] !== undefined) {
                    if (prev.id !== next.id) {
                        delete state.zAxis[prev.id];
                    }
                    state.zAxis[next.id] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(next);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        removeZAxis: {
            reducer (state, action) {
                delete state.zAxis[action.payload.id];
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        updateYAxisWidth (state, action) {
            var { id, width } = action.payload;
            var axis = state.yAxis[id];
            if (axis) {
                var _history$;
                var history = axis.widthHistory || [];
                // An oscillation is detected when the new width is the same as the width before the last one.
                // This is a simple A -> B -> A pattern. If the next width is B, and the difference is less than 1 pixel, we ignore it.
                if (history.length === 3 && history[0] === history[2] && width === history[1] && width !== axis.width && Math.abs(width - ((_history$ = history[0]) !== null && _history$ !== void 0 ? _history$ : 0)) <= 1) {
                    return;
                }
                var newHistory = [
                    ...history,
                    width
                ].slice(-3);
                state.yAxis[id] = _objectSpread(_objectSpread({}, axis), {}, {
                    width,
                    widthHistory: newHistory
                });
            }
        }
    }
});
var { addXAxis, replaceXAxis, removeXAxis, addYAxis, replaceYAxis, removeYAxis, addZAxis, replaceZAxis, removeZAxis, updateYAxisWidth } = cartesianAxisSlice.actions;
var cartesianAxisReducer = cartesianAxisSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/graphicalItemsSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addCartesianGraphicalItem",
    ()=>addCartesianGraphicalItem,
    "addPolarGraphicalItem",
    ()=>addPolarGraphicalItem,
    "graphicalItemsReducer",
    ()=>graphicalItemsReducer,
    "removeCartesianGraphicalItem",
    ()=>removeCartesianGraphicalItem,
    "removePolarGraphicalItem",
    ()=>removePolarGraphicalItem,
    "replaceCartesianGraphicalItem",
    ()=>replaceCartesianGraphicalItem,
    "replacePolarGraphicalItem",
    ()=>replacePolarGraphicalItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
;
;
/**
 * Unique ID of the graphical item.
 * This is used to identify the graphical item in the state and in the React tree.
 * This is required for every graphical item - it's either provided by the user or generated automatically.
 */ var initialState = {
    cartesianItems: [],
    polarItems: []
};
var graphicalItemsSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'graphicalItems',
    initialState,
    reducers: {
        addCartesianGraphicalItem: {
            reducer (state, action) {
                state.cartesianItems.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload));
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        replaceCartesianGraphicalItem: {
            reducer (state, action) {
                var { prev, next } = action.payload;
                var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).cartesianItems.indexOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(prev));
                if (index > -1) {
                    state.cartesianItems[index] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(next);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        removeCartesianGraphicalItem: {
            reducer (state, action) {
                var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).cartesianItems.indexOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload));
                if (index > -1) {
                    state.cartesianItems.splice(index, 1);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        addPolarGraphicalItem: {
            reducer (state, action) {
                state.polarItems.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload));
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        removePolarGraphicalItem: {
            reducer (state, action) {
                var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).polarItems.indexOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload));
                if (index > -1) {
                    state.polarItems.splice(index, 1);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        replacePolarGraphicalItem: {
            reducer (state, action) {
                var { prev, next } = action.payload;
                var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).polarItems.indexOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(prev));
                if (index > -1) {
                    state.polarItems[index] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(next);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        }
    }
});
var { addCartesianGraphicalItem, replaceCartesianGraphicalItem, removeCartesianGraphicalItem, addPolarGraphicalItem, removePolarGraphicalItem, replacePolarGraphicalItem } = graphicalItemsSlice.actions;
var graphicalItemsReducer = graphicalItemsSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/referenceElementsSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addArea",
    ()=>addArea,
    "addDot",
    ()=>addDot,
    "addLine",
    ()=>addLine,
    "referenceElementsReducer",
    ()=>referenceElementsReducer,
    "referenceElementsSlice",
    ()=>referenceElementsSlice,
    "removeArea",
    ()=>removeArea,
    "removeDot",
    ()=>removeDot,
    "removeLine",
    ()=>removeLine
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
;
;
var initialState = {
    dots: [],
    areas: [],
    lines: []
};
var referenceElementsSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'referenceElements',
    initialState,
    reducers: {
        addDot: (state, action)=>{
            state.dots.push(action.payload);
        },
        removeDot: (state, action)=>{
            var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).dots.findIndex((dot)=>dot === action.payload);
            if (index !== -1) {
                state.dots.splice(index, 1);
            }
        },
        addArea: (state, action)=>{
            state.areas.push(action.payload);
        },
        removeArea: (state, action)=>{
            var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).areas.findIndex((area)=>area === action.payload);
            if (index !== -1) {
                state.areas.splice(index, 1);
            }
        },
        addLine: (state, action)=>{
            state.lines.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload));
        },
        removeLine: (state, action)=>{
            var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).lines.findIndex((line)=>line === action.payload);
            if (index !== -1) {
                state.lines.splice(index, 1);
            }
        }
    }
});
var { addDot, removeDot, addArea, removeArea, addLine, removeLine } = referenceElementsSlice.actions;
var referenceElementsReducer = referenceElementsSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/brushSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "brushReducer",
    ()=>brushReducer,
    "brushSlice",
    ()=>brushSlice,
    "setBrushSettings",
    ()=>setBrushSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
;
/**
 * From all Brush properties, only height has a default value and will always be defined.
 * Other properties are nullable and will be computed from offsets and margins if they are not set.
 */ var initialState = {
    x: 0,
    y: 0,
    width: 0,
    height: 0,
    padding: {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
    }
};
var brushSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'brush',
    initialState,
    reducers: {
        setBrushSettings (_state, action) {
            if (action.payload == null) {
                return initialState;
            }
            return action.payload;
        }
    }
});
var { setBrushSettings } = brushSlice.actions;
var brushReducer = brushSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/legendSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addLegendPayload",
    ()=>addLegendPayload,
    "legendReducer",
    ()=>legendReducer,
    "removeLegendPayload",
    ()=>removeLegendPayload,
    "replaceLegendPayload",
    ()=>replaceLegendPayload,
    "setLegendSettings",
    ()=>setLegendSettings,
    "setLegendSize",
    ()=>setLegendSize
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
;
;
/**
 * The properties inside this state update independently of each other and quite often.
 * When selecting, never select the whole state because you are going to get
 * unnecessary re-renders. Select only the properties you need.
 *
 * This is why this state type is not exported - don't use it directly.
 */ var initialState = {
    settings: {
        layout: 'horizontal',
        align: 'center',
        verticalAlign: 'middle',
        itemSorter: 'value'
    },
    size: {
        width: 0,
        height: 0
    },
    payload: []
};
var legendSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'legend',
    initialState,
    reducers: {
        setLegendSize (state, action) {
            state.size.width = action.payload.width;
            state.size.height = action.payload.height;
        },
        setLegendSettings (state, action) {
            state.settings.align = action.payload.align;
            state.settings.layout = action.payload.layout;
            state.settings.verticalAlign = action.payload.verticalAlign;
            state.settings.itemSorter = action.payload.itemSorter;
        },
        addLegendPayload: {
            reducer (state, action) {
                state.payload.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload));
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        replaceLegendPayload: {
            reducer (state, action) {
                var { prev, next } = action.payload;
                var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).payload.indexOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(prev));
                if (index > -1) {
                    state.payload[index] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(next);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        removeLegendPayload: {
            reducer (state, action) {
                var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["current"])(state).payload.indexOf((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload));
                if (index > -1) {
                    state.payload.splice(index, 1);
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        }
    }
});
var { setLegendSize, setLegendSettings, addLegendPayload, replaceLegendPayload, removeLegendPayload } = legendSlice.actions;
var legendReducer = legendSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/rootPropsSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "initialState",
    ()=>initialState,
    "rootPropsReducer",
    ()=>rootPropsReducer,
    "updateOptions",
    ()=>updateOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
;
var initialState = {
    accessibilityLayer: true,
    barCategoryGap: '10%',
    barGap: 4,
    barSize: undefined,
    className: undefined,
    maxBarSize: undefined,
    stackOffset: 'none',
    syncId: undefined,
    syncMethod: 'index',
    baseValue: undefined,
    reverseStackOrder: false
};
var rootPropsSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'rootProps',
    initialState,
    reducers: {
        updateOptions: (state, action)=>{
            var _action$payload$barGa;
            state.accessibilityLayer = action.payload.accessibilityLayer;
            state.barCategoryGap = action.payload.barCategoryGap;
            state.barGap = (_action$payload$barGa = action.payload.barGap) !== null && _action$payload$barGa !== void 0 ? _action$payload$barGa : initialState.barGap;
            state.barSize = action.payload.barSize;
            state.maxBarSize = action.payload.maxBarSize;
            state.stackOffset = action.payload.stackOffset;
            state.syncId = action.payload.syncId;
            state.syncMethod = action.payload.syncMethod;
            state.className = action.payload.className;
            state.baseValue = action.payload.baseValue;
            state.reverseStackOrder = action.payload.reverseStackOrder;
        }
    }
});
var rootPropsReducer = rootPropsSlice.reducer;
var { updateOptions } = rootPropsSlice.actions;
}),
"[project]/node_modules/recharts/es6/state/polarAxisSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addAngleAxis",
    ()=>addAngleAxis,
    "addRadiusAxis",
    ()=>addRadiusAxis,
    "polarAxisReducer",
    ()=>polarAxisReducer,
    "removeAngleAxis",
    ()=>removeAngleAxis,
    "removeRadiusAxis",
    ()=>removeRadiusAxis
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
;
;
var initialState = {
    radiusAxis: {},
    angleAxis: {}
};
var polarAxisSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'polarAxis',
    initialState,
    reducers: {
        addRadiusAxis (state, action) {
            state.radiusAxis[action.payload.id] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload);
        },
        removeRadiusAxis (state, action) {
            delete state.radiusAxis[action.payload.id];
        },
        addAngleAxis (state, action) {
            state.angleAxis[action.payload.id] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload);
        },
        removeAngleAxis (state, action) {
            delete state.angleAxis[action.payload.id];
        }
    }
});
var { addRadiusAxis, removeRadiusAxis, addAngleAxis, removeAngleAxis } = polarAxisSlice.actions;
var polarAxisReducer = polarAxisSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/polarOptionsSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "polarOptionsReducer",
    ()=>polarOptionsReducer,
    "updatePolarOptions",
    ()=>updatePolarOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
;
var initialState = null;
var reducers = {
    updatePolarOptions: (state, action)=>{
        if (state === null) {
            return action.payload;
        }
        state.startAngle = action.payload.startAngle;
        state.endAngle = action.payload.endAngle;
        state.cx = action.payload.cx;
        state.cy = action.payload.cy;
        state.innerRadius = action.payload.innerRadius;
        state.outerRadius = action.payload.outerRadius;
        return state;
    }
};
var polarOptionsSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'polarOptions',
    initialState,
    reducers
});
var { updatePolarOptions } = polarOptionsSlice.actions;
var polarOptionsReducer = polarOptionsSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/keyboardEventsMiddleware.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "blurAction",
    ()=>blurAction,
    "focusAction",
    ()=>focusAction,
    "keyDownAction",
    ()=>keyDownAction,
    "keyboardEventsMiddleware",
    ()=>keyboardEventsMiddleware
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/tooltipSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/tooltipSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/axisSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveTooltipIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/combiners/combineActiveTooltipIndex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipEventType.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
var keyDownAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAction"])('keyDown');
var focusAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAction"])('focus');
var blurAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAction"])('blur');
var keyboardEventsMiddleware = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createListenerMiddleware"])();
var rafId = null;
var timeoutId = null;
var latestKeyboardActionPayload = null;
keyboardEventsMiddleware.startListening({
    actionCreator: keyDownAction,
    effect: (action, listenerApi)=>{
        latestKeyboardActionPayload = action.payload;
        if (rafId !== null) {
            cancelAnimationFrame(rafId);
            rafId = null;
        }
        var state = listenerApi.getState();
        var { throttleDelay, throttledEvents } = state.eventSettings;
        var isThrottled = throttledEvents === 'all' || throttledEvents.includes('keydown');
        if (timeoutId !== null && (typeof throttleDelay !== 'number' || !isThrottled)) {
            clearTimeout(timeoutId);
            timeoutId = null;
        }
        var callback = ()=>{
            try {
                var currentState = listenerApi.getState();
                var accessibilityLayerIsActive = currentState.rootProps.accessibilityLayer !== false;
                if (!accessibilityLayerIsActive) {
                    return;
                }
                var { keyboardInteraction } = currentState.tooltip;
                var key = latestKeyboardActionPayload;
                if (key !== 'ArrowRight' && key !== 'ArrowLeft' && key !== 'Enter') {
                    return;
                }
                // TODO this is lacking index for charts that do not support numeric indexes
                var resolvedIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveTooltipIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineActiveTooltipIndex"])(keyboardInteraction, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipDisplayedData"])(currentState), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisDataKey"])(currentState), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisDomain"])(currentState));
                var currentIndex = resolvedIndex == null ? -1 : Number(resolvedIndex);
                var isOutsideDomain = !Number.isFinite(currentIndex) || currentIndex < 0;
                var tooltipTicks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisTicks"])(currentState);
                var displayedData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipDisplayedData"])(currentState);
                var tooltipEventType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipEventType"])(currentState, currentState.tooltip.settings.shared);
                if (key === 'Enter') {
                    if (isOutsideDomain) {
                        return;
                    }
                    var _coordinate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectCoordinateForDefaultIndex"])(currentState, tooltipEventType, 'hover', String(keyboardInteraction.index));
                    listenerApi.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setKeyboardInteraction"])({
                        active: !keyboardInteraction.active,
                        activeIndex: keyboardInteraction.index,
                        activeCoordinate: _coordinate
                    }));
                    return;
                }
                var direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDirection"])(currentState);
                var directionMultiplier = direction === 'left-to-right' ? 1 : -1;
                var movement = key === 'ArrowRight' ? 1 : -1;
                var nextIndex;
                if (isOutsideDomain) {
                    var axisDataKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisDataKey"])(currentState);
                    var domain = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipAxisDomain"])(currentState);
                    var effectiveMovement = movement * directionMultiplier;
                    // Build a minimal TooltipInteractionState for the candidate-index check.
                    var mkInteraction = (i)=>({
                            active: false,
                            index: String(i),
                            dataKey: undefined,
                            graphicalItemId: undefined,
                            coordinate: undefined
                        });
                    nextIndex = -1;
                    if (effectiveMovement > 0) {
                        for(var i = 0; i < displayedData.length; i++){
                            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveTooltipIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineActiveTooltipIndex"])(mkInteraction(i), displayedData, axisDataKey, domain) != null) {
                                nextIndex = i;
                                break;
                            }
                        }
                    } else {
                        for(var _i = displayedData.length - 1; _i >= 0; _i--){
                            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$combiners$2f$combineActiveTooltipIndex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineActiveTooltipIndex"])(mkInteraction(_i), displayedData, axisDataKey, domain) != null) {
                                nextIndex = _i;
                                break;
                            }
                        }
                    }
                    if (nextIndex < 0) {
                        return;
                    }
                } else {
                    nextIndex = currentIndex + movement * directionMultiplier;
                    var dataLength = (tooltipTicks === null || tooltipTicks === void 0 ? void 0 : tooltipTicks.length) || displayedData.length;
                    if (dataLength === 0 || nextIndex >= dataLength || nextIndex < 0) {
                        return;
                    }
                }
                var coordinate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectCoordinateForDefaultIndex"])(currentState, tooltipEventType, 'hover', String(nextIndex));
                listenerApi.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setKeyboardInteraction"])({
                    active: true,
                    activeIndex: nextIndex.toString(),
                    activeCoordinate: coordinate
                }));
            } finally{
                rafId = null;
                timeoutId = null;
            }
        };
        if (!isThrottled) {
            callback();
            return;
        }
        if (throttleDelay === 'raf') {
            rafId = requestAnimationFrame(callback);
        } else if (typeof throttleDelay === 'number') {
            if (timeoutId === null) {
                callback();
                latestKeyboardActionPayload = null;
                timeoutId = setTimeout(()=>{
                    if (latestKeyboardActionPayload) {
                        callback();
                    } else {
                        timeoutId = null;
                        rafId = null;
                    }
                }, throttleDelay);
            }
        }
    }
});
keyboardEventsMiddleware.startListening({
    actionCreator: focusAction,
    effect: (_action, listenerApi)=>{
        var state = listenerApi.getState();
        var accessibilityLayerIsActive = state.rootProps.accessibilityLayer !== false;
        if (!accessibilityLayerIsActive) {
            return;
        }
        var { keyboardInteraction } = state.tooltip;
        if (keyboardInteraction.active) {
            return;
        }
        if (keyboardInteraction.index == null) {
            var nextIndex = '0';
            var tooltipEventType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipEventType"])(state, state.tooltip.settings.shared);
            var coordinate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectCoordinateForDefaultIndex"])(state, tooltipEventType, 'hover', String(nextIndex));
            listenerApi.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setKeyboardInteraction"])({
                active: true,
                activeIndex: nextIndex,
                activeCoordinate: coordinate
            }));
        }
    }
});
keyboardEventsMiddleware.startListening({
    actionCreator: blurAction,
    effect: (_action, listenerApi)=>{
        var state = listenerApi.getState();
        var accessibilityLayerIsActive = state.rootProps.accessibilityLayer !== false;
        if (!accessibilityLayerIsActive) {
            return;
        }
        var { keyboardInteraction } = state.tooltip;
        if (keyboardInteraction.active) {
            listenerApi.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setKeyboardInteraction"])({
                active: false,
                activeIndex: keyboardInteraction.index,
                activeCoordinate: keyboardInteraction.coordinate
            }));
        }
    }
});
}),
"[project]/node_modules/recharts/es6/state/externalEventsMiddleware.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "externalEventAction",
    ()=>externalEventAction,
    "externalEventsMiddleware",
    ()=>externalEventsMiddleware
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/tooltipSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$createEventProxy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/createEventProxy.js [app-client] (ecmascript)");
;
;
;
var externalEventAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAction"])('externalEvent');
var externalEventsMiddleware = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createListenerMiddleware"])();
/*
 * We need a Map keyed by event type because this middleware handles MULTIPLE different event types
 * (click, mouseenter, mouseleave, mousedown, mouseup, contextmenu, dblclick, touchstart, touchmove, touchend)
 * from the same DOM element. Different event types should NOT cancel each other's animation frames.
 * For example, a click event and a mousemove event can happen in quick succession and both should be processed.
 * This is different from mouseMoveMiddleware which only handles one event type and uses a single rafId.
 */ var rafIdMap = new Map();
var timeoutIdMap = new Map();
var latestEventMap = new Map();
externalEventsMiddleware.startListening({
    actionCreator: externalEventAction,
    effect: (action, listenerApi)=>{
        var { handler, reactEvent } = action.payload;
        if (handler == null) {
            return;
        }
        var eventType = reactEvent.type;
        var eventProxy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$createEventProxy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEventProxy"])(reactEvent);
        latestEventMap.set(eventType, {
            handler,
            reactEvent: eventProxy
        });
        // Cancel any pending execution for this event type
        var existingRafId = rafIdMap.get(eventType);
        if (existingRafId !== undefined) {
            cancelAnimationFrame(existingRafId);
            rafIdMap.delete(eventType);
        }
        var state = listenerApi.getState();
        var { throttleDelay, throttledEvents } = state.eventSettings;
        /*
     * reactEvent.type gives us the event type as a string, e.g., 'click', 'mousemove', etc.
     * which is the same as the names used in throttledEvents array
     * but that array is strictly typed as ReadonlyArray<keyof GlobalEventHandlersEventMap> | 'all' | undefined
     * so that we can have relevant autocomplete and type checking elsewhere.
     * This makes TypeScript panic because it refuses to call .includes() on ReadonlyArray<keyof GlobalEventHandlersEventMap>
     * with a string argument.
     * To satisfy TypeScript, we need to explicitly typecast throttledEvents here.
     */ var eventListAsString = throttledEvents;
        // Check if this event type should be throttled
        // throttledEvents can be 'all' or an array of event names
        var isThrottled = eventListAsString === 'all' || (eventListAsString === null || eventListAsString === void 0 ? void 0 : eventListAsString.includes(eventType));
        var existingTimeoutId = timeoutIdMap.get(eventType);
        if (existingTimeoutId !== undefined && (typeof throttleDelay !== 'number' || !isThrottled)) {
            clearTimeout(existingTimeoutId);
            timeoutIdMap.delete(eventType);
        }
        var callback = ()=>{
            var latestAction = latestEventMap.get(eventType);
            try {
                if (!latestAction) {
                    // This happens if the event was consumed by the leading edge and no new event came in
                    return;
                }
                var { handler: latestHandler, reactEvent: latestEvent } = latestAction;
                var currentState = listenerApi.getState();
                var nextState = {
                    activeCoordinate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectActiveTooltipCoordinate"])(currentState),
                    activeDataKey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectActiveTooltipDataKey"])(currentState),
                    activeIndex: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectActiveTooltipIndex"])(currentState),
                    activeLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectActiveLabel"])(currentState),
                    activeTooltipIndex: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectActiveTooltipIndex"])(currentState),
                    isTooltipActive: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectIsTooltipActive"])(currentState)
                };
                if (latestHandler) {
                    latestHandler(nextState, latestEvent);
                }
            } finally{
                rafIdMap.delete(eventType);
                timeoutIdMap.delete(eventType);
                latestEventMap.delete(eventType);
            }
        };
        if (!isThrottled) {
            // Execute immediately
            callback();
            return;
        }
        if (throttleDelay === 'raf') {
            var rafId = requestAnimationFrame(callback);
            rafIdMap.set(eventType, rafId);
        } else if (typeof throttleDelay === 'number') {
            if (!timeoutIdMap.has(eventType)) {
                /*
         * Leading edge execution - execute immediately on the first event
         * and then start the cooldown period to throttle subsequent events.
         */ callback();
                // Start cooldown
                var timeoutId = setTimeout(callback, throttleDelay);
                timeoutIdMap.set(eventType, timeoutId);
            }
        } else {
            // Should not happen based on type, but fallback to immediate
            callback();
        }
    }
});
}),
"[project]/node_modules/recharts/es6/state/selectors/touchSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectTooltipCoordinate",
    ()=>selectTooltipCoordinate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipState.js [app-client] (ecmascript)");
;
;
var selectAllTooltipPayloadConfiguration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipState"]
], (tooltipState)=>tooltipState.tooltipItemPayloads);
var selectTooltipCoordinate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectAllTooltipPayloadConfiguration,
    (_state, tooltipIndex)=>tooltipIndex,
    (_state, _tooltipIndex, graphicalItemId)=>graphicalItemId
], (allTooltipConfigurations, tooltipIndex, graphicalItemId)=>{
    if (tooltipIndex == null) {
        return undefined;
    }
    var mostRelevantTooltipConfiguration = allTooltipConfigurations.find((tooltipConfiguration)=>{
        return tooltipConfiguration.settings.graphicalItemId === graphicalItemId;
    });
    if (mostRelevantTooltipConfiguration == null) {
        return undefined;
    }
    var { getPosition } = mostRelevantTooltipConfiguration;
    if (getPosition == null) {
        return undefined;
    }
    return getPosition(tooltipIndex);
});
}),
"[project]/node_modules/recharts/es6/state/touchEventsMiddleware.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "touchEventAction",
    ()=>touchEventAction,
    "touchEventMiddleware",
    ()=>touchEventMiddleware
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/tooltipSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectActivePropsFromChartPointer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectActivePropsFromChartPointer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getRelativeCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/getRelativeCoordinate.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectTooltipEventType.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/Constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$touchSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/touchSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/tooltipSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$createEventProxy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/createEventProxy.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
var touchEventAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAction"])('touchMove');
var touchEventMiddleware = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createListenerMiddleware"])();
var rafId = null;
var timeoutId = null;
var latestChartPointers = null;
var latestTouchEvent = null;
touchEventMiddleware.startListening({
    actionCreator: touchEventAction,
    effect: (action, listenerApi)=>{
        var touchEvent = action.payload;
        if (touchEvent.touches == null || touchEvent.touches.length === 0) {
            return;
        }
        latestTouchEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$createEventProxy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createEventProxy"])(touchEvent);
        var state = listenerApi.getState();
        var { throttleDelay, throttledEvents } = state.eventSettings;
        var isThrottled = throttledEvents === 'all' || throttledEvents.includes('touchmove');
        if (rafId !== null) {
            cancelAnimationFrame(rafId);
            rafId = null;
        }
        if (timeoutId !== null && (typeof throttleDelay !== 'number' || !isThrottled)) {
            clearTimeout(timeoutId);
            timeoutId = null;
        }
        latestChartPointers = Array.from(touchEvent.touches).map((touch)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$getRelativeCoordinate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRelativeCoordinate"])({
                clientX: touch.clientX,
                clientY: touch.clientY,
                currentTarget: touchEvent.currentTarget
            }));
        var callback = ()=>{
            if (latestTouchEvent == null) {
                return;
            }
            var currentState = listenerApi.getState();
            var tooltipEventType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectTooltipEventType$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipEventType"])(currentState, currentState.tooltip.settings.shared);
            if (tooltipEventType === 'axis') {
                var _latestChartPointers;
                var latestTouchPointer = (_latestChartPointers = latestChartPointers) === null || _latestChartPointers === void 0 ? void 0 : _latestChartPointers[0];
                if (latestTouchPointer == null) {
                    rafId = null;
                    timeoutId = null;
                    return;
                }
                var activeProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectActivePropsFromChartPointer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectActivePropsFromChartPointer"])(currentState, latestTouchPointer);
                if ((activeProps === null || activeProps === void 0 ? void 0 : activeProps.activeIndex) != null) {
                    listenerApi.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMouseOverAxisIndex"])({
                        activeIndex: activeProps.activeIndex,
                        activeDataKey: undefined,
                        activeCoordinate: activeProps.activeCoordinate
                    }));
                }
            } else if (tooltipEventType === 'item') {
                var _target$getAttribute;
                var touch = latestTouchEvent.touches[0];
                if (document.elementFromPoint == null || touch == null) {
                    return;
                }
                var target = document.elementFromPoint(touch.clientX, touch.clientY);
                if (!target || !target.getAttribute) {
                    return;
                }
                var itemIndex = target.getAttribute(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DATA_ITEM_INDEX_ATTRIBUTE_NAME"]);
                var graphicalItemId = (_target$getAttribute = target.getAttribute(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DATA_ITEM_GRAPHICAL_ITEM_ID_ATTRIBUTE_NAME"])) !== null && _target$getAttribute !== void 0 ? _target$getAttribute : undefined;
                var settings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$tooltipSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAllGraphicalItemsSettings"])(currentState).find((item)=>item.id === graphicalItemId);
                if (itemIndex == null || settings == null || graphicalItemId == null) {
                    return;
                }
                var { dataKey } = settings;
                var coordinate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$touchSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTooltipCoordinate"])(currentState, itemIndex, graphicalItemId);
                listenerApi.dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setActiveMouseOverItemIndex"])({
                    activeDataKey: dataKey,
                    activeIndex: itemIndex,
                    activeCoordinate: coordinate,
                    activeGraphicalItemId: graphicalItemId
                }));
            }
            rafId = null;
            timeoutId = null;
        };
        if (!isThrottled) {
            callback();
            return;
        }
        if (throttleDelay === 'raf') {
            rafId = requestAnimationFrame(callback);
        } else if (typeof throttleDelay === 'number') {
            if (timeoutId === null) {
                callback();
                latestTouchEvent = null;
                timeoutId = setTimeout(()=>{
                    if (latestTouchEvent) {
                        callback();
                    } else {
                        timeoutId = null;
                        rafId = null;
                    }
                }, throttleDelay);
            }
        }
    }
});
}),
"[project]/node_modules/recharts/es6/state/errorBarSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addErrorBar",
    ()=>addErrorBar,
    "errorBarReducer",
    ()=>errorBarReducer,
    "removeErrorBar",
    ()=>removeErrorBar,
    "replaceErrorBar",
    ()=>replaceErrorBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
;
/**
 * ErrorBars have lot more settings but all the others are scoped to the component itself.
 * Only some of them required to be reported to the global store because XAxis and YAxis need to know
 * if the error bar is contributing to extending the axis domain.
 */ var initialState = {};
var errorBarSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'errorBars',
    initialState,
    reducers: {
        addErrorBar: (state, action)=>{
            var { itemId, errorBar } = action.payload;
            if (!state[itemId]) {
                state[itemId] = [];
            }
            state[itemId].push(errorBar);
        },
        replaceErrorBar: (state, action)=>{
            var { itemId, prev, next } = action.payload;
            if (state[itemId]) {
                state[itemId] = state[itemId].map((e)=>e.dataKey === prev.dataKey && e.direction === prev.direction ? next : e);
            }
        },
        removeErrorBar: (state, action)=>{
            var { itemId, errorBar } = action.payload;
            if (state[itemId]) {
                state[itemId] = state[itemId].filter((e)=>e.dataKey !== errorBar.dataKey || e.direction !== errorBar.direction);
            }
        }
    }
});
var { addErrorBar, replaceErrorBar, removeErrorBar } = errorBarSlice.actions;
var errorBarReducer = errorBarSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/zIndexSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "registerZIndexPortal",
    ()=>registerZIndexPortal,
    "registerZIndexPortalElement",
    ()=>registerZIndexPortalElement,
    "unregisterZIndexPortal",
    ()=>unregisterZIndexPortal,
    "unregisterZIndexPortalElement",
    ()=>unregisterZIndexPortalElement,
    "zIndexReducer",
    ()=>zIndexReducer
]);
/**
 * This slice contains a registry of z-index values for various components.
 * The state is a map from z-index numbers to element references.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$zIndex$2f$DefaultZIndexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/zIndex/DefaultZIndexes.js [app-client] (ecmascript)");
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
;
;
;
var seed = {};
var initialState = {
    zIndexMap: Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$zIndex$2f$DefaultZIndexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultZIndexes"]).reduce((acc, current)=>_objectSpread(_objectSpread({}, acc), {}, {
            [current]: {
                element: undefined,
                panoramaElement: undefined,
                consumers: 0
            }
        }), seed)
};
var defaultZIndexSet = new Set(Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$zIndex$2f$DefaultZIndexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DefaultZIndexes"]));
function isDefaultZIndex(zIndex) {
    return defaultZIndexSet.has(zIndex);
}
var zIndexSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'zIndex',
    initialState,
    reducers: {
        registerZIndexPortal: {
            reducer: (state, action)=>{
                var { zIndex } = action.payload;
                if (state.zIndexMap[zIndex]) {
                    state.zIndexMap[zIndex].consumers += 1;
                } else {
                    state.zIndexMap[zIndex] = {
                        consumers: 1,
                        element: undefined,
                        panoramaElement: undefined
                    };
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        unregisterZIndexPortal: {
            reducer: (state, action)=>{
                var { zIndex } = action.payload;
                if (state.zIndexMap[zIndex]) {
                    state.zIndexMap[zIndex].consumers -= 1;
                    /*
           * Garbage collect unused z-index entries, except for default z-indexes.
           * Default z-indexes are always rendered, regardless of whether there are consumers or not.
           * And because of that, even if we delete this entry, the ZIndexPortal provider will still be rendered
           * and React is not going to re-create it, and it won't re-register the element ID.
           * So let's not delete default z-index entries.
           */ if (state.zIndexMap[zIndex].consumers <= 0 && !isDefaultZIndex(zIndex)) {
                        delete state.zIndexMap[zIndex];
                    }
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        registerZIndexPortalElement: {
            reducer: (state, action)=>{
                var { zIndex, element, isPanorama } = action.payload;
                if (state.zIndexMap[zIndex]) {
                    if (isPanorama) {
                        state.zIndexMap[zIndex].panoramaElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(element);
                    } else {
                        state.zIndexMap[zIndex].element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(element);
                    }
                } else {
                    state.zIndexMap[zIndex] = {
                        consumers: 0,
                        element: isPanorama ? undefined : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(element),
                        panoramaElement: isPanorama ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(element) : undefined
                    };
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        },
        unregisterZIndexPortalElement: {
            reducer: (state, action)=>{
                var { zIndex } = action.payload;
                if (state.zIndexMap[zIndex]) {
                    if (action.payload.isPanorama) {
                        state.zIndexMap[zIndex].panoramaElement = undefined;
                    } else {
                        state.zIndexMap[zIndex].element = undefined;
                    }
                }
            },
            prepare: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["prepareAutoBatched"])()
        }
    }
});
var { registerZIndexPortal, unregisterZIndexPortal, registerZIndexPortalElement, unregisterZIndexPortalElement } = zIndexSlice.actions;
var zIndexReducer = zIndexSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/eventSettingsSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "eventSettingsReducer",
    ()=>eventSettingsReducer,
    "initialEventSettingsState",
    ()=>initialEventSettingsState,
    "setEventSettings",
    ()=>setEventSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
;
;
var initialEventSettingsState = {
    throttleDelay: 'raf',
    throttledEvents: [
        'mousemove',
        'touchmove',
        'pointermove',
        'scroll',
        'wheel'
    ]
};
var eventSettingsSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'eventSettings',
    initialState: initialEventSettingsState,
    reducers: {
        setEventSettings: (state, action)=>{
            if (action.payload.throttleDelay != null) {
                state.throttleDelay = action.payload.throttleDelay;
            }
            if (action.payload.throttledEvents != null) {
                state.throttledEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(action.payload.throttledEvents);
            }
        }
    }
});
var { setEventSettings } = eventSettingsSlice.actions;
var eventSettingsReducer = eventSettingsSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/renderedTicksSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "removeRenderedTicks",
    ()=>removeRenderedTicks,
    "renderedTicksReducer",
    ()=>renderedTicksReducer,
    "renderedTicksSlice",
    ()=>renderedTicksSlice,
    "setRenderedTicks",
    ()=>setRenderedTicks
]);
/**
 * @fileOverview this stores actually rendered ticks.
 *
 * What we do is that we have the domain -> ticks mapping in the cartesianSlice,
 * which is fine but the result then goes to CartesianAxis where we use DOM measurement
 * to decide which ticks to actually render.
 *
 * This renderedTickSlice stores those actually rendered ticks so that we can return them from a hook later.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
;
;
var initialState = {
    xAxis: {},
    yAxis: {}
};
var renderedTicksSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: 'renderedTicks',
    initialState,
    reducers: {
        setRenderedTicks: (state, action)=>{
            var { axisType, axisId, ticks } = action.payload;
            state[axisType][axisId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castDraft"])(ticks);
        },
        removeRenderedTicks: (state, action)=>{
            var { axisType, axisId } = action.payload;
            delete state[axisType][axisId];
        }
    }
});
var { setRenderedTicks, removeRenderedTicks } = renderedTicksSlice.actions;
var renderedTicksReducer = renderedTicksSlice.reducer;
}),
"[project]/node_modules/recharts/es6/state/store.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createRechartsStore",
    ()=>createRechartsStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$redux$2f$dist$2f$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/redux/dist/redux.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$optionsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/optionsSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/tooltipSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$chartDataSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/chartDataSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$layoutSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/layoutSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$mouseEventsMiddleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/mouseEventsMiddleware.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$reduxDevtoolsJsonStringifyReplacer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/reduxDevtoolsJsonStringifyReplacer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$cartesianAxisSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/cartesianAxisSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$graphicalItemsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/graphicalItemsSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$referenceElementsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/referenceElementsSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$brushSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/brushSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$legendSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/legendSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$rootPropsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/rootPropsSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$polarAxisSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/polarAxisSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$polarOptionsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/polarOptionsSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$keyboardEventsMiddleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/keyboardEventsMiddleware.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$externalEventsMiddleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/externalEventsMiddleware.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$touchEventsMiddleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/touchEventsMiddleware.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$errorBarSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/errorBarSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Global$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/Global.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$zIndexSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/zIndexSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$eventSettingsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/eventSettingsSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$renderedTicksSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/renderedTicksSlice.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var rootReducer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$redux$2f$dist$2f$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combineReducers"])({
    brush: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$brushSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["brushReducer"],
    cartesianAxis: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$cartesianAxisSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianAxisReducer"],
    chartData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$chartDataSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chartDataReducer"],
    errorBars: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$errorBarSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["errorBarReducer"],
    eventSettings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$eventSettingsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["eventSettingsReducer"],
    graphicalItems: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$graphicalItemsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["graphicalItemsReducer"],
    layout: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$layoutSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chartLayoutReducer"],
    legend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$legendSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["legendReducer"],
    options: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$optionsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsReducer"],
    polarAxis: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$polarAxisSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["polarAxisReducer"],
    polarOptions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$polarOptionsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["polarOptionsReducer"],
    referenceElements: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$referenceElementsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["referenceElementsReducer"],
    renderedTicks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$renderedTicksSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderedTicksReducer"],
    rootProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$rootPropsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rootPropsReducer"],
    tooltip: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tooltipReducer"],
    zIndex: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$zIndexSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["zIndexReducer"]
});
var createRechartsStore = function createRechartsStore(preloadedState) {
    var chartName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'Chart';
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["configureStore"])({
        reducer: rootReducer,
        // redux-toolkit v1 types are unhappy with the preloadedState type. Remove the `as any` when bumping to v2
        preloadedState: preloadedState,
        // @ts-expect-error redux-toolkit v1 types are unhappy with the middleware array. Remove this comment when bumping to v2
        middleware: (getDefaultMiddleware)=>{
            var _process$env$NODE_ENV;
            return getDefaultMiddleware({
                serializableCheck: false,
                immutableCheck: ![
                    'commonjs',
                    'es6',
                    'production'
                ].includes((_process$env$NODE_ENV = "es6") !== null && _process$env$NODE_ENV !== void 0 ? _process$env$NODE_ENV : '')
            }).concat([
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$mouseEventsMiddleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mouseClickMiddleware"].middleware,
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$mouseEventsMiddleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mouseMoveMiddleware"].middleware,
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$keyboardEventsMiddleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["keyboardEventsMiddleware"].middleware,
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$externalEventsMiddleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["externalEventsMiddleware"].middleware,
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$touchEventsMiddleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["touchEventMiddleware"].middleware
            ]);
        },
        /*
     * I can't find out how to satisfy typescript here.
     * We return `EnhancerArray<[StoreEnhancer<{}, {}>, StoreEnhancer]>` from this function,
     * but the types say we should return `EnhancerArray<StoreEnhancer<{}, {}>`.
     * Looks like it's badly inferred generics, but it won't allow me to provide the correct type manually either.
     * So let's just ignore the error for now.
     */ // @ts-expect-error mismatched generics
        enhancers: (getDefaultEnhancers)=>{
            var enhancers = getDefaultEnhancers;
            if (typeof getDefaultEnhancers === 'function') {
                /*
         * In RTK v2 this is always a function, but in v1 it is an array.
         * Because we have @types/redux-toolkit v1 as a dependency, typescript is going to flag this as an error.
         * We support both RTK v1 and v2, so we need to do this check.
         * https://redux-toolkit.js.org/usage/migrating-rtk-2#configurestoreenhancers-must-be-a-callback
         */ // @ts-expect-error RTK v2 behaviour on RTK v1 types
                enhancers = getDefaultEnhancers();
            }
            return enhancers.concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoBatchEnhancer"])({
                type: 'raf'
            }));
        },
        devTools: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$Global$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Global"].devToolsEnabled && {
            serialize: {
                replacer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$reduxDevtoolsJsonStringifyReplacer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reduxDevtoolsJsonStringifyReplacer"]
            },
            name: "recharts-".concat(chartName)
        }
    });
};
}),
"[project]/node_modules/recharts/es6/state/RechartsStoreProvider.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RechartsStoreProvider",
    ()=>RechartsStoreProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/store.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$PanoramaContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/PanoramaContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$RechartsReduxContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/RechartsReduxContext.js [app-client] (ecmascript)");
;
;
;
;
;
;
function RechartsStoreProvider(_ref) {
    var { preloadedState, children, reduxStoreName } = _ref;
    var isPanorama = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$PanoramaContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsPanorama"])();
    /*
   * Why the ref? Redux official documentation recommends to use store as a singleton,
   * and reuse that everywhere: https://redux-toolkit.js.org/api/configureStore#basic-example
   *
   * Which is correct! Except that is considering deploying Redux in an app.
   * Recharts as a library supports multiple charts on the same page.
   * And each of these charts needs its own store independent of others!
   *
   * The alternative is to have everything in the store keyed by the chart id.
   * Which would make working with everything a little bit more painful because we need the chart id everywhere.
   */ var storeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    /*
   * Panorama means that this chart is not its own chart, it's only a "preview"
   * being rendered as a child of Brush.
   * In such case, it should not have a store on its own - it should implicitly inherit
   * whatever data is in the "parent" or "root" chart.
   * Which here is represented by not having a Provider at all. All selectors will use the root store by default.
   */ if (isPanorama) {
        return children;
    }
    if (storeRef.current == null) {
        storeRef.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRechartsStore"])(preloadedState, reduxStoreName);
    }
    // @ts-expect-error React-Redux types demand that the context internal value is not null, but we have that as default.
    var nonNullContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$RechartsReduxContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RechartsReduxContext"];
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Provider"], {
        context: nonNullContext,
        store: storeRef.current
    }, children);
}
}),
"[project]/node_modules/recharts/es6/state/ReportMainChartProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ReportMainChartProps",
    ()=>ReportMainChartProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$PanoramaContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/PanoramaContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$layoutSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/layoutSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$propsAreEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/propsAreEqual.js [app-client] (ecmascript)");
;
;
;
;
;
/**
 * "Main" props are props that are only accepted on the main chart,
 * as opposed to the small panorama chart inside a Brush.
 */ function ReportMainChartPropsImpl(_ref) {
    var { layout, margin } = _ref;
    var dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    /*
   * Skip dispatching properties in panorama chart for two reasons:
   * 1. The root chart should be deciding on these properties, and
   * 2. Brush reads these properties from redux store, and so they must remain stable
   *      to avoid circular dependency and infinite re-rendering.
   */ var isPanorama = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$PanoramaContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsPanorama"])();
    /*
   * useEffect here is required to avoid the "Cannot update a component while rendering a different component" error.
   * https://github.com/facebook/react/issues/18178
   *
   * Reported in https://github.com/recharts/recharts/issues/5514
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ReportMainChartPropsImpl.useEffect": ()=>{
            if (!isPanorama) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$layoutSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setLayout"])(layout));
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$layoutSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMargin"])(margin));
            }
        }
    }["ReportMainChartPropsImpl.useEffect"], [
        dispatch,
        isPanorama,
        layout,
        margin
    ]);
    return null;
}
var ReportMainChartProps = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(ReportMainChartPropsImpl, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$propsAreEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["propsAreEqual"]);
}),
"[project]/node_modules/recharts/es6/state/ReportChartProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ReportChartProps",
    ()=>ReportChartProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$rootPropsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/rootPropsSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/hooks.js [app-client] (ecmascript)");
;
;
;
function ReportChartProps(props) {
    var dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ReportChartProps.useEffect": ()=>{
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$rootPropsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateOptions"])(props));
        }
    }["ReportChartProps.useEffect"], [
        dispatch,
        props
    ]);
    return null;
}
}),
"[project]/node_modules/recharts/es6/state/ReportEventSettings.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ReportEventSettings",
    ()=>ReportEventSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$eventSettingsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/eventSettingsSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$propsAreEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/propsAreEqual.js [app-client] (ecmascript)");
;
;
;
;
var ReportEventSettingsImpl = (props)=>{
    var dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ReportEventSettingsImpl.useEffect": ()=>{
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$eventSettingsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setEventSettings"])(props));
        }
    }["ReportEventSettingsImpl.useEffect"], [
        dispatch,
        props
    ]);
    return null;
};
var ReportEventSettings = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(ReportEventSettingsImpl, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$propsAreEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["propsAreEqual"]);
}),
"[project]/node_modules/recharts/es6/state/selectors/selectChartOffset.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectChartOffset",
    ()=>selectChartOffset
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectChartOffsetInternal.js [app-client] (ecmascript)");
;
;
var selectChartOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffsetInternal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffsetInternal"]
], (offsetInternal)=>{
    return {
        top: offsetInternal.top,
        bottom: offsetInternal.bottom,
        left: offsetInternal.left,
        right: offsetInternal.right
    };
});
}),
"[project]/node_modules/recharts/es6/state/selectors/selectPlotArea.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectPlotArea",
    ()=>selectPlotArea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/selectChartOffset.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/containerSelectors.js [app-client] (ecmascript)");
;
;
;
var selectPlotArea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$selectChartOffset$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartOffset"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartWidth"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$containerSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartHeight"]
], (offset, chartWidth, chartHeight)=>{
    if (!offset || chartWidth == null || chartHeight == null) {
        return undefined;
    }
    return {
        x: offset.left,
        y: offset.top,
        width: Math.max(0, chartWidth - offset.left - offset.right),
        height: Math.max(0, chartHeight - offset.top - offset.bottom)
    };
});
}),
"[project]/node_modules/recharts/es6/state/SetTooltipEntrySettings.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SetTooltipEntrySettings",
    ()=>SetTooltipEntrySettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/tooltipSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$PanoramaContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/PanoramaContext.js [app-client] (ecmascript)");
;
;
;
;
function SetTooltipEntrySettings(_ref) {
    var { tooltipEntrySettings } = _ref;
    var dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    var isPanorama = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$PanoramaContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsPanorama"])();
    var prevSettingsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetTooltipEntrySettings.useLayoutEffect": ()=>{
            if (isPanorama) {
                // Panorama graphical items should never contribute to Tooltip payload.
                return;
            }
            if (prevSettingsRef.current === null) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addTooltipEntrySettings"])(tooltipEntrySettings));
            } else if (prevSettingsRef.current !== tooltipEntrySettings) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceTooltipEntrySettings"])({
                    prev: prevSettingsRef.current,
                    next: tooltipEntrySettings
                }));
            }
            prevSettingsRef.current = tooltipEntrySettings;
        }
    }["SetTooltipEntrySettings.useLayoutEffect"], [
        tooltipEntrySettings,
        dispatch,
        isPanorama
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetTooltipEntrySettings.useLayoutEffect": ()=>{
            return ({
                "SetTooltipEntrySettings.useLayoutEffect": ()=>{
                    if (prevSettingsRef.current) {
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$tooltipSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeTooltipEntrySettings"])(prevSettingsRef.current));
                        prevSettingsRef.current = null;
                    }
                }
            })["SetTooltipEntrySettings.useLayoutEffect"];
        }
    }["SetTooltipEntrySettings.useLayoutEffect"], [
        dispatch
    ]);
    return null;
}
}),
"[project]/node_modules/recharts/es6/state/selectors/graphicalItemSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectXAxisIdFromGraphicalItemId",
    ()=>selectXAxisIdFromGraphicalItemId,
    "selectYAxisIdFromGraphicalItemId",
    ()=>selectYAxisIdFromGraphicalItemId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$cartesianAxisSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/cartesianAxisSlice.js [app-client] (ecmascript)");
;
function selectXAxisIdFromGraphicalItemId(state, id) {
    var _state$graphicalItems, _state$graphicalItems2;
    return (_state$graphicalItems = (_state$graphicalItems2 = state.graphicalItems.cartesianItems.find((item)=>item.id === id)) === null || _state$graphicalItems2 === void 0 ? void 0 : _state$graphicalItems2.xAxisId) !== null && _state$graphicalItems !== void 0 ? _state$graphicalItems : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$cartesianAxisSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultAxisId"];
}
function selectYAxisIdFromGraphicalItemId(state, id) {
    var _state$graphicalItems3, _state$graphicalItems4;
    return (_state$graphicalItems3 = (_state$graphicalItems4 = state.graphicalItems.cartesianItems.find((item)=>item.id === id)) === null || _state$graphicalItems4 === void 0 ? void 0 : _state$graphicalItems4.yAxisId) !== null && _state$graphicalItems3 !== void 0 ? _state$graphicalItems3 : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$cartesianAxisSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultAxisId"];
}
}),
"[project]/node_modules/recharts/es6/state/selectors/areaSelectors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectArea",
    ()=>selectArea,
    "selectGraphicalItemStackedData",
    ()=>selectGraphicalItemStackedData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/reselect/dist/reselect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Area$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/cartesian/Area.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/axisSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/chartLayoutContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/dataSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/ChartUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$stacks$2f$getStackSeriesIdentifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/util/stacks/getStackSeriesIdentifier.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/rootPropsSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$graphicalItemSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/selectors/graphicalItemSelectors.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
var selectXAxisWithScale = (state, graphicalItemId, isPanorama)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAxisWithScale"])(state, 'xAxis', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$graphicalItemSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectXAxisIdFromGraphicalItemId"])(state, graphicalItemId), isPanorama);
var selectXAxisTicks = (state, graphicalItemId, isPanorama)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTicksOfGraphicalItem"])(state, 'xAxis', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$graphicalItemSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectXAxisIdFromGraphicalItemId"])(state, graphicalItemId), isPanorama);
var selectYAxisWithScale = (state, graphicalItemId, isPanorama)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectAxisWithScale"])(state, 'yAxis', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$graphicalItemSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectYAxisIdFromGraphicalItemId"])(state, graphicalItemId), isPanorama);
var selectYAxisTicks = (state, graphicalItemId, isPanorama)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectTicksOfGraphicalItem"])(state, 'yAxis', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$graphicalItemSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectYAxisIdFromGraphicalItemId"])(state, graphicalItemId), isPanorama);
var selectBandSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectXAxisWithScale,
    selectYAxisWithScale,
    selectXAxisTicks,
    selectYAxisTicks
], (layout, xAxis, yAxis, xAxisTicks, yAxisTicks)=>{
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCategoricalAxis"])(layout, 'xAxis')) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBandSizeOfAxis"])(xAxis, xAxisTicks, false);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBandSizeOfAxis"])(yAxis, yAxisTicks, false);
});
var pickAreaId = (_state, id)=>id;
/*
 * There is a race condition problem because we read some data from props and some from the state.
 * The state is updated through a dispatch and is one render behind,
 * and so we have this weird one tick render where the displayedData in one selector have the old dataKey
 * but the new dataKey in another selector.
 *
 * A proper fix is to either move everything into the state, or read the dataKey always from props
 * - but this is a smaller change.
 */ var selectSynchronisedAreaSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectUnfilteredCartesianItems"],
    pickAreaId
], (graphicalItems, id)=>graphicalItems.filter((item)=>item.type === 'area').find((item)=>item.id === id));
var selectNumericalAxisType = (state)=>{
    var layout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"])(state);
    var isXAxisCategorical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$ChartUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCategoricalAxis"])(layout, 'xAxis');
    return isXAxisCategorical ? 'yAxis' : 'xAxis';
};
var selectNumericalAxisIdFromGraphicalItemId = (state, graphicalItemId)=>{
    var axisType = selectNumericalAxisType(state);
    if (axisType === 'yAxis') {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$graphicalItemSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectYAxisIdFromGraphicalItemId"])(state, graphicalItemId);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$graphicalItemSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectXAxisIdFromGraphicalItemId"])(state, graphicalItemId);
};
var selectNumericalAxisStackGroups = (state, graphicalItemId, isPanorama)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$axisSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectStackGroups"])(state, selectNumericalAxisType(state), selectNumericalAxisIdFromGraphicalItemId(state, graphicalItemId), isPanorama);
var selectGraphicalItemStackedData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    selectSynchronisedAreaSettings,
    selectNumericalAxisStackGroups
], (areaSettings, stackGroups)=>{
    var _stackGroups$stackId;
    if (areaSettings == null || stackGroups == null) {
        return undefined;
    }
    var { stackId } = areaSettings;
    var stackSeriesIdentifier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$util$2f$stacks$2f$getStackSeriesIdentifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStackSeriesIdentifier"])(areaSettings);
    if (stackId == null || stackSeriesIdentifier == null) {
        return undefined;
    }
    var groups = (_stackGroups$stackId = stackGroups[stackId]) === null || _stackGroups$stackId === void 0 ? void 0 : _stackGroups$stackId.stackedData;
    var found = groups === null || groups === void 0 ? void 0 : groups.find((v)=>v.key === stackSeriesIdentifier);
    if (found == null) {
        return undefined;
    }
    return found.map((item)=>[
            item[0],
            item[1]
        ]);
});
var selectArea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$reselect$2f$dist$2f$reselect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"],
    selectXAxisWithScale,
    selectYAxisWithScale,
    selectXAxisTicks,
    selectYAxisTicks,
    selectGraphicalItemStackedData,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$dataSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartDataWithIndexesIfNotInPanoramaPosition3"],
    selectBandSize,
    selectSynchronisedAreaSettings,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$selectors$2f$rootPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartBaseValue"]
], (layout, xAxis, yAxis, xAxisTicks, yAxisTicks, stackedData, _ref, bandSize, areaSettings, chartBaseValue)=>{
    var { chartData, dataStartIndex, dataEndIndex } = _ref;
    if (areaSettings == null || layout !== 'horizontal' && layout !== 'vertical' || xAxis == null || yAxis == null || xAxisTicks == null || yAxisTicks == null || xAxisTicks.length === 0 || yAxisTicks.length === 0 || bandSize == null) {
        return undefined;
    }
    var { data } = areaSettings;
    var displayedData;
    if (data && data.length > 0) {
        displayedData = data;
    } else {
        displayedData = chartData === null || chartData === void 0 ? void 0 : chartData.slice(dataStartIndex, dataEndIndex + 1);
    }
    if (displayedData == null) {
        return undefined;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Area$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeArea"])({
        layout,
        xAxis,
        yAxis,
        xAxisTicks,
        yAxisTicks,
        dataStartIndex,
        areaSettings,
        stackedData,
        displayedData,
        chartBaseValue,
        bandSize
    });
});
}),
"[project]/node_modules/recharts/es6/state/SetLegendPayload.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SetLegendPayload",
    ()=>SetLegendPayload,
    "SetPolarLegendPayload",
    ()=>SetPolarLegendPayload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$PanoramaContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/PanoramaContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/context/chartLayoutContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$legendSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/legendSlice.js [app-client] (ecmascript)");
;
;
;
;
;
function SetLegendPayload(_ref) {
    var { legendPayload } = _ref;
    var dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    var isPanorama = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$PanoramaContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsPanorama"])();
    var prevPayloadRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetLegendPayload.useLayoutEffect": ()=>{
            if (isPanorama) {
                return;
            }
            if (prevPayloadRef.current === null) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$legendSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addLegendPayload"])(legendPayload));
            } else if (prevPayloadRef.current !== legendPayload) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$legendSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceLegendPayload"])({
                    prev: prevPayloadRef.current,
                    next: legendPayload
                }));
            }
            prevPayloadRef.current = legendPayload;
        }
    }["SetLegendPayload.useLayoutEffect"], [
        dispatch,
        isPanorama,
        legendPayload
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetLegendPayload.useLayoutEffect": ()=>{
            return ({
                "SetLegendPayload.useLayoutEffect": ()=>{
                    if (prevPayloadRef.current) {
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$legendSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeLegendPayload"])(prevPayloadRef.current));
                        prevPayloadRef.current = null;
                    }
                }
            })["SetLegendPayload.useLayoutEffect"];
        }
    }["SetLegendPayload.useLayoutEffect"], [
        dispatch
    ]);
    return null;
}
function SetPolarLegendPayload(_ref2) {
    var { legendPayload } = _ref2;
    var dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    var layout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppSelector"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$context$2f$chartLayoutContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectChartLayout"]);
    var prevPayloadRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetPolarLegendPayload.useLayoutEffect": ()=>{
            if (layout !== 'centric' && layout !== 'radial') {
                return;
            }
            if (prevPayloadRef.current === null) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$legendSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addLegendPayload"])(legendPayload));
            } else if (prevPayloadRef.current !== legendPayload) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$legendSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceLegendPayload"])({
                    prev: prevPayloadRef.current,
                    next: legendPayload
                }));
            }
            prevPayloadRef.current = legendPayload;
        }
    }["SetPolarLegendPayload.useLayoutEffect"], [
        dispatch,
        layout,
        legendPayload
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetPolarLegendPayload.useLayoutEffect": ()=>{
            return ({
                "SetPolarLegendPayload.useLayoutEffect": ()=>{
                    if (prevPayloadRef.current) {
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$legendSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeLegendPayload"])(prevPayloadRef.current));
                        prevPayloadRef.current = null;
                    }
                }
            })["SetPolarLegendPayload.useLayoutEffect"];
        }
    }["SetPolarLegendPayload.useLayoutEffect"], [
        dispatch
    ]);
    return null;
}
}),
"[project]/node_modules/recharts/es6/state/SetGraphicalItem.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SetCartesianGraphicalItem",
    ()=>SetCartesianGraphicalItem,
    "SetPolarGraphicalItem",
    ()=>SetPolarGraphicalItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/hooks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$graphicalItemsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/state/graphicalItemsSlice.js [app-client] (ecmascript)");
;
;
;
var SetCartesianGraphicalItemImpl = (props)=>{
    var dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    var prevPropsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetCartesianGraphicalItemImpl.useLayoutEffect": ()=>{
            if (prevPropsRef.current === null) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$graphicalItemsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addCartesianGraphicalItem"])(props));
            } else if (prevPropsRef.current !== props) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$graphicalItemsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceCartesianGraphicalItem"])({
                    prev: prevPropsRef.current,
                    next: props
                }));
            }
            prevPropsRef.current = props;
        }
    }["SetCartesianGraphicalItemImpl.useLayoutEffect"], [
        dispatch,
        props
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetCartesianGraphicalItemImpl.useLayoutEffect": ()=>{
            return ({
                "SetCartesianGraphicalItemImpl.useLayoutEffect": ()=>{
                    if (prevPropsRef.current) {
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$graphicalItemsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeCartesianGraphicalItem"])(prevPropsRef.current));
                        /*
         * Here we have to reset the ref to null because in StrictMode, the effect will run twice,
         * but it will keep the same ref value from the first render.
         *
         * In browser, React will clear the ref after the first effect cleanup,
         * so that wouldn't be an issue.
         *
         * In StrictMode, however, the ref is kept,
         * and in the hook above the code checks for `prevPropsRef.current === null`
         * which would be false so it would not dispatch the `addCartesianGraphicalItem` action again.
         *
         * https://github.com/recharts/recharts/issues/6022
         */ prevPropsRef.current = null;
                    }
                }
            })["SetCartesianGraphicalItemImpl.useLayoutEffect"];
        }
    }["SetCartesianGraphicalItemImpl.useLayoutEffect"], [
        dispatch
    ]);
    return null;
};
var SetCartesianGraphicalItem = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(SetCartesianGraphicalItemImpl);
var SetPolarGraphicalItemImpl = (props)=>{
    var dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$hooks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    var prevPropsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetPolarGraphicalItemImpl.useLayoutEffect": ()=>{
            if (prevPropsRef.current === null) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$graphicalItemsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addPolarGraphicalItem"])(props));
            } else if (prevPropsRef.current !== props) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$graphicalItemsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replacePolarGraphicalItem"])({
                    prev: prevPropsRef.current,
                    next: props
                }));
            }
            prevPropsRef.current = props;
        }
    }["SetPolarGraphicalItemImpl.useLayoutEffect"], [
        dispatch,
        props
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])({
        "SetPolarGraphicalItemImpl.useLayoutEffect": ()=>{
            return ({
                "SetPolarGraphicalItemImpl.useLayoutEffect": ()=>{
                    if (prevPropsRef.current) {
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$state$2f$graphicalItemsSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removePolarGraphicalItem"])(prevPropsRef.current));
                        prevPropsRef.current = null;
                    }
                }
            })["SetPolarGraphicalItemImpl.useLayoutEffect"];
        }
    }["SetPolarGraphicalItemImpl.useLayoutEffect"], [
        dispatch
    ]);
    return null;
};
var SetPolarGraphicalItem = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(SetPolarGraphicalItemImpl);
}),
]);

//# sourceMappingURL=node_modules_recharts_es6_state_0d7bkjz._.js.map